<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class SGP_Elementor_Availability_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'sgp_availability_form';
    }

    public function get_title() {
        return __( 'Verificação de Disponibilidade SGP', 'sgp-integration' );
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return [ 'sgp-widgets' ];
    }

    protected function _register_controls() {
        // Layout
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Layout', 'sgp-integration' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'form_columns',
            [
                'label' => __( 'Colunas', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'options' => [
                    '1' => __( '1 Coluna', 'sgp-integration' ),
                    '2' => __( '2 Colunas', 'sgp-integration' ),
                ],
            ]
        );
        $this->add_control(
            'show_title',
            [
                'label' => __( 'Exibir Título', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'title_align',
            [
                'label' => __( 'Alinhamento do Título', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [ 'title' => __( 'Esquerda', 'sgp-integration' ), 'icon' => 'eicon-text-align-left' ],
                    'center' => [ 'title' => __( 'Centro', 'sgp-integration' ), 'icon' => 'eicon-text-align-center' ],
                    'right' => [ 'title' => __( 'Direita', 'sgp-integration' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-title' => 'text-align: {{VALUE}};',
                ],
                'condition' => [ 'show_title' => 'yes' ]
            ]
        );
        $this->end_controls_section();

        // Estilo do Formulário
        $this->start_controls_section(
            'section_style_form',
            [
                'label' => __( 'Formulário', 'sgp-integration' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'form_bg_color',
            [
                'label' => __( 'Cor de Fundo', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-availability-form-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'form_padding',
            [
                'label' => __( 'Padding', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-availability-form-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'form_border_radius',
            [
                'label' => __( 'Arredondamento do Formulário', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-availability-form-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        // Título
        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __( 'Título', 'sgp-integration' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Cor do Título', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .sgp-form-title',
            ]
        );
        $this->end_controls_section();

        // Campos
        $this->start_controls_section(
            'section_style_fields',
            [
                'label' => __( 'Campos', 'sgp-integration' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'fields_bg_color',
            [
                'label' => __( 'Cor de Fundo dos Campos', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'fields_text_color',
            [
                'label' => __( 'Cor do Texto dos Campos', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'fields_border_radius',
            [
                'label' => __( 'Arredondamento dos Campos', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'fields_typography',
                'selector' => '{{WRAPPER}} .sgp-input',
            ]
        );
        $this->end_controls_section();

        // Botão
        $this->start_controls_section(
            'section_style_button',
            [
                'label' => __( 'Botão', 'sgp-integration' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'button_bg_color',
            [
                'label' => __( 'Cor de Fundo do Botão', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-button-primary' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Cor do Texto do Botão', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-button-primary' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_border_radius',
            [
                'label' => __( 'Arredondamento do Botão', 'sgp-integration' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-button-primary' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .sgp-button-primary',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        // Adiciona classe para layout de colunas
        $columns_class = ($settings['form_columns'] === '1') ? 'sgp-form-1col' : 'sgp-form-2col';
        // Exibe ou não o título
        $show_title = $settings['show_title'] !== 'no';
        echo '<div class="sgp-elementor-widget-wrapper">';
        echo '<div class="sgp-availability-form-container ' . esc_attr($columns_class) . '">';
        if ($show_title) {
            echo '<h3 class="sgp-form-title">Verifique a disponibilidade em seu endereço</h3>';
        }
        echo do_shortcode('[sgp_availability_form]');
        echo '</div>';
        echo '</div>';
    }
} 