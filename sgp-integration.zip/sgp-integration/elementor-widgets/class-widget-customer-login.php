<?php
/**
 * Widget Elementor - Área do Cliente SGP
 * 
 * Widget personalizado para exibir o formulário de login da área do cliente
 * com opções avançadas de customização.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Schemes\Typography;
use Elementor\Core\Schemes\Color;

class SGP_Elementor_Customer_Login_Widget extends Widget_Base {

    public function get_name() {
        return 'sgp_customer_login';
    }

    public function get_title() {
        return __('SGP - Área do Cliente', 'sgp-integration');
    }

    public function get_icon() {
        return 'eicon-login';
    }

    public function get_categories() {
        return ['sgp-widgets'];
    }

    public function get_keywords() {
        return ['sgp', 'customer', 'login', 'área', 'cliente', 'painel'];
    }

    protected function register_controls() {
        
        // ============ CONTEÚDO ============
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Conteúdo', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_logo',
            [
                'label' => __('Exibir Logo', 'sgp-integration'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'sgp-integration'),
                'label_off' => __('Não', 'sgp-integration'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'custom_title',
            [
                'label' => __('Título Personalizado', 'sgp-integration'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => __('Deixe vazio para usar o padrão', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'custom_subtitle',
            [
                'label' => __('Subtítulo Personalizado', 'sgp-integration'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => __('Deixe vazio para usar o padrão', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'button_alignment',
            [
                'label' => __('Alinhamento do Botão', 'sgp-integration'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Esquerda', 'sgp-integration'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Centro', 'sgp-integration'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Direita', 'sgp-integration'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-actions' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_width',
            [
                'label' => __('Largura do Botão', 'sgp-integration'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'auto' => [
                        'title' => __('Automática', 'sgp-integration'),
                        'icon' => 'eicon-h-align-left',
                    ],
                    '100%' => [
                        'title' => __('Total', 'sgp-integration'),
                        'icon' => 'eicon-h-align-stretch',
                    ],
                ],
                'default' => '100%',
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'width: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'show_button_icon',
            [
                'label' => __('Exibir Ícone no Botão', 'sgp-integration'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Sim', 'sgp-integration'),
                'label_off' => __('Não', 'sgp-integration'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Texto do Botão', 'sgp-integration'),
                'type' => Controls_Manager::TEXT,
                'default' => 'Entrar',
                'placeholder' => __('Texto do botão', 'sgp-integration'),
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - CONTAINER ============
        $this->start_controls_section(
            'container_style',
            [
                'label' => __('Container', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_width',
            [
                'label' => __('Largura Máxima', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 300,
                        'max' => 800,
                        'step' => 10,
                    ],
                    '%' => [
                        'min' => 30,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 480,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-customer-login-container' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Espaçamento Interno', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-customer-login-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label' => __('Margem Externa', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-customer-login-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'container_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-customer-login-container',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-customer-login-container',
            ]
        );

        $this->add_responsive_control(
            'container_border_radius',
            [
                'label' => __('Arredondamento', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-customer-login-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-customer-login-container',
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - LOGO ============
        $this->start_controls_section(
            'logo_style',
            [
                'label' => __('Logo', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_logo' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'logo_size',
            [
                'label' => __('Tamanho do Logo', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 50,
                        'max' => 300,
                        'step' => 5,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-custom-logo img' => 'max-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sgp-tech-icon' => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}}{{UNIT}} / 2);',
                ],
            ]
        );

        $this->add_responsive_control(
            'logo_margin',
            [
                'label' => __('Margem', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-logo-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'logo_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-custom-logo, {{WRAPPER}} .sgp-tech-icon',
            ]
        );

        $this->add_responsive_control(
            'logo_border_radius',
            [
                'label' => __('Arredondamento', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-custom-logo' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sgp-tech-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'logo_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-custom-logo, {{WRAPPER}} .sgp-tech-icon',
                'fields_options' => [
                    'box_shadow_type' => [
                        'default' => '',
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - TÍTULOS ============
        $this->start_controls_section(
            'titles_style',
            [
                'label' => __('Títulos', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_heading',
            [
                'label' => __('Título Principal', 'sgp-integration'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-login-header h3',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Cor', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-login-header h3' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margem', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-login-header h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_heading',
            [
                'label' => __('Subtítulo', 'sgp-integration'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-login-header p',
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Cor', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-login-header p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => __('Margem', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-login-header p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - FORMULÁRIO ============
        $this->start_controls_section(
            'form_style',
            [
                'label' => __('Formulário', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'form_spacing',
            [
                'label' => __('Espaçamento entre Campos', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-group' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Labels
        $this->add_control(
            'labels_heading',
            [
                'label' => __('Labels', 'sgp-integration'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'labels_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-form-group label',
            ]
        );

        $this->add_control(
            'labels_color',
            [
                'label' => __('Cor', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-group label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'labels_margin',
            [
                'label' => __('Margem', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-group label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - INPUTS ============
        $this->start_controls_section(
            'inputs_style',
            [
                'label' => __('Campos de Input', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'inputs_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-input',
            ]
        );

        $this->add_responsive_control(
            'inputs_padding',
            [
                'label' => __('Espaçamento Interno', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Estados dos inputs
        $this->start_controls_tabs('inputs_tabs');

        $this->start_controls_tab(
            'inputs_normal',
            [
                'label' => __('Normal', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'inputs_text_color',
            [
                'label' => __('Cor do Texto', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'inputs_placeholder_color',
            [
                'label' => __('Cor do Placeholder', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-input::placeholder' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'inputs_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-input',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'inputs_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-input',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'inputs_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-input',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'inputs_focus',
            [
                'label' => __('Foco', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'inputs_focus_text_color',
            [
                'label' => __('Cor do Texto', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-input:focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'inputs_focus_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-input:focus',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'inputs_focus_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-input:focus',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'inputs_focus_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-input:focus',
            ]
        );

        $this->add_control(
            'inputs_focus_transform',
            [
                'label' => __('Transformação', 'sgp-integration'),
                'type' => Controls_Manager::TEXT,
                'default' => 'translateY(-2px)',
                'selectors' => [
                    '{{WRAPPER}} .sgp-input:focus' => 'transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'inputs_border_radius',
            [
                'label' => __('Arredondamento', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .sgp-input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - BOTÃO ============
        $this->start_controls_section(
            'button_style',
            [
                'label' => __('Botão', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-btn',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Espaçamento Interno', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'default' => [
                    'top' => '1',
                    'right' => '2',
                    'bottom' => '1',
                    'left' => '2',
                    'unit' => 'rem',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_min_width',
            [
                'label' => __('Largura Mínima', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 400,
                        'step' => 10,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'condition' => [
                    'button_width' => 'auto',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_margin',
            [
                'label' => __('Margem', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Estados do botão
        $this->start_controls_tabs('button_tabs');

        $this->start_controls_tab(
            'button_normal',
            [
                'label' => __('Normal', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __('Cor do Texto', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-btn',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-btn',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover',
            [
                'label' => __('Hover', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __('Cor do Texto', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_hover_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-btn:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_hover_border',
                'label' => __('Borda', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-btn:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_hover_shadow',
                'label' => __('Sombra', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-btn:hover',
            ]
        );

        $this->add_control(
            'button_hover_transform',
            [
                'label' => __('Transformação', 'sgp-integration'),
                'type' => Controls_Manager::TEXT,
                'default' => 'translateY(-2px)',
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn:hover' => 'transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => __('Arredondamento', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .sgp-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - LINKS ============
        $this->start_controls_section(
            'links_style',
            [
                'label' => __('Links', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'links_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-form-links a',
            ]
        );

        $this->add_responsive_control(
            'links_spacing',
            [
                'label' => __('Espaçamento', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Estados dos links
        $this->start_controls_tabs('links_tabs');

        $this->start_controls_tab(
            'links_normal',
            [
                'label' => __('Normal', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'links_color',
            [
                'label' => __('Cor', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'links_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-form-links a',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'links_hover',
            [
                'label' => __('Hover', 'sgp-integration'),
            ]
        );

        $this->add_control(
            'links_hover_color',
            [
                'label' => __('Cor', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'links_hover_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-form-links a:hover',
            ]
        );

        $this->add_control(
            'links_hover_transform',
            [
                'label' => __('Transformação', 'sgp-integration'),
                'type' => Controls_Manager::TEXT,
                'default' => 'translateY(-1px)',
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links a:hover' => 'transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'links_border_radius',
            [
                'label' => __('Arredondamento', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'links_padding',
            [
                'label' => __('Espaçamento Interno', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-links a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ============ ESTILO - RODAPÉ ============
        $this->start_controls_section(
            'footer_style',
            [
                'label' => __('Rodapé', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'footer_typography',
                'label' => __('Tipografia', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-form-footer, {{WRAPPER}} .sgp-login-footer',
            ]
        );

        $this->add_control(
            'footer_text_color',
            [
                'label' => __('Cor do Texto', 'sgp-integration'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-footer' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .sgp-login-footer' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'footer_background',
                'label' => __('Fundo', 'sgp-integration'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .sgp-form-footer, {{WRAPPER}} .sgp-login-footer',
            ]
        );

        $this->add_responsive_control(
            'footer_padding',
            [
                'label' => __('Espaçamento Interno', 'sgp-integration'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .sgp-form-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sgp-login-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'footer_border',
                'label' => __('Borda Superior', 'sgp-integration'),
                'selector' => '{{WRAPPER}} .sgp-form-footer, {{WRAPPER}} .sgp-login-footer',
            ]
        );

        $this->end_controls_section();

        // ============ AVANÇADO ============
        $this->start_controls_section(
            'advanced_style',
            [
                'label' => __('Avançado', 'sgp-integration'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'custom_css',
            [
                'label' => __('CSS Personalizado', 'sgp-integration'),
                'type' => Controls_Manager::CODE,
                'language' => 'css',
                'rows' => 10,
                'placeholder' => '/* Seu CSS personalizado aqui */',
            ]
        );

        $this->add_control(
            'animation_duration',
            [
                'label' => __('Duração da Animação (ms)', 'sgp-integration'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'ms' => [
                        'min' => 0,
                        'max' => 2000,
                        'step' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'ms',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sgp-input, {{WRAPPER}} .sgp-btn, {{WRAPPER}} .sgp-form-links a' => 'transition-duration: {{SIZE}}ms;',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // CSS personalizado
        if (!empty($settings['custom_css'])) {
            echo '<style>' . $settings['custom_css'] . '</style>';
        }

        // Adiciona classes personalizadas
        $classes = ['sgp-elementor-widget'];
        if ($settings['show_logo'] !== 'yes') {
            $classes[] = 'sgp-hide-logo';
        }
        if ($settings['show_button_icon'] !== 'yes') {
            $classes[] = 'sgp-hide-button-icon';
        }

        echo '<div class="' . implode(' ', $classes) . '">';

        // Se tem configurações personalizadas, modifica temporariamente
        if (!empty($settings['custom_title']) || !empty($settings['custom_subtitle']) || !empty($settings['button_text'])) {
            add_filter('sgp_customer_panel_title', function() use ($settings) {
                return !empty($settings['custom_title']) ? $settings['custom_title'] : __('Acesse sua Área do Cliente', 'sgp-integration');
            });
            
            add_filter('sgp_customer_panel_subtitle', function() use ($settings) {
                return !empty($settings['custom_subtitle']) ? $settings['custom_subtitle'] : __('Gerencie sua conta, visualize faturas e abra chamados', 'sgp-integration');
            });
            
            add_filter('sgp_customer_panel_button_text', function() use ($settings) {
                return !empty($settings['button_text']) ? $settings['button_text'] : __('Entrar', 'sgp-integration');
            });
        }

        // Renderiza o shortcode
        echo do_shortcode('[sgp_customer_panel]');

        echo '</div>';

        // CSS para esconder logo se necessário
        if ($settings['show_logo'] !== 'yes') {
            echo '<style>.sgp-hide-logo .sgp-logo-wrapper { display: none !important; }</style>';
        }
    }

    protected function content_template() {
        ?>
        <# if (settings.custom_css) { #>
            <style>{{{ settings.custom_css }}}</style>
        <# } #>
        
        <div class="sgp-elementor-widget">
            <div class="sgp-customer-login-container">
                <div class="sgp-login-header">
                    <# if (settings.show_logo === 'yes') { #>
                    <div class="sgp-logo-wrapper">
                        <div class="sgp-tech-icon">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="3"/>
                                <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                            </svg>
                        </div>
                    </div>
                    <# } #>
                    <h3>{{{ settings.custom_title || 'Acesse sua Área do Cliente' }}}</h3>
                    <p>{{{ settings.custom_subtitle || 'Gerencie sua conta, visualize faturas e abra chamados' }}}</p>
                </div>
                
                <div class="sgp-ajax-form">
                    <div class="sgp-form-group">
                        <label>CPF/CNPJ*</label>
                        <input type="text" class="sgp-input" placeholder="Seu CPF ou CNPJ" />
                    </div>
                    
                    <div class="sgp-form-group">
                        <label>Senha*</label>
                        <input type="password" class="sgp-input" placeholder="Sua senha" />
                    </div>
                    
                    <div class="sgp-form-group sgp-form-actions">
                        <button class="sgp-btn sgp-btn-primary">
                            <# if (settings.show_button_icon === 'yes') { #>
                            <span class="sgp-btn-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4m-5-4l5-5-5-5m5 5H3"/>
                                </svg>
                            </span>
                            <# } #>
                            <span class="sgp-btn-text">{{{ settings.button_text || 'Entrar' }}}</span>
                            <span class="sgp-btn-loading">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 12a9 9 0 11-6.219-8.56"/>
                                </svg>
                            </span>
                        </button>
                    </div>
                    
                    <div class="sgp-form-links">
                        <a href="#">Esqueci minha senha</a>
                        <span>•</span>
                        <a href="#">Precisa de ajuda?</a>
                    </div>
                </div>
                
                <div class="sgp-form-footer">
                    <p>Primeira vez? Entre com seu CPF/CNPJ e a senha fornecida pela empresa.</p>
                </div>
            </div>
        </div>
        <?php
    }
} 