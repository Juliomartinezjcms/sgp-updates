<?php
if (!defined('ABSPATH')) exit;

class SGP_Elementor_Duo_Form_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'sgp_duo_form';
    }
    public function get_title() {
        return __('SGP Formulário Duplo', 'sgp-integration');
    }
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    public function get_categories() {
        return ['sgp-widgets'];
    }
    public function get_keywords() {
        return ['sgp', 'duplo', 'etapas', 'form', 'lead', 'viabilidade'];
    }
    protected function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __('Conteúdo', 'sgp-integration'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('titulo_viabilidade', [
            'label' => __('Título da Etapa 1', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '1. Verifique a disponibilidade',
        ]);
        $this->add_control('titulo_lead', [
            'label' => __('Título da Etapa 2', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '2. Cadastre seu interesse',
        ]);
        $this->add_control('texto_botao_verificar', [
            'label' => __('Texto do botão de verificar', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Verificar disponibilidade',
        ]);
        $this->add_control('texto_botao_avancar', [
            'label' => __('Texto do botão de avançar', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Avançar',
        ]);
        $this->add_control('texto_botao_lead', [
            'label' => __('Texto do botão de lead', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Receber Atendimento',
        ]);
        $this->add_control('texto_termo', [
            'label' => __('Texto do termo (primeira etapa)', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::WYSIWYG,
            'default' => 'Concordo com o <a href="#">tratamento dos dados pessoais</a> e autorizo o contato para ofertas comerciais*',
        ]);
        $this->end_controls_section();

        // Seção de estilo geral
        $this->start_controls_section('style_section', [
            'label' => __('Estilo do Formulário', 'sgp-integration'),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        ]);
        
        // Largura do formulário
        $this->add_responsive_control('form_width', [
            'label' => __('Largura do formulário', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range' => [
                'px' => [
                    'min' => 300,
                    'max' => 1200,
                    'step' => 10,
                ],
                '%' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
                'vw' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'default' => [
                'unit' => '%',
                'size' => 100,
            ],
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]);
        
        $this->add_responsive_control('form_max_width', [
            'label' => __('Largura máxima do formulário', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'vw'],
            'range' => [
                'px' => [
                    'min' => 300,
                    'max' => 1200,
                    'step' => 10,
                ],
                '%' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
                'vw' => [
                    'min' => 10,
                    'max' => 100,
                    'step' => 1,
                ],
            ],
            'default' => [
                'unit' => 'px',
                'size' => 600,
            ],
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ]);
        
        // Fundo do formulário
        $this->add_control('form_bg_color', [
            'label' => __('Cor de fundo do formulário', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container' => 'background-color: {{VALUE}};',
            ],
        ]);
        $this->add_responsive_control('form_radius', [
            'label' => __('Borda arredondada do formulário', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->add_group_control(\Elementor\Group_Control_Box_Shadow::get_type(), [
            'name' => 'form_shadow',
            'selector' => '{{WRAPPER}} .sgp-duo-form-container',
        ]);
        // Título
        $this->add_control('titulo_color', [
            'label' => __('Cor do título', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container h3' => 'color: {{VALUE}};',
            ],
        ]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'titulo_typo',
            'selector' => '{{WRAPPER}} .sgp-duo-form-container h3',
        ]);
        // Labels
        $this->add_control('label_color', [
            'label' => __('Cor dos labels', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container label' => 'color: {{VALUE}};',
            ],
        ]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'label_typo',
            'selector' => '{{WRAPPER}} .sgp-duo-form-container label',
        ]);
        $this->add_responsive_control('label_margin', [
            'label' => __('Margem do label', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);
        $this->add_responsive_control('label_spacing', [
            'label' => __('Espaçamento entre label e campo', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ]);
        // Espaçamento entre grupos de campos
        $this->add_responsive_control('group_spacing', [
            'label' => __('Espaçamento entre grupos de campos', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-form-group' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ]);
        // Campos
        $this->add_control('input_bg_color', [
            'label' => __('Cor de fundo dos campos', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container input, {{WRAPPER}} .sgp-duo-form-container select' => 'background-color: {{VALUE}};',
            ],
        ]);
        $this->add_control('input_text_color', [
            'label' => __('Cor do texto dos campos', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container input, {{WRAPPER}} .sgp-duo-form-container select' => 'color: {{VALUE}};',
            ],
        ]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'input_typo',
            'selector' => '{{WRAPPER}} .sgp-duo-form-container input, {{WRAPPER}} .sgp-duo-form-container select',
        ]);
        $this->add_control('input_border_color', [
            'label' => __('Cor da borda dos campos', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container input, {{WRAPPER}} .sgp-duo-form-container select' => 'border-color: {{VALUE}};',
            ],
        ]);
        $this->add_responsive_control('input_radius', [
            'label' => __('Borda arredondada dos campos', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container input, {{WRAPPER}} .sgp-duo-form-container select' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
        ]);
        // Botões
        $this->add_control('button_alignment', [
            'label' => __('Alinhamento do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Esquerda', 'sgp-integration'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Centro', 'sgp-integration'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Direita', 'sgp-integration'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-form-actions' => 'text-align: {{VALUE}};',
            ],
        ]);
        $this->add_control('button_border_color', [
            'label' => __('Cor da borda do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'border-color: {{VALUE}};',
            ],
        ]);
        $this->add_responsive_control('button_border_width', [
            'label' => __('Espessura da borda do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'range' => [ 'px' => [ 'min' => 0, 'max' => 10 ] ],
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'border-width: {{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->add_responsive_control('button_margin_btn', [
            'label' => __('Margem do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);
        $this->add_control('button_bg_color', [
            'label' => __('Cor de fundo do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'background-color: {{VALUE}};',
            ],
        ]);
        $this->add_control('button_text_color', [
            'label' => __('Cor do texto do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'color: {{VALUE}};',
            ],
        ]);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(), [
            'name' => 'button_typo',
            'selector' => '{{WRAPPER}} .sgp-duo-form-container .sgp-button',
        ]);
        $this->add_responsive_control('button_radius', [
            'label' => __('Borda arredondada do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->add_responsive_control('form_padding', [
            'label' => __('Espaçamento interno do formulário', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);
        $this->add_responsive_control('button_padding', [
            'label' => __('Padding do botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);
        
        // Seção de efeitos especiais
        $this->add_control('effects_section_divider', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ]);
        
        $this->add_control('effects_section_heading', [
            'label' => __('Efeitos Especiais do Botão', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ]);
        
        // Cor do hover do botão
        $this->add_control('button_hover_bg_color', [
            'label' => __('Cor de fundo do botão (hover)', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button:hover' => 'background-color: {{VALUE}};',
            ],
        ]);
        
        // Cor da sombra do hover
        $this->add_control('button_hover_shadow_color', [
            'label' => __('Cor da sombra do botão (hover)', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container .sgp-button:hover' => 'box-shadow: 0 4px 12px {{VALUE}};',
            ],
        ]);
        
        // Cor de fundo do botão "Avançar"
        $this->add_control('button_next_bg_color', [
            'label' => __('Cor de fundo do botão "Avançar"', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'description' => __('Cor que aparece quando o botão muda para "Avançar"', 'sgp-integration'),
        ]);
        
        // Cor secundária do gradiente do botão "Avançar"
        $this->add_control('button_next_bg_color_secondary', [
            'label' => __('Cor secundária do botão "Avançar"', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'description' => __('Segunda cor do gradiente do botão "Avançar"', 'sgp-integration'),
        ]);
        
        // Cor do efeito pulse do botão "Avançar"
        $this->add_control('button_next_pulse_color', [
            'label' => __('Cor do efeito pulse do botão "Avançar"', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'description' => __('Cor do efeito de pulso ao redor do botão "Avançar"', 'sgp-integration'),
        ]);
        
        // Efeito Neon
        $this->add_control('neon_section_divider', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
        ]);
        
        $this->add_control('neon_section_heading', [
            'label' => __('Efeito Neon dos Botões', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ]);
        
        // Ativar efeito neon
        $this->add_control('button_neon_enable', [
            'label' => __('Ativar efeito neon', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Sim', 'sgp-integration'),
            'label_off' => __('Não', 'sgp-integration'),
            'return_value' => 'yes',
            'default' => '',
        ]);
        
        // Cor do brilho neon
        $this->add_control('button_neon_color', [
            'label' => __('Cor do brilho neon', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::COLOR,
            'description' => __('Cor do efeito de brilho neon dos botões', 'sgp-integration'),
            'condition' => [
                'button_neon_enable' => 'yes',
            ],
        ]);
        
        // Intensidade do brilho
        $this->add_control('button_neon_intensity', [
            'label' => __('Intensidade do brilho neon', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 5,
                    'max' => 30,
                    'step' => 1,
                ],
            ],
            'default' => [
                'size' => 15,
            ],
            'condition' => [
                'button_neon_enable' => 'yes',
            ],
        ]);
        
        // Animação do neon (pulsação)
        $this->add_control('button_neon_animation', [
            'label' => __('Animação do neon', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Sim', 'sgp-integration'),
            'label_off' => __('Não', 'sgp-integration'),
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => [
                'button_neon_enable' => 'yes',
            ],
        ]);
        
        // Título
        $this->add_control('titulo_alignment', [
            'label' => __('Alinhamento do título', 'sgp-integration'),
            'type' => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Esquerda', 'sgp-integration'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Centro', 'sgp-integration'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Direita', 'sgp-integration'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .sgp-duo-form-container h3' => 'text-align: {{VALUE}};',
            ],
        ]);
        $this->end_controls_section();
    }
    protected function render() {
        $settings = $this->get_settings_for_display();
        // Passa as opções para o template
        set_query_var('sgp_duo_form_opts', $settings);
        include SGP_INTEGRATION_PATH . 'templates/duo-form.php';
        set_query_var('sgp_duo_form_opts', null);
    }
} 