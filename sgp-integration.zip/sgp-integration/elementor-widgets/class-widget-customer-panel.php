<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SGP_Elementor_Customer_Panel_Widget extends \Elementor\Widget_Base {
    public function get_name() {
        return 'sgp_customer_panel';
    }
    public function get_title() {
        return __( 'Painel do Cliente SGP', 'sgp-integration' );
    }
    public function get_icon() {
        return 'eicon-lock-user';
    }
    public function get_categories() {
        return [ 'sgp-widgets' ];
    }
    protected function _register_controls() {
        $this->start_controls_section('section_style', [
            'label' => __( 'Estilo', 'sgp-integration' ),
            'tab' => \Elementor\Controls_Manager::TAB_STYLE,
        ]);
        $this->add_control('panel_bg_color', [
            'label' => __( 'Cor de Fundo', 'sgp-integration' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .sgp-customer-panel-container' => 'background-color: {{VALUE}};',
            ],
        ]);
        $this->add_control('panel_border_radius', [
            'label' => __( 'Arredondamento', 'sgp-integration' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range' => [ 'px' => [ 'min' => 0, 'max' => 50 ] ],
            'selectors' => [
                '{{WRAPPER}} .sgp-customer-panel-container' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
        ]);
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'panel_typography',
                'selector' => '{{WRAPPER}} .sgp-customer-panel-container',
            ]
        );
        $this->end_controls_section();
    }
    protected function render() {
        echo '<div class="sgp-customer-panel-container">';
        echo do_shortcode('[sgp_customer_panel]');
        echo '</div>';
    }
} 