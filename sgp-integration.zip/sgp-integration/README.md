# SGP Integration - Plugin WordPress

Integração completa entre WordPress e o Sistema de Gerenciamento de Provedores (SGP).

## 📋 Descrição

Este plugin oferece uma integração completa entre WordPress e o Sistema de Gerenciamento de Provedores (SGP), permitindo:

- Consulta de disponibilidade de serviços por CEP
- Gerenciamento de leads com validação completa
- Área do cliente com login integrado
- Painel administrativo completo
- Sistema de cache inteligente
- Logs detalhados de todas as operações

## 🚀 Funcionalidades

### Para Visitantes
- **Consulta de Disponibilidade**: Verificar se há cobertura no endereço
- **Formulário de Lead**: Solicitar informações sobre planos disponíveis
- **Lista de Planos**: Visualizar planos disponíveis por região

### Para Clientes
- **Login Seguro**: Autenticação integrada com o SGP
- **Área do Cliente**: Dashboard completo com:
  - Visualização de faturas
  - Abertura de chamados
  - Atualização de perfil
  - Solicitação de mudança de plano
- **Recuperação de Senha**: Sistema integrado de recuperação

### Para Administradores
- **Configurações da API**: Interface para configurar credenciais
- **Gerenciamento de Leads**: Visualizar e exportar leads
- **Relatórios**: Estatísticas detalhadas do sistema
- **Cache Management**: Controle de cache da API
- **Logs**: Sistema de logs para debugging

## 📦 Instalação

1. Faça upload do plugin para `/wp-content/plugins/sgp-integration/`
2. Ative o plugin através do menu 'Plugins' no WordPress
3. Configure as credenciais da API em **SGP Integration > Configurações**
4. Use os shortcodes disponíveis em suas páginas

## ⚙️ Configuração

### Configurações da API
1. Acesse **SGP Integration > Configurações**
2. Preencha:
   - **URL da API SGP**: URL base da API
   - **Token da API**: Token de acesso
3. Teste a conexão usando o botão "Testar Conexão"
4. Salve as configurações

### Configurações Gerais
- **Armazenar leads localmente**: Salva leads no WordPress
- **Ativar logs**: Registra todas as operações
- **Tempo de Cache**: Define duração do cache (300-86400 segundos)
- **E-mail de Notificação**: Recebe notificações de novos leads

## 🎯 Shortcodes Disponíveis

### `[sgp_customer_panel]`
Exibe o painel do cliente com login integrado.

**Parâmetros:**
- `show_login="true|false"` - Mostra formulário de login (padrão: true)
- `redirect_url="url"` - URL de redirecionamento após login

**Exemplo:**
```
[sgp_customer_panel show_login="true" redirect_url="/minha-conta"]
```

### `[sgp_availability_form]`
Formulário para consulta de disponibilidade.

**Parâmetros:**
- `show_plans="true|false"` - Mostra planos disponíveis (padrão: true)
- `redirect_url="url"` - URL após envio do formulário

**Exemplo:**
```
[sgp_availability_form show_plans="true"]
```

### `[sgp_plan_list]`
Lista de planos disponíveis.

**Parâmetros:**
- `cep="00000000"` - CEP para filtrar planos
- `show_prices="true|false"` - Mostra preços (padrão: true)
- `show_features="true|false"` - Mostra recursos (padrão: true)

**Exemplo:**
```
[sgp_plan_list cep="12345678" show_prices="true"]
```

## 🔧 API Endpoints

O plugin integra com os seguintes endpoints da API SGP:

### Autenticação
- `POST /api/login` - Login da API
- `POST /api/customer/login` - Login do cliente
- `POST /api/customer/password-recovery` - Recuperação de senha

### Cobertura e Planos
- `POST /api/coverage/check` - Consulta de disponibilidade
- `GET /api/plans` - Lista de planos disponíveis

### Leads
- `POST /api/leads/create` - Criação de lead
- `GET /api/leads/check` - Verificar lead existente

### Cliente
- `GET /api/customer/invoices` - Faturas do cliente
- `GET /api/customer/tickets` - Chamados do cliente
- `POST /api/customer/tickets/create` - Criar chamado
- `PUT /api/customer/profile` - Atualizar perfil
- `POST /api/customer/plan-change` - Solicitar mudança de plano

## 🛡️ Segurança

### Medidas Implementadas
- **Rate Limiting**: Limite de tentativas de login
- **CSRF Protection**: Tokens de segurança em todos os formulários
- **Input Sanitization**: Sanitização de todos os dados de entrada
- **Role-based Access**: Controle de acesso por tipo de usuário
- **Secure Cookies**: Cookies seguros para autenticação

### Configurações de Segurança
- `SGP_LOGIN_ATTEMPTS_LIMIT`: Limite de tentativas (padrão: 5)
- `SGP_LOGIN_TIMEOUT`: Tempo de bloqueio (padrão: 15 minutos)
- `SGP_AUTH_COOKIE`: Nome do cookie de autenticação

## 📊 Cache System

### Tipos de Cache
- **Autenticação**: Token de API (1 hora)
- **Cobertura**: Consultas por CEP (configurável)
- **Planos**: Lista de planos por região (configurável)

### Gerenciamento
- Cache automático com expiração
- Limpeza manual via painel administrativo
- Cache inteligente baseado em parâmetros

## 📝 Logs

### Tipos de Log
- **Info**: Operações normais
- **Warning**: Avisos e alertas
- **Error**: Erros e falhas

### Configuração
- Ativação/desativação via painel
- Logs de erro críticos sempre ativos
- Filtros para controle granular

## 🔄 Hooks e Filtros

### Actions
```php
// Log de eventos
do_action('sgp_integration_log', $log_entry);

// Lead criado
do_action('sgp_lead_created', $lead_data, $api_response);

// Cliente logado
do_action('sgp_customer_logged_in', $user_id, $customer_data);
```

### Filters
```php
// Controle de logs
apply_filters('sgp_integration_enable_logging', true);

// Validação de dados
apply_filters('sgp_validate_lead_data', $data);

// Personalização de mensagens
apply_filters('sgp_custom_messages', $messages);
```

## 🐛 Troubleshooting

### Problemas Comuns

**1. Erro de conexão com API**
- Verifique as credenciais da API
- Teste a conexão no painel administrativo
- Verifique se a URL da API está correta

**2. Formulários não funcionam**
- Verifique se o JavaScript está carregado
- Confirme se os nonces estão sendo gerados
- Verifique os logs de erro

**3. Cache não atualiza**
- Limpe o cache manualmente
- Verifique o tempo de cache configurado
- Confirme se os transients estão funcionando

### Debug Mode
Para ativar logs detalhados, adicione ao `wp-config.php`:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

## 📈 Performance

### Otimizações
- Cache inteligente de consultas
- Lazy loading de scripts
- Minificação de assets
- Compressão de respostas

### Monitoramento
- Estatísticas de uso no painel
- Logs de performance
- Métricas de cache hit/miss

## 🔄 Atualizações

### Versão 1.0.0
- ✅ Integração completa com API SGP
- ✅ Sistema de autenticação de clientes
- ✅ Gerenciamento de leads
- ✅ Painel administrativo
- ✅ Sistema de cache
- ✅ Logs detalhados
- ✅ Validações de segurança

## 📞 Suporte

Para suporte técnico ou dúvidas:
- **Autor**: Julio César Martinez @juliomartinez_jcms
- **Versão**: 1.0.0
- **Licença**: GPL-2.0+

## 📄 Licença

Este plugin é licenciado sob GPL v2 ou posterior.

---

**SGP Integration** - Integração completa e segura entre WordPress e SGP.

## Como funciona

- Integração com a API SGP via token fixo (campo obrigatório em todas as requisições)
- Todas as requisições enviam o token como campo do formulário (form-data)
- Exemplo de chamada:

```php
$response = wp_remote_post('https://demo.sgp.net.br/api/ura/fatura2via/', [
    'body' => [
        'token' => 'SEU_TOKEN_AQUI',
        'app' => 'fortics',
        'contrato' => '308'
    ]
]);
```

## Configuração

- No painel do WordPress, vá em SGP > Configurações
- Preencha a URL da API (ex: https://demo.sgp.net.br)
- Preencha o Token da API (fornecido pela SGP)

## Exemplos de uso

### Segunda via de fatura
```php
$sgp = new SGP_API_Client();
$sgp->set_api_url('https://demo.sgp.net.br');
$sgp->set_api_token('SEU_TOKEN_AQUI');
$response = $sgp->get_fatura_segunda_via('308');
```

### Enviar fatura
```php
$response = $sgp->enviar_fatura('313');
```

## Observações
- Consulte a documentação oficial da API SGP para detalhes de cada endpoint: https://documenter.getpostman.com/view/6682240/Tz5s5whG#a121c02f-2290-4904-9d07-16a3dfe748bc
- O plugin pode ser facilmente estendido para outros endpoints seguindo o padrão acima.

# SGP Integrado - Consulta de Viabilidade

## Como funciona

- O cliente informa o CEP no formulário ([sgp_availability_form])
- O plugin converte o CEP em latitude/longitude usando a chave do Google Maps
- Busca todas as CTOs via API SGP (Basic Auth)
- Geocodifica o endereço de cada CTO
- Calcula a distância entre o cliente e cada CTO
- Se houver CTO a até 300 metros, retorna "Atendemos!"
- Caso contrário, retorna "Fora da área de cobertura"

## Configuração

- No painel do WordPress, vá em SGP Integrado > Configurações
- Preencha:
  - URL da API SGP
  - Token da API SGP
  - Usuário SGP (Basic Auth)
  - Senha SGP (Basic Auth)
  - Chave da API Google Maps

## Exemplo de uso no código

```php
$sgp = new SGP_API_Client();
$sgp->set_api_url('https://demo.sgp.net.br');
$sgp->set_api_token('SEU_TOKEN_AQUI');
$response = $sgp->consulta_viabilidade('01001000');
if (!empty($response['atende'])) {
    echo 'Atendemos!';
} else {
    echo 'Fora da área de cobertura.';
}
```
