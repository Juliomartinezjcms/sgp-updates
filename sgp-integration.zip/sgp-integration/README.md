# SGP Integrado - Plugin WordPress

## 🚀 Integração Completa WordPress + API Central SGP Real

**Versão:** 2.7.0 - API Central SGP Real  
**Autor:** Julio César Martinez @juliomartinez_jcms  
**Licença:** GPL-2.0+  
**Compatibilidade:** WordPress 5.0+ | PHP 7.4+  

---

## 📋 Descrição

O **SGP Integrado** é um plugin WordPress avançado que oferece integração completa e em tempo real com o **Sistema de Gerenciamento de Provedores (SGP)** através da **API Central Real**. Desenvolvido com arquitetura modular, oferece uma solução completa para provedores de internet que utilizam o SGP.

### ✨ Principais Características
- 🔗 **API Central SGP Real** - Integração direta com endpoints oficiais
- 🎨 **5 Widgets Elementor** - Interface moderna e customizável
- 🔐 **Sistema de Licença Comercial** - Validação remota de licenças
- 📊 **Painel Administrativo Completo** - Relatórios e configurações
- 👥 **Área do Cliente Avançada** - Dashboard completo com contratos reais
- 🛡️ **Segurança Avançada** - Rate limiting, headers de segurança, autenticação robusta

---

## 🎯 Funcionalidades Principais

### 🌐 **Para Visitantes**
- **Formulário Duplo**: Viabilidade + Lead em etapas
- **Consulta de Viabilidade**: Verificação automática por CEP via Google Maps
- **Busca Automática de CEP**: Integração com ViaCEP
- **Lista de Planos**: Visualização de planos disponíveis
- **Efeitos Visuais**: Interface moderna com efeitos neon

### 👤 **Para Clientes SGP**
- **Login com CPF/CNPJ**: Autenticação direta com credenciais SGP
- **Dashboard Completo**: Contratos, faturas, chamados em tempo real
- **Gerenciamento de Chamados**: Criar, atualizar e acompanhar tickets
- **Funcionalidades Financeiras**: 2ª via, PIX, verificação de acesso
- **Recuperação de Senha**: Sistema integrado de recuperação

### ⚙️ **Para Administradores**
- **Configurações Avançadas**: API, segurança, cache, logs
- **Relatórios Detalhados**: Gráficos Chart.js, filtros, exportação CSV
- **Gerenciamento de Leads**: Visualização e exportação
- **Sistema de Logs**: Debug completo de todas as operações
- **Cache Management**: Controle granular de cache

---

## 🎨 Widgets Elementor

### 1. **Formulário Duplo** (`SGP_Elementor_Duo_Form_Widget`)
- Formulário em duas etapas: viabilidade + lead
- Efeitos neon e transições suaves
- Validações em tempo real
- Busca automática de CEP

### 2. **Formulário de Viabilidade** (`SGP_Elementor_Availability_Form_Widget`)
- Consulta de cobertura por CEP
- Integração com Google Maps
- Cálculo de distância automático
- Resultados em tempo real

### 3. **Painel do Cliente** (`SGP_Elementor_Customer_Panel_Widget`)
- Dashboard completo do cliente
- Contratos, faturas, chamados
- Interface responsiva e moderna
- Funcionalidades AJAX

### 4. **Login do Cliente** (`SGP_Elementor_Customer_Login_Widget`)
- Formulário de login com CPF/CNPJ
- Máscaras JavaScript
- Recuperação de senha
- Modal de recuperação

### 5. **Lista de Planos** (`SGP_Elementor_Plan_List_Widget`)
- Exibição de planos disponíveis
- Comparação de planos
- Filtros por região
- Template customizável

---

## 🔗 API Central SGP Real

### **Endpoints Implementados**

#### **Autenticação e Acesso**
- `POST /api/central/verificar_acesso` - Verificação de acesso
- `POST /api/central/login` - Login com CPF/CNPJ + senha

#### **Contratos e Dados**
- `POST /api/central/listar_contratos` - Lista de contratos do cliente
- `POST /api/central/buscar_contratos_detalhados` - Contratos com detalhes completos
- `POST /api/central/listar_titulos` - Títulos e faturas

#### **Chamados e Suporte**
- `POST /api/central/listar_chamados` - Lista de chamados
- `POST /api/central/criar_chamado` - Criação de novo chamado
- `POST /api/central/atualizar_chamado` - Atualização de chamado
- `POST /api/central/criar_anotacao_chamado` - Adicionar anotação

#### **Funcionalidades Financeiras**
- `POST /api/central/fatura_segunda_via` - 2ª via de fatura
- `POST /api/central/gerar_pix` - Geração de PIX

### **Características da API**
- **Autenticação**: CPF/CNPJ + senha (não mais email)
- **Formato**: POST com form-data
- **Respostas**: JSON e HTML tratados
- **Logs**: Debug específico para API SGP
- **Cache**: Inteligente com expiração configurável

---

## 📦 Instalação

### **Requisitos do Sistema**
- WordPress 5.0 ou superior
- PHP 7.4 ou superior
- MySQL 5.6 ou superior
- Elementor (recomendado)

### **Passos de Instalação**
1. **Upload do Plugin**
   ```bash
   # Via FTP/SFTP
   Upload para: /wp-content/plugins/sgp-integration/
   
   # Via Admin WordPress
   Plugins > Adicionar Novo > Enviar Plugin
   ```

2. **Ativação**
   - Acesse **Plugins > SGP Integrado**
   - Clique em **Ativar**

3. **Configuração Inicial**
   - Acesse **SGP Integrado > Configurações**
   - Configure as credenciais da API Central SGP
   - Teste a conexão

4. **Licenciamento**
   - Configure sua licença comercial
   - Validação remota automática

---

## ⚙️ Configuração

### **Configurações da API Central SGP**

#### **Credenciais Principais**
```php
// Configurações obrigatórias
'sgp_api_url' => 'https://seu-sgp.com.br',
'sgp_api_cpfcnpj' => '12345678901',
'sgp_api_password' => 'senha_segura',
```

#### **Configurações Avançadas**
- **Google Maps Key**: Para consultas de viabilidade
- **ViaCEP**: Busca automática de CEP
- **Distância de Cobertura**: Padrão 200m (configurável)

### **Configurações de Segurança**
```php
// Segurança avançada
'sgp_force_https' => true,
'sgp_security_headers' => true,
'sgp_ip_whitelist' => '192.168.1.1,10.0.0.1',
'sgp_login_attempts_limit' => 5,
'sgp_login_timeout' => 900, // 15 minutos
```

### **Configurações de Cache**
- **Tempo de Cache**: 3600 segundos (1 hora)
- **Cache de API**: Automático com expiração
- **Transients**: Gerenciamento inteligente

---

## 🎯 Shortcodes e Widgets

### **Shortcodes Disponíveis**

#### **Painel do Cliente**
```php
[sgp_customer_panel show_login="true" redirect_url="/area-do-cliente"]
```

#### **Formulário Duplo**
```php
[sgp_duo_form show_plans="true" redirect_url="/obrigado"]
```

#### **Consulta de Viabilidade**
```php
[sgp_availability_form show_plans="true"]
```

#### **Lista de Planos**
```php
[sgp_plan_list cep="12345678" show_prices="true"]
```

### **Widgets Elementor**
- **Categoria**: SGP (ícone: fa fa-plug)
- **5 Widgets**: Todos customizáveis via interface
- **Responsivos**: Funcionam em todos os dispositivos
- **AJAX**: Operações assíncronas

---

## 🛡️ Sistema de Segurança

### **Medidas Implementadas**

#### **Autenticação e Autorização**
- **Rate Limiting**: 5 tentativas, bloqueio de 15 minutos
- **Cookies Seguros**: Autenticação com cookies criptografados
- **Nonces**: Proteção CSRF em todos os formulários
- **Role-based Access**: Controle granular de permissões

#### **Headers de Segurança**
```http
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: default-src 'self'
```

#### **Validação de Dados**
- **Sanitização**: Todos os inputs sanitizados
- **Escape**: Output seguro em todas as saídas
- **Validação**: Regras específicas por campo
- **Máscaras**: JavaScript para formatação

### **Configurações de Segurança**
- **Força HTTPS**: Redirecionamento automático
- **Whitelist de IPs**: Controle de acesso por IP
- **2FA**: Autenticação de dois fatores (opcional)
- **Session Timeout**: Timeout configurável de sessão

---

## 📊 Painel Administrativo

### **Funcionalidades Principais**

#### **Dashboard**
- **Estatísticas Gerais**: Leads, consultas, clientes
- **Gráficos Chart.js**: Visualização de dados
- **Filtros por Período**: Análise temporal
- **Exportação CSV**: Relatórios exportáveis

#### **Configurações**
- **API Central SGP**: Credenciais e endpoints
- **Segurança**: Headers, IPs, rate limiting
- **Cache**: Tempo e gerenciamento
- **Logs**: Ativação e configuração

#### **Relatórios**
- **Leads**: Análise de conversão
- **Consultas**: Estatísticas de viabilidade
- **Clientes**: Atividade e engajamento
- **Performance**: Métricas de sistema

### **Sistema de Logs**
- **Logs de API**: Requisições e respostas
- **Logs de Segurança**: Tentativas de login
- **Logs de Erro**: Debug completo
- **Logs de Performance**: Métricas de tempo

---

## 🔄 Hooks e Filtros

### **Actions Disponíveis**
```php
// Eventos de lead
do_action('sgp_lead_created', $lead_data, $api_response);
do_action('sgp_lead_updated', $lead_id, $new_data);

// Eventos de cliente
do_action('sgp_customer_logged_in', $user_id, $customer_data);
do_action('sgp_customer_logged_out', $user_id);

// Eventos de API
do_action('sgp_api_request', $endpoint, $data);
do_action('sgp_api_response', $endpoint, $response);

// Eventos de cache
do_action('sgp_cache_cleared', $cache_type);
do_action('sgp_cache_updated', $cache_key, $data);
```

### **Filters Disponíveis**
```php
// Controle de logs
apply_filters('sgp_integration_enable_logging', true);
apply_filters('sgp_log_level', 'info');

// Validação de dados
apply_filters('sgp_validate_lead_data', $data);
apply_filters('sgp_validate_customer_data', $data);

// Personalização de mensagens
apply_filters('sgp_custom_messages', $messages);
apply_filters('sgp_error_messages', $errors);

// Configurações de cache
apply_filters('sgp_cache_time', 3600);
apply_filters('sgp_cache_enabled', true);
```

---

## 🐛 Troubleshooting

### **Problemas Comuns**

#### **1. Erro de Conexão com API SGP**
```php
// Verificar logs
error_log('SGP API Error: ' . $response['error']);

// Soluções:
// - Verificar credenciais CPF/CNPJ e senha
// - Confirmar URL da API
// - Verificar conectividade de rede
// - Consultar logs de debug
```

#### **2. Widgets Elementor Não Aparecem**
```php
// Verificar se Elementor está ativo
if (!class_exists('\Elementor\Plugin')) {
    return;
}

// Soluções:
// - Ativar plugin Elementor
// - Verificar versão do Elementor (3.0+)
// - Limpar cache do Elementor
```

#### **3. Formulários Não Funcionam**
```php
// Verificar JavaScript
console.log('SGP Integration:', sgpIntegrationVars);

// Soluções:
// - Verificar se JS está carregado
// - Confirmar nonces válidos
// - Verificar logs de erro
// - Testar em modo debug
```

#### **4. Cache Não Atualiza**
```php
// Limpar cache manualmente
wp_cache_flush();
delete_transient('sgp_cache_key');

// Soluções:
// - Limpar cache via painel admin
// - Verificar tempo de cache
// - Forçar atualização
```

### **Modo Debug**
```php
// Ativar logs detalhados
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('SGP_DEBUG', true);

// Logs específicos do SGP
error_log('[SGP_DEBUG] API Request: ' . json_encode($request));
error_log('[SGP_DEBUG] API Response: ' . json_encode($response));
```

---

## 📈 Performance e Otimização

### **Otimizações Implementadas**

#### **Cache Inteligente**
- **Cache de API**: Respostas da API Central SGP
- **Cache de Consultas**: Viabilidade por CEP
- **Cache de Usuários**: Dados de clientes
- **Transients**: Dados temporários

#### **Carregamento Otimizado**
- **Lazy Loading**: Scripts carregados sob demanda
- **Minificação**: CSS e JS otimizados
- **Compressão**: Respostas comprimidas
- **CDN Ready**: Compatível com CDNs

#### **Banco de Dados**
- **Índices Otimizados**: Consultas rápidas
- **Limpeza Automática**: Dados antigos removidos
- **Transações**: Operações atômicas
- **Prepared Statements**: Consultas seguras

### **Métricas de Performance**
- **Tempo de Carregamento**: < 2 segundos
- **Tamanho de Assets**: < 500KB total
- **Requisições HTTP**: Mínimas
- **Cache Hit Rate**: > 80%

---

## 🔄 Atualizações

### **Versão 2.7.0 - API Central Real**
- ✅ **API Central SGP Real** integrada
- ✅ **Autenticação CPF/CNPJ** (substitui email)
- ✅ **5 Widgets Elementor** completos
- ✅ **Sistema de licença comercial**
- ✅ **Primeira etapa de melhorias** implementada
- ✅ **Erro crítico de endereço** corrigido
- ✅ **MODO DE TESTE REMOVIDO**

### **Versão 2.6.0 - Melhorias de Interface**
- ✅ Sistema de slides com dots
- ✅ Gráfico de pizza funcional
- ✅ Detalhes simplificados na tabela
- ✅ Filtros de data avançados

### **Versão 2.5.0 - API Central**
- ✅ Integração com API Central SGP
- ✅ Métodos de contratos, títulos, chamados
- ✅ Funcionalidades financeiras
- ✅ Sistema de usuários baseado em CPF/CNPJ

### **Versão 2.0.0 - Reestruturação**
- ✅ Arquitetura modular
- ✅ Widgets Elementor
- ✅ Sistema de cache avançado
- ✅ Segurança robusta

---

## 📞 Suporte e Licenciamento

### **Informações de Contato**
- **Autor**: Julio César Martinez @juliomartinez_jcms
- **Website**: juliocesarmartinez.com.br
- **Versão**: 2.7.0 - API Central SGP Real
- **Licença**: GPL-2.0+ (comercial disponível)

### **Sistema de Licenciamento**
- **Validação Remota**: juliocesarmartinez.com.br
- **Licença Comercial**: Para uso em produção
- **Atualizações**: Automáticas via GitHub
- **Suporte**: Técnico especializado

### **Documentação**
- **Documentação Completa**: Pasta `/DOCS/`
- **Exemplos de Uso**: Incluídos no código
- **Tutoriais**: Disponíveis no website
- **FAQ**: Perguntas frequentes

---

## 📄 Licença

Este plugin é licenciado sob **GPL v2 ou posterior**.

### **Uso Comercial**
Para uso comercial ou em produção, é necessária uma licença comercial válida.

### **Redistribuição**
O código pode ser modificado e redistribuído, mantendo a licença GPL.

---

## 🚀 Próximas Versões

### **Segunda Etapa de Melhorias**
- 🔄 Funcionalidades específicas por contrato
- 🔄 Interface aprimorada
- 🔄 Experiência do usuário otimizada

### **Terceira Etapa**
- 🔄 Otimizações de performance
- 🔄 Sistema de cache avançado
- 🔄 Métricas detalhadas

### **Quarta Etapa**
- 🔄 Testes finais
- 🔄 Validação completa
- 🔄 Documentação final

---

**SGP Integrado v2.7.0** - A solução mais completa e avançada para integração WordPress + SGP com API Central Real.

*Desenvolvido com ❤️ por Julio César Martinez*
