<?php
/**
 * Plugin Name: SGP Integrado
 * Description: Integração completa entre WordPress e o Sistema de Gerenciamento de Provedores (SGP)
 * Version: 2.4.1
 * Author: Julio César Martinez @juliomartinez_jcms
 * License: GPL-2.0+
 * Text Domain: sgp-integration
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

// ==================== CONSTANTES DO PLUGIN ====================
define('SGP_INTEGRATION_VERSION', '2.4.1');
define('SGP_INTEGRATION_PATH', plugin_dir_path(__FILE__));
define('SGP_INTEGRATION_URL', plugin_dir_url(__FILE__));
define('SGP_INTEGRATION_API_CACHE_TIME', 3600); // 1 hora em segundos

// Segurança e Login
define('SGP_LOGIN_ATTEMPTS_LIMIT', 5); // Tentativas antes de bloquear
define('SGP_LOGIN_TIMEOUT', 15 * MINUTE_IN_SECONDS); // Tempo de bloqueio
define('SGP_AUTH_COOKIE', 'sgp_secure_auth'); // Nome do cookie de autenticação

// Configurações de Segurança Avançada
define('SGP_FORCE_HTTPS', get_option('sgp_force_https', false)); // Força HTTPS
define('SGP_SECURITY_HEADERS', get_option('sgp_security_headers', true)); // Headers de segurança
define('SGP_IP_WHITELIST', get_option('sgp_ip_whitelist', '')); // Whitelist de IPs

// ==================== CARREGAMENTO DE ARQUIVOS ====================
require_once SGP_INTEGRATION_PATH . 'includes/class-sgp-integration.php';
require_once SGP_INTEGRATION_PATH . 'includes/api/class-sgp-api-client.php';
require_once SGP_INTEGRATION_PATH . 'includes/class-lead-manager.php';
require_once SGP_INTEGRATION_PATH . 'includes/class-customer-panel.php';
require_once SGP_INTEGRATION_PATH . 'includes/admin/class-sgp-admin.php';

// ==================== HOOKS DE SEGURANÇA ====================
add_action('init', 'sgp_integration_security_checks');
add_action('send_headers', 'sgp_integration_security_headers');

function sgp_integration_security_checks() {
    // Força HTTPS se configurado
    if (SGP_FORCE_HTTPS && !is_ssl() && !WP_DEBUG) {
        wp_redirect('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
        exit;
    }
    
    // Verifica whitelist de IPs
    if (!empty(SGP_IP_WHITELIST)) {
        $allowed_ips = explode(',', SGP_IP_WHITELIST);
        $client_ip = $_SERVER['REMOTE_ADDR'];
        if (!in_array(trim($client_ip), array_map('trim', $allowed_ips))) {
            wp_die(__('Acesso negado por IP.', 'sgp-integration'));
        }
    }
    
    // Redireciona clientes SGP que tentam acessar o admin
    if (is_user_logged_in() && !wp_doing_ajax() && is_admin()) {
        $user = wp_get_current_user();
        if (in_array('sgp_customer', $user->roles)) {
            wp_redirect(home_url('/area-do-cliente'));
            exit;
        }
    }
    
    // Verifica tentativas de login suspeitas
    if (isset($_POST['action']) && $_POST['action'] === 'customer_login') {
        $transient_name = 'sgp_login_attempts_' . $_SERVER['REMOTE_ADDR'];
        $attempts = get_transient($transient_name) ?: 0;
        
        if ($attempts >= SGP_LOGIN_ATTEMPTS_LIMIT) {
            status_header(403);
            wp_send_json_error([
                'message' => __('Muitas tentativas. Tente novamente mais tarde.', 'sgp-integration')
            ]);
        }
    }
}

function sgp_integration_security_headers() {
    // Não envia headers no admin, AJAX, REST ou editor Elementor
    if (
        is_admin() ||
        (defined('DOING_AJAX') && DOING_AJAX) ||
        (defined('REST_REQUEST') && REST_REQUEST) ||
        (isset($_GET['elementor-preview']) || (defined('ELEMENTOR_VERSION') && isset($_GET['action']) && $_GET['action'] === 'elementor'))
    ) {
        return;
    }
    if (SGP_SECURITY_HEADERS) {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';");
    }
}

// ==================== INICIALIZAÇÃO DO PLUGIN ====================
function sgp_integration_init() {
    // Carrega as traduções
    load_plugin_textdomain(
        'sgp-integration',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );

    // Inicializa a instância principal
    $plugin = SGP_Integration::get_instance();
    $plugin->initialize();
    
    // Registra os shortcodes
    add_shortcode('sgp_customer_panel', [sgp_integration()->get_customer_panel(), 'render_customer_panel']);
    
    // Redireciona para configurações na primeira ativação
    if (get_option('sgp_first_activation') && is_admin() && !wp_doing_ajax()) {
        delete_option('sgp_first_activation');
        wp_redirect(admin_url('admin.php?page=sgp-integration&first_activation=1'));
        exit;
    }

    // Adiciona opções padrão
    add_option('sgp_api_url', '');
    add_option('sgp_api_token', '');
    add_option('sgp_api_cpfcnpj', '');
    add_option('sgp_api_password', '');
    add_option('sgp_store_leads_locally', '1');
    add_option('sgp_enable_logging', '1');
    add_option('sgp_cache_time', '3600');
    add_option('sgp_notification_email', get_option('admin_email'));
    add_option('sgp_api_user', '');
    add_option('sgp_api_pass', '');
    add_option('sgp_google_maps_key', '');
}

// Registra os hooks de ativação/desativação
register_activation_hook(__FILE__, ['SGP_Integration', 'activate']);
register_deactivation_hook(__FILE__, ['SGP_Integration', 'deactivate']);

// Inicia o plugin
add_action('plugins_loaded', 'sgp_integration_init');

// ==================== FUNÇÕES ÚTEIS ====================
function sgp_integration() {
    return SGP_Integration::get_instance();
}

// Função para registrar a role do cliente
function sgp_add_customer_role() {
    $capabilities = [
        'read' => true,
        'view_sgp_dashboard' => true,
        'edit_sgp_account' => true,
        // Restrições explícitas
        'edit_posts' => false,
        'delete_posts' => false,
        'create_posts' => false,
        'publish_posts' => false,
        'upload_files' => false,
        'edit_others_posts' => false
    ];
    
    add_role('sgp_customer', __('Cliente SGP', 'sgp-integration'), $capabilities);
}
register_activation_hook(__FILE__, 'sgp_add_customer_role');

// ==================== ASSETS E SCRIPTS ====================
function sgp_integration_register_assets() {
    // Só carrega no frontend e fora do admin/editor Elementor
    if (!is_admin() && !isset($_GET['elementor-preview'])) {
        wp_enqueue_style(
            'sgp-integration-frontend',
            SGP_INTEGRATION_URL . 'assets/css/frontend.css',
            [],
            SGP_INTEGRATION_VERSION
        );
        wp_enqueue_script(
            'sgp-integration-frontend',
            SGP_INTEGRATION_URL . 'assets/js/frontend.js',
            ['jquery', 'wp-i18n'],
            SGP_INTEGRATION_VERSION,
            true
        );
        wp_localize_script('sgp-integration-frontend', 'sgpIntegrationVars', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'apiBase' => rest_url('sgp-integration/v1'),
            'nonce' => wp_create_nonce('sgp-integration-nonce'),
            'security' => [
                'loginTimeout' => SGP_LOGIN_TIMEOUT / 1000, // Em segundos para JS
                'maxAttempts' => SGP_LOGIN_ATTEMPTS_LIMIT
            ],
            'i18n' => [
                'invalidCep' => __('CEP inválido', 'sgp-integration'),
                'requiredField' => __('Este campo é obrigatório', 'sgp-integration'),
                'loginBlocked' => __('Acesso temporariamente bloqueado', 'sgp-integration')
            ]
        ]);
        wp_set_script_translations(
            'sgp-integration-frontend',
            'sgp-integration',
            SGP_INTEGRATION_PATH . 'languages'
        );
    }
}
add_action('wp_enqueue_scripts', 'sgp_integration_register_assets');

// ==================== TIPOS DE POST E REST API ====================
function sgp_integration_register_post_types() {
    if (get_option('sgp_store_leads_locally')) {
        register_post_type('sgp_lead', [
            'labels' => [
                'name' => __('Leads SGP', 'sgp-integration'),
                'singular_name' => __('Lead SGP', 'sgp-integration')
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'sgp-integration',
            'capability_type' => 'post',
            'capabilities' => [
                'create_posts' => false,
            ],
            'map_meta_cap' => true,
            'supports' => ['title', 'custom-fields']
        ]);
    }
}
add_action('init', 'sgp_integration_register_post_types');

function sgp_integration_register_rest_routes() {
    register_rest_route('sgp-integration/v1', '/check-coverage', [
        'methods' => 'POST',
        'callback' => 'sgp_integration_rest_check_coverage',
        'permission_callback' => '__return_true',
        'args' => [
            'cep' => [
                'required' => true,
                'validate_callback' => function($param) {
                    return preg_match('/^[0-9]{8}$/', $param);
                },
                'sanitize_callback' => 'absint'
            ],
            'numero' => [
                'required' => false,
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);
}
add_action('rest_api_init', 'sgp_integration_register_rest_routes');

function sgp_integration_rest_check_coverage(WP_REST_Request $request) {
    $plugin = sgp_integration();
    $response = $plugin->get_api_client()->check_coverage(
        $request->get_param('cep'),
        $request->get_param('numero')
    );
    
    return isset($response['error'])
        ? new WP_REST_Response($response, 400)
        : new WP_REST_Response($response, 200);
}

// ==================== SISTEMA DE LOGS ====================
function sgp_integration_log($message, $data = [], $level = 'info') {
    $log_entry = [
        'timestamp' => current_time('mysql'),
        'level' => in_array($level, ['info', 'warning', 'error']) ? $level : 'info',
        'message' => $message,
        'data' => is_array($data) ? $data : []
    ];
    
    if (apply_filters('sgp_integration_enable_logging', true)) {
        do_action('sgp_integration_log', $log_entry);
        
        // Log adicional para erros críticos
        if ($level === 'error') {
            error_log('SGP Error: ' . $message);
        }
    }
    
    return $log_entry;
}

add_action('elementor/widgets/widgets_registered', function($widgets_manager) {
    $base = __DIR__ . '/elementor-widgets/';
    if (file_exists($base . 'class-widget-availability-form.php')) {
        require_once $base . 'class-widget-availability-form.php';
        $widgets_manager->register_widget_type(new \SGP_Elementor_Availability_Form_Widget());
    }
    if (file_exists($base . 'class-widget-customer-panel.php')) {
        require_once $base . 'class-widget-customer-panel.php';
        $widgets_manager->register_widget_type(new \SGP_Elementor_Customer_Panel_Widget());
    }
    if (file_exists($base . 'class-widget-plan-list.php')) {
        require_once $base . 'class-widget-plan-list.php';
        $widgets_manager->register_widget_type(new \SGP_Elementor_Plan_List_Widget());
    }
});

add_action('elementor/elements/categories_registered', function($elements_manager) {
    $elements_manager->add_category(
        'sgp-widgets',
        [
            'title' => __('SGP', 'sgp-integration'),
            'icon'  => 'fa fa-plug'
        ],
        1
    );
}); 