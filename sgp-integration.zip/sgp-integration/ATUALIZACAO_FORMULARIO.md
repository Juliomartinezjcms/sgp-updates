# Atualização do Formulário de Consulta de Viabilidade

## Resumo das Mudanças

O formulário de consulta de viabilidade foi completamente reformulado para oferecer **consultas mais precisas** usando endereço completo em vez de apenas CEP.

## Principais Melhorias

### 1. **Formulário Completo**
- **Campos obrigatórios:** CEP, Rua, Número, Bairro, Cidade, Estado
- **Campos opcionais:** Complemento, Ponto de Referência
- **Validação:** Checkbox de termos e condições

### 2. **Preenchimento Automático por CEP**
- Integração com API ViaCEP
- Preenchimento automático de rua, bairro, cidade e estado
- Indicador visual de carregamento

### 3. **Geocodificação Precisa**
- Uso de endereço completo para geocodificação
- Coordenadas exatas do endereço (não centroide do CEP)
- Cálculo de distância mais preciso

### 4. **Interface Melhorada**
- Layout responsivo com grid
- Validação em tempo real
- Mensagens de erro claras
- Confirmação do endereço consultado

## Arquivos Modificados

### Templates
- `templates/availability-form.php` - Formulário completo

### Estilos
- `assets/css/frontend.css` - Estilos responsivos e indicadores

### JavaScript
- `assets/js/frontend.js` - Validações e preenchimento automático

### Backend
- `includes/api/class-sgp-api-client.php` - Nova lógica de consulta
- `includes/class-lead-manager.php` - Handler AJAX atualizado

## Como Funciona

### 1. **Preenchimento do Formulário**
```
CEP → Preenchimento automático → Validação → Envio
```

### 2. **Processamento Backend**
```
Dados → Montagem do endereço → Geocodificação → Busca CTOs → Cálculo de distância
```

### 3. **Resposta**
```
Resultado → Exibição do endereço → Status de cobertura → Planos (se disponível)
```

## Vantagens da Nova Abordagem

### ✅ **Precisão Máxima**
- Coordenadas exatas do endereço
- Sem falsos negativos por centroide de CEP

### ✅ **Melhor Experiência**
- Preenchimento automático
- Validação em tempo real
- Interface responsiva

### ✅ **Resultados Confiáveis**
- Distância calculada em metros
- CTO mais próxima identificada
- Logs detalhados para depuração

## Configuração Necessária

### 1. **Google Maps API Key**
- Configurar no painel administrativo
- Habilitar Geocoding API

### 2. **Credenciais SGP**
- URL da API
- Usuário e senha para autenticação

### 3. **Teste**
- Verificar logs de depuração
- Testar com endereços conhecidos

## Logs de Depuração

O sistema agora registra logs detalhados:
- Dados do formulário
- Tempo de geocodificação
- CTOs encontradas
- Distâncias calculadas
- Resultado final

## Compatibilidade

- ✅ WordPress 5.0+
- ✅ PHP 7.4+
- ✅ Navegadores modernos
- ✅ Dispositivos móveis

## Próximos Passos

1. **Testar** o formulário com endereços reais
2. **Monitorar** os logs de depuração
3. **Ajustar** o raio de cobertura se necessário (atualmente 300m)
4. **Personalizar** mensagens e estilos conforme necessário 