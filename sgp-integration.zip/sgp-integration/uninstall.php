<?php
/**
 * Arquivo de desinstalação do plugin SGP Integration
 * 
 * Este arquivo é executado quando o plugin é desinstalado
 * Remove todas as opções, posts e dados criados pelo plugin
 */

// Se não foi chamado pelo WordPress, sai
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// ==================== REMOÇÃO DE OPÇÕES ====================
$options_to_delete = [
    'sgp_api_url',
    'sgp_api_email',
    'sgp_api_password',
    'sgp_store_leads_locally',
    'sgp_enable_logging',
    'sgp_cache_time',
    'sgp_notification_email',
    'sgp_force_https',
    'sgp_security_headers',
    'sgp_ip_whitelist',
    'sgp_enable_2fa',
    'sgp_session_timeout',
    'sgp_first_activation'
];

foreach ($options_to_delete as $option) {
    delete_option($option);
}

// ==================== REMOÇÃO DE POSTS ====================
// Remove todos os leads salvos localmente
$leads = get_posts([
    'post_type' => 'sgp_lead',
    'posts_per_page' => -1,
    'post_status' => 'any'
]);

foreach ($leads as $lead) {
    wp_delete_post($lead->ID, true);
}

// ==================== REMOÇÃO DE USUÁRIOS ====================
// Remove a role personalizada
remove_role('sgp_customer');

// Remove meta dados dos usuários
global $wpdb;
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'sgp_%'");

// ==================== REMOÇÃO DE CACHE ====================
// Remove todos os transients relacionados ao SGP
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sgp_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_sgp_%'");

// ==================== REMOÇÃO DE LOGS ====================
// Remove logs salvos no banco (se houver)
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'sgp_log_%'");

// ==================== LIMPEZA DE ARQUIVOS ====================
// Remove arquivos de exportação antigos (mais de 7 dias)
$upload_dir = wp_upload_dir();
$export_dir = $upload_dir['basedir'] . '/';

if (is_dir($export_dir)) {
    $files = glob($export_dir . 'sgp-leads-*.csv');
    $cutoff_time = time() - (7 * 24 * 60 * 60); // 7 dias atrás
    
    foreach ($files as $file) {
        if (filemtime($file) < $cutoff_time) {
            unlink($file);
        }
    }
}

// ==================== LOG DE DESINSTALAÇÃO ====================
// Registra a desinstalação (último log antes de remover tudo)
error_log('SGP Integration Plugin desinstalado em: ' . current_time('mysql'));

// ==================== LIMPEZA FINAL ====================
// Força limpeza de cache do WordPress
wp_cache_flush();

// Limpa qualquer cache de plugins externos
if (function_exists('w3tc_flush_all')) {
    w3tc_flush_all();
}

if (function_exists('wp_cache_clear_cache')) {
    wp_cache_clear_cache();
}

if (function_exists('rocket_clean_domain')) {
    rocket_clean_domain();
}

// ==================== CONFIRMAÇÃO ====================
// Adiciona uma opção temporária para confirmar desinstalação
add_option('sgp_uninstalled', current_time('mysql'), '', 'no');

// Remove a opção após 1 hora
wp_schedule_single_event(time() + 3600, 'delete_option', ['sgp_uninstalled']);