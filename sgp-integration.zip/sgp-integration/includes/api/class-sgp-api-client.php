<?php
class SGP_API_Client {
    private $api_url;
    private $api_cpfcnpj;
    private $api_password;
    private $auth_token;
    private $cache_time;
    private $api_token;

    public function init() {
        $this->api_url = get_option('sgp_api_url');
        $this->api_cpfcnpj = get_option('sgp_api_cpfcnpj');
        $this->api_password = get_option('sgp_api_password');
        $this->cache_time = SGP_INTEGRATION_API_CACHE_TIME;
        
        // Carregar credenciais do cliente se disponível
        $customer_credentials = get_transient('sgp_customer_credentials');
        if (!empty($customer_credentials) && isset($customer_credentials['authenticated']) && $customer_credentials['authenticated'] === true) {
            $this->auth_token = $customer_credentials; // Armazenar credenciais como "token"
            error_log('[SGP_DEBUG] Credenciais do cliente carregadas do cache');
        }
        
        // Verificar credenciais corretas para CTOs (sgp_api_user e sgp_api_pass)
        $api_user = get_option('sgp_api_user');
        $api_pass = get_option('sgp_api_pass');
        
        // Sempre usar modo de produção - API real
        if (!empty($this->api_url) && !empty($api_user) && !empty($api_pass)) {
            error_log('[SGP_DEBUG] MODO PRODUÇÃO - Todas as credenciais configuradas');
            $this->authenticate();
        } else {
            error_log('[SGP_DEBUG] AVISO: Credenciais incompletas - Configure todas as credenciais necessárias');
            error_log('[SGP_DEBUG] - API URL: ' . (empty($this->api_url) ? 'VAZIA' : 'OK'));
            error_log('[SGP_DEBUG] - API User: ' . (empty($api_user) ? 'VAZIO' : 'OK'));
            error_log('[SGP_DEBUG] - API Pass: ' . (empty($api_pass) ? 'VAZIA' : 'OK'));
        }
    }

    private function authenticate() {
        if (empty($this->api_url) || empty($this->api_cpfcnpj) || empty($this->api_password)) {
            return false;
        }

        $response = $this->make_request('POST', '/api/central/contratos', [
            'cpfcnpj' => $this->api_cpfcnpj,
            'senha' => $this->api_password
        ], false); // Não usar token para login
        
        if (isset($response['token'])) {
            $this->auth_token = $response['token'];
            set_transient('sgp_api_token', $this->auth_token, $this->cache_time);
            return true;
        } else {
            return false;
        }
    }

    public function check_coverage($cep, $numero = '') {
        $cache_key = 'sgp_coverage_' . $cep . '_' . $numero;
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }

        $response = $this->make_request('POST', '/api/coverage/check', [
            'cep' => preg_replace('/[^0-9]/', '', $cep),
            'numero' => $numero
        ]);
        
        if (!isset($response['error'])) {
            set_transient($cache_key, $response, $this->cache_time);
        }
        
        return $response;
    }

    public function authenticate_customer($credentials) {
        return $this->make_request('POST', '/api/customer/login', [
            'email' => $credentials['email'],
            'password' => $credentials['password']
        ], false);
    }

    public function create_lead($data) {
        $required_fields = ['name', 'email', 'phone', 'cep'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return ['error' => "Campo obrigatório não preenchido: {$field}"];
            }
        }

        // Validação de email
        if (!is_email($data['email'])) {
            return ['error' => 'E-mail inválido'];
        }

        // Validação de CEP
        if (strlen(preg_replace('/[^0-9]/', '', $data['cep'])) !== 8) {
            return ['error' => 'CEP inválido'];
        }

        $response = $this->make_request('POST', '/api/leads/create', $data);
        
        // Se configurado para salvar localmente
        if (get_option('sgp_store_leads_locally') && !isset($response['error'])) {
            $this->store_lead_locally($data, $response);
        }
        
        return $response;
    }

    public function password_recovery($email) {
        if (!is_email($email)) {
            return ['error' => 'E-mail inválido'];
        }

        return $this->make_request('POST', '/api/customer/password-recovery', [
            'email' => $email
        ], false);
    }

    public function validate_token($token) {
        return $this->make_request('GET', '/api/customer/validate-token', [
            'token' => $token
        ], false);
    }

    public function get_customer_invoices($period = 'all') {
        return $this->make_request('GET', '/api/customer/invoices', [
            'period' => $period
        ]);
    }

    public function get_customer_tickets() {
        return $this->make_request('GET', '/api/customer/tickets');
    }

    public function create_ticket($data) {
        $required_fields = ['subject', 'description', 'priority'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return ['error' => "Campo obrigatório não preenchido: {$field}"];
            }
        }

        return $this->make_request('POST', '/api/customer/tickets/create', $data);
    }

    public function update_customer_profile($data) {
        return $this->make_request('PUT', '/api/customer/profile', $data);
    }

    public function request_plan_change($plan_id) {
        return $this->make_request('POST', '/api/customer/plan-change', [
            'plan_id' => $plan_id
        ]);
    }

    public function get_available_plans($cep = '') {
        $cache_key = 'sgp_plans_' . $cep;
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }

        $response = $this->make_request('GET', '/api/plans', [
            'cep' => $cep
        ]);
        
        if (!isset($response['error'])) {
            set_transient($cache_key, $response, $this->cache_time);
        }
        
        return $response;
    }

    public function check_lead_exists($email) {
        return $this->make_request('GET', '/api/leads/check', [
            'email' => $email
        ]);
    }

    public function set_api_url($url) {
        $this->api_url = $url;
    }

    public function set_api_token($token) {
        $this->api_token = $token;
    }

    public function get_api_token() {
        return $this->api_token;
    }

    private function get_token() {
        if (!empty($this->api_token)) return $this->api_token;
        return get_option('sgp_api_token');
    }

    public function call_endpoint($endpoint, $params = [], $method = 'POST') {
        $url = rtrim($this->api_url ?: get_option('sgp_api_url'), '/') . $endpoint;
        $body = array_merge(['token' => $this->get_token()], $params);
        $args = [
            'body' => $body
        ];
        if (strtoupper($method) === 'GET') {
            $url = add_query_arg($body, $url);
            $response = wp_remote_get($url, $args);
        } else {
            $response = wp_remote_post($url, $args);
        }
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        return $json ? $json : ['error' => 'Resposta inválida da API'];
    }

    // Exemplo de endpoint: segunda via de fatura
    public function get_fatura_segunda_via($contrato, $app = 'fortics') {
        return $this->call_endpoint('/api/ura/fatura2via/', [
            'contrato' => $contrato,
            'app' => $app
        ]);
    }

    // Exemplo de endpoint: enviar fatura
    public function enviar_fatura($contrato, $app = 'fortics') {
        return $this->call_endpoint('/api/ura/enviafatura/', [
            'contrato' => $contrato,
            'app' => $app
        ]);
    }

    private function get_headers() {
        $headers = [
            'Content-Type' => 'application/json',
        ];
        if (!empty($this->api_token)) {
            $headers['Authorization'] = 'Bearer ' . $this->api_token;
        }
        return $headers;
    }

    private function make_request($method, $endpoint, $data = [], $use_auth = true) {
        if (empty($this->api_url)) {
            return ['error' => 'API URL não configurada'];
        }
        $url = rtrim($this->api_url, '/') . $endpoint;
        $args = [
            'method' => $method,
            'headers' => $this->get_headers(),
        ];
        if ($method === 'GET') {
            $url = add_query_arg($data, $url);
        } else {
            $args['body'] = json_encode($data);
        }
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        return $json ? $json : ['error' => 'Resposta inválida da API'];
    }

    private function store_lead_locally($data, $api_response) {
        $post_data = [
            'post_title' => $data['name'],
            'post_type' => 'sgp_lead',
            'post_status' => 'publish',
            'meta_input' => [
                'sgp_email' => $data['email'],
                'sgp_phone' => $data['phone'],
                'sgp_cep' => $data['cep'],
                'sgp_api_id' => $api_response['id'] ?? '',
                'sgp_created_at' => current_time('mysql'),
                'sgp_status' => 'new'
            ]
        ];

        if (!empty($data['cpf'])) {
            $post_data['meta_input']['sgp_cpf'] = $data['cpf'];
        }

        if (!empty($data['address'])) {
            $post_data['meta_input']['sgp_address'] = $data['address'];
        }

        wp_insert_post($post_data);
    }

    public function get_api_url() {
        return $this->api_url;
    }
    
    public function get_api_cpfcnpj() {
        return $this->api_cpfcnpj;
    }
    
    public function get_api_password() {
        return $this->api_password;
    }

    public function test_token_connection() {
        $response = $this->make_request('GET', '/api/central/contratos', [], true);
        return (isset($response) && !isset($response['error']));
    }

    public function get_ctos() {
        $user = strtolower(trim(get_option('sgp_api_user')));
        $pass = strtolower(trim(get_option('sgp_api_pass')));
        $url = rtrim($this->api_url ?: get_option('sgp_api_url'), '/') . '/api/fttx/splitter/all/';
        $auth_base64 = base64_encode("$user:$pass");
        
        $args = [
            'headers' => [
                'Authorization' => 'Basic ' . $auth_base64
            ],
            'timeout' => 30
        ];
        
        $start_time = microtime(true);
        $response = wp_remote_get($url, $args);
        $elapsed = microtime(true) - $start_time;
        
        if (is_wp_error($response)) {
            error_log('[SGP_DEBUG] ERRO na requisição CTOs: ' . $response->get_error_message());
            return [];
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        
        if ($http_code !== 200) {
            error_log('[SGP_DEBUG] ERRO HTTP na busca CTOs - Code: ' . $http_code);
            return [];
        }
        
        $body = wp_remote_retrieve_body($response);
        
        if (empty($body)) {
            error_log('[SGP_DEBUG] ERRO: Resposta vazia da API CTOs');
            return [];
        }
        
        $json = json_decode($body, true);
        if (!is_array($json)) {
            error_log('[SGP_DEBUG] ERRO: JSON inválido na resposta CTOs');
            return [];
        }
        
        error_log('[SGP_DEBUG] CTOs obtidas: ' . count($json) . ' (tempo: ' . round($elapsed * 1000) . 'ms)');
        
        return $json;
    }

    public function geocode_address($address) {
        $google_maps_key = get_option('sgp_google_maps_key');
        
        if (empty($google_maps_key)) {
            error_log('[SGP_DEBUG] ERRO: Google Maps Key não configurada');
            return false;
        }
        
        $url = 'https://maps.googleapis.com/maps/api/geocode/json';
        $url .= '?address=' . urlencode($address);
        $url .= '&key=' . $google_maps_key;
        
        $start_time = microtime(true);
        $response = wp_remote_get($url, array('timeout' => 10));
        $elapsed = microtime(true) - $start_time;
        
        if (is_wp_error($response)) {
            error_log('[SGP_DEBUG] ERRO na geocodificação: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || $data['status'] !== 'OK' || empty($data['results'])) {
            error_log('[SGP_DEBUG] ERRO: Geocodificação falhou - Status: ' . ($data['status'] ?? 'UNKNOWN'));
            return false;
        }
        
        $result = $data['results'][0];
        $location = $result['geometry']['location'];
        
        return [
            'lat' => $location['lat'],
            'lng' => $location['lng'],
            'address' => $result['formatted_address']
        ];
    }

    public function haversine($lat1, $lon1, $lat2, $lon2) {
        $r = 6371; // Raio da Terra em quilômetros
        $lat1 = deg2rad($lat1);
        $lon1 = deg2rad($lon1);
        $lat2 = deg2rad($lat2);
        $lon2 = deg2rad($lon2);
        $dlat = $lat2 - $lat1;
        $dlon = $lon2 - $lon1;
        $a = sin($dlat/2) * sin($dlat/2) + cos($lat1) * cos($lat2) * sin($dlon/2) * sin($dlon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $r * $c;
    }

    public function consulta_viabilidade($cep) {
        $start_time = microtime(true);
        
        // 1. Geocodificar o CEP
        $address = sprintf('%s, Brasil', $cep);
        $latlng = $this->geocode_address($address);
        $geo_time = microtime(true);
        
        if (!$latlng) {
            return ['available' => false, 'address' => ''];
        }
        
        // 2. Buscar CTOs
        $ctos = $this->get_ctos();
        $ctos_time = microtime(true);
        
        if (empty($ctos)) {
            return ['available' => false, 'address' => $latlng['address']];
        }
        
        // 3. Processar CTOs e encontrar a mais próxima
        $ctos_processadas = [];
        $ctos_sem_localizacao = 0;
        
        foreach ($ctos as $cto) {
            $coords = $this->extrair_coordenadas_cto($cto);
            
            if (!$coords) {
                $ctos_sem_localizacao++;
                continue;
            }
            
            // Verificar estrutura mínima da CTO
            if (!isset($cto['olt']) || !isset($cto['clientes_conectados'])) {
                continue;
            }
            
            // Verificar se há portas livres
            $total_portas = intval($cto['total_portas'] ?? 0);
            $clientes_conectados = intval($cto['clientes_conectados']);
            $portas_livres = $total_portas - $clientes_conectados;
            
            if ($portas_livres <= 0) {
                continue;
            }
            
            $distancia = $this->haversine(
                $latlng['lat'], $latlng['lng'],
                $coords['lat'], $coords['lng']
            );
            
            // Considerar disponível se:
            // 1. Distância <= 2km (raio de atendimento padrão)
            // 2. Há portas livres
            if ($distancia <= 2.0) {
                return [
                    'available' => true,
                    'address' => $latlng['address'],
                    'distance' => $distancia,
                    'cto' => $cto
                ];
            }
        }
        
        return [
            'available' => false,
            'address' => $latlng['address']
        ];
    }

    /**
     * Calcula rota caminhando entre dois pontos usando Google Directions API
     */
    public function calculate_walking_route($origin_lat, $origin_lng, $dest_lat, $dest_lng) {
        $key = get_option('sgp_google_maps_key');
        
        if (empty($key)) {
            error_log('[SGP_DEBUG] ERRO: Google Maps Key não configurada para rota');
            return false;
        }
        
        $origin = $origin_lat . ',' . $origin_lng;
        $destination = $dest_lat . ',' . $dest_lng;
        
        $url = 'https://maps.googleapis.com/maps/api/directions/json?' . http_build_query([
            'origin' => $origin,
            'destination' => $destination,
            'mode' => 'walking',
            'key' => $key
        ]);
        
        error_log('[SGP_DEBUG] === CALCULANDO ROTA CAMINHANDO (GOOGLE DIRECTIONS) ===');
        error_log('[SGP_DEBUG] De: ' . $origin . ' Para: ' . $destination);
        error_log('[SGP_DEBUG] URL da API: ' . substr($url, 0, 120) . '...');
        error_log('[SGP_DEBUG] Modo: WALKING (rota real pelas ruas)');
        
        $start_time = microtime(true);
        $response = wp_remote_get($url);
        $elapsed = microtime(true) - $start_time;
        
        error_log('[SGP_DEBUG] ⏱️ Tempo da requisição Google: ' . round($elapsed * 1000, 2) . 'ms');
        
        if (is_wp_error($response)) {
            error_log('[SGP_DEBUG] ERRO na requisição de rota: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || $data['status'] !== 'OK') {
            error_log('[SGP_DEBUG] ERRO na resposta da rota - Status: ' . ($data['status'] ?? 'UNKNOWN'));
            if (isset($data['error_message'])) {
                error_log('[SGP_DEBUG] Mensagem de erro da rota: ' . $data['error_message']);
            }
            return false;
        }
        
        if (empty($data['routes'])) {
            error_log('[SGP_DEBUG] ERRO: Nenhuma rota encontrada');
            return false;
        }
        
        $route = $data['routes'][0];
        $leg = $route['legs'][0];
        
        $distance_meters = $leg['distance']['value'];
        $distance_km = $distance_meters / 1000;
        $duration_seconds = $leg['duration']['value'];
        $duration_minutes = round($duration_seconds / 60);
        
        error_log('[SGP_DEBUG] ✅ ROTA CALCULADA COM SUCESSO:');
        error_log('[SGP_DEBUG] 📏 Distância: ' . round($distance_km, 3) . 'km (' . $distance_meters . 'm)');
        error_log('[SGP_DEBUG] ⏱️ Tempo caminhando: ' . $duration_minutes . ' minutos (' . $duration_seconds . 's)');
        error_log('[SGP_DEBUG] 🚶‍♂️ Velocidade média: ' . round(($distance_km / ($duration_seconds / 3600)), 1) . ' km/h');
        
        // Log dos passos da rota (limitado a 5 passos principais)
        if (isset($leg['steps']) && count($leg['steps']) > 0) {
            error_log('[SGP_DEBUG] === PASSOS DA ROTA (primeiros 5) ===');
            $steps_to_show = array_slice($leg['steps'], 0, 5);
            
            foreach ($steps_to_show as $i => $step) {
                $step_distance = round($step['distance']['value']);
                $step_instruction = strip_tags($step['html_instructions']);
                // Limitar instrução para não poluir o log
                $instruction_short = strlen($step_instruction) > 80 ? 
                    substr($step_instruction, 0, 80) . '...' : $step_instruction;
                
                error_log('[SGP_DEBUG] Passo ' . ($i + 1) . ': ' . $instruction_short . ' (' . $step_distance . 'm)');
            }
            
            if (count($leg['steps']) > 5) {
                error_log('[SGP_DEBUG] ... e mais ' . (count($leg['steps']) - 5) . ' passos');
            }
        }
        
        return [
            'distance_km' => $distance_km,
            'distance_meters' => $distance_meters,
            'duration_seconds' => $duration_seconds,
            'duration_minutes' => $duration_minutes,
            'distance_text' => $leg['distance']['text'],
            'duration_text' => $leg['duration']['text'],
            'start_address' => $leg['start_address'],
            'end_address' => $leg['end_address']
        ];
    }

    public function consulta_viabilidade_completa($dados_endereco) {
        $start_time = microtime(true);
        
        error_log('[SGP_DEBUG] === CONSULTA VIABILIDADE POR COORDENADAS ===');
        error_log('[SGP_DEBUG] Modo: PRODUÇÃO (API Real)');
        
        // 1. Geocodificar o endereço do cliente
        $endereco_completo = $this->montar_endereco_completo($dados_endereco);
        $latlng = $this->geocode_address($endereco_completo);
        
        if (!$latlng) {
            error_log('[SGP_DEBUG] ERRO: Geocodificação falhou');
            return ['available' => false, 'address' => ''];
        }
        
        error_log('[SGP_DEBUG] Cliente: lat=' . $latlng['lat'] . ', lng=' . $latlng['lng']);
        
        // 2. Buscar todas as CTOs
        $ctos = $this->get_ctos();
        
        if (empty($ctos)) {
            error_log('[SGP_DEBUG] ERRO: Nenhuma CTO encontrada');
            return ['available' => false, 'address' => $latlng['address']];
        }
        
        // 3. Calcular distância linear para todas as CTOs com coordenadas válidas
        $ctos_com_distancia = [];
        $ctos_sem_coordenadas = 0;
        
        // Contadores geográficos baseados em proximidade
        $ctos_estado = []; // CTOs no mesmo estado (até 500km)
        $ctos_cidade = []; // CTOs na mesma cidade (até 50km)
        $ctos_bairro = []; // CTOs no mesmo bairro (até 5km)
        
        foreach ($ctos as $index => $cto) {
            $coords = $this->extrair_coordenadas_cto($cto);
            
            if (!$coords) {
                $ctos_sem_coordenadas++;
                continue;
            }
            
            // Calcular distância linear (haversine)
            $distancia_linear_km = $this->haversine(
                $latlng['lat'], $latlng['lng'],
                $coords['lat'], $coords['lng']
            );
            
            $cto_data = [
                'index' => $index,
                'cto' => $cto,
                'coords' => $coords,
                'distancia_linear_km' => $distancia_linear_km
            ];
            
            $ctos_com_distancia[] = $cto_data;
            
            // Classificação geográfica por proximidade
            if ($distancia_linear_km <= 500) { // Estado (até 500km)
                $ctos_estado[] = $cto_data;
                
                if ($distancia_linear_km <= 50) { // Cidade (até 50km)
                    $ctos_cidade[] = $cto_data;
                    
                    if ($distancia_linear_km <= 5) { // Bairro (até 5km)
                        $ctos_bairro[] = $cto_data;
                    }
                }
            }
        }
        
        // Logs geográficos baseados em proximidade
        error_log('[SGP_DEBUG] === ANÁLISE GEOGRÁFICA POR PROXIMIDADE ===');
        error_log('[SGP_DEBUG] 🗺️ Estado (até 500km): ' . count($ctos_estado) . ' CTOs');
        error_log('[SGP_DEBUG] 🏙️ Cidade (até 50km): ' . count($ctos_cidade) . ' CTOs');
        error_log('[SGP_DEBUG] 🏘️ Bairro (até 5km): ' . count($ctos_bairro) . ' CTOs');
        error_log('[SGP_DEBUG] CTOs com coordenadas: ' . count($ctos_com_distancia));
        error_log('[SGP_DEBUG] CTOs sem coordenadas: ' . $ctos_sem_coordenadas);
        
        if (empty($ctos_com_distancia)) {
            error_log('[SGP_DEBUG] ERRO: Nenhuma CTO com coordenadas válidas');
            return ['available' => false, 'address' => $latlng['address']];
        }
        
        // 4. Ordenar por distância linear e pegar as mais próximas
        usort($ctos_com_distancia, function($a, $b) {
            return $a['distancia_linear_km'] <=> $b['distancia_linear_km'];
        });
        
        // Processar apenas as 20 CTOs mais próximas por distância linear
        $ctos_para_processar = array_slice($ctos_com_distancia, 0, 20);
        error_log('[SGP_DEBUG] Processando as ' . count($ctos_para_processar) . ' CTOs mais próximas');
        
        // 5. Calcular rota caminhando para as CTOs mais próximas
        $ctos_com_rota = [];
        $limite_distancia_km = 2.0; // 2km máximo
        
        foreach ($ctos_para_processar as $cto_data) {
            $cto = $cto_data['cto'];
            $coords = $cto_data['coords'];
            
            // Pular CTOs muito distantes
            if ($cto_data['distancia_linear_km'] > $limite_distancia_km) {
                continue;
            }
            
            // Verificar portas disponíveis
            $total_portas = 0;
            $clientes_conectados = 0;
            
            if (isset($cto['ports'])) {
                $total_portas = intval($cto['ports']);
            } elseif (isset($cto['total_portas'])) {
                $total_portas = intval($cto['total_portas']);
            } elseif (isset($cto['on_ports'])) {
                $total_portas = intval($cto['on_ports']);
            }
            
            if (isset($cto['onu_count'])) {
                $clientes_conectados = intval($cto['onu_count']);
            } elseif (isset($cto['clientes_conectados'])) {
                $clientes_conectados = intval($cto['clientes_conectados']);
            } elseif (isset($cto['used_ports'])) {
                $clientes_conectados = intval($cto['used_ports']);
            }
            
            $portas_livres = $total_portas - $clientes_conectados;
            
            if ($portas_livres <= 0) {
                continue; // Pular CTOs sem portas livres
            }
            
            // Calcular rota caminhando real
            $rota = $this->calculate_walking_route(
                $coords['lat'], $coords['lng'],
                $latlng['lat'], $latlng['lng']
            );
            
            if (!$rota) {
                continue; // Pular se não conseguiu calcular rota
            }
            
            $ctos_com_rota[] = [
                'cto' => $cto,
                'coords' => $coords,
                'portas_livres' => $portas_livres,
                'total_portas' => $total_portas,
                'distancia_linear_km' => $cto_data['distancia_linear_km'],
                'distancia_rota_km' => $rota['distance_km'],
                'tempo_caminhada_min' => $rota['duration_minutes'],
                'rota_completa' => $rota
            ];
        }
        
        error_log('[SGP_DEBUG] CTOs com rota calculada: ' . count($ctos_com_rota));
        
        if (empty($ctos_com_rota)) {
            error_log('[SGP_DEBUG] Nenhuma CTO viável encontrada');
            return [
                'available' => false,
                'address' => $latlng['address'],
                'endereco_completo' => $endereco_completo
            ];
        }
        
        // 6. Ordenar por distância de rota caminhando (mais precisa)
        usort($ctos_com_rota, function($a, $b) {
            return $a['distancia_rota_km'] <=> $b['distancia_rota_km'];
        });
        
        // Log das CTOs mais próximas
        error_log('[SGP_DEBUG] === TOP CTOs MAIS PRÓXIMAS ===');
        foreach (array_slice($ctos_com_rota, 0, 3) as $rank => $cto_info) {
            $ident = $cto_info['cto']['ident'] ?? 'sem_ident';
            $distancia_linear_m = round($cto_info['distancia_linear_km'] * 1000);
            $distancia_rota_m = round($cto_info['distancia_rota_km'] * 1000);
            error_log('[SGP_DEBUG] #' . ($rank + 1) . '. ' . $ident . ' | Linear: ' . $distancia_linear_m . 'm | Caminhada: ' . $distancia_rota_m . 'm | Tempo: ' . $cto_info['tempo_caminhada_min'] . 'min | Portas: ' . $cto_info['portas_livres']);
        }
        
        // 7. Verificar se a CTO mais próxima está dentro do limite configurável
        $cto_mais_proxima = $ctos_com_rota[0];
        $distancia_maxima_metros = get_option('sgp_coverage_distance', 200); // Valor configurável, padrão 200m
        $distancia_maxima_km = $distancia_maxima_metros / 1000; // Converter para km
        
        if ($cto_mais_proxima['distancia_rota_km'] <= $distancia_maxima_km) {
            $tempo_total = round((microtime(true) - $start_time) * 1000, 2);
            $ident = $cto_mais_proxima['cto']['ident'] ?? 'sem_ident';
            $distancia_m = round($cto_mais_proxima['distancia_rota_km'] * 1000);
            
            error_log('[SGP_DEBUG] ✅ COBERTURA APROVADA');
            error_log('[SGP_DEBUG] CTO: ' . $ident . ' | Distância: ' . $distancia_m . 'm | Tempo: ' . $cto_mais_proxima['tempo_caminhada_min'] . 'min');
            error_log('[SGP_DEBUG] Processamento: ' . $tempo_total . 'ms');
            
            return [
                'available' => true,
                'address' => $latlng['address'],
                'distance' => $cto_mais_proxima['distancia_rota_km'],
                'linear_distance' => $cto_mais_proxima['distancia_linear_km'],
                'walking_time' => $cto_mais_proxima['tempo_caminhada_min'],
                'route_info' => $cto_mais_proxima['rota_completa'],
                'cto' => $cto_mais_proxima['cto'],
                'endereco_completo' => $endereco_completo,
                'all_ctos_analyzed' => count($ctos_com_rota)
            ];
        } else {
            $tempo_total = round((microtime(true) - $start_time) * 1000, 2);
            $ident = $cto_mais_proxima['cto']['ident'] ?? 'sem_ident';
            $distancia_m = round($cto_mais_proxima['distancia_rota_km'] * 1000);
            
            error_log('[SGP_DEBUG] ❌ SEM COBERTURA');
            error_log('[SGP_DEBUG] CTO mais próxima: ' . $ident . ' (' . $distancia_m . 'm) - Limite: ' . $distancia_maxima_metros . 'm');
            error_log('[SGP_DEBUG] Processamento: ' . $tempo_total . 'ms');
            
            return [
                'available' => false,
                'address' => $latlng['address'],
                'endereco_completo' => $endereco_completo,
                'closest_cto' => $ident,
                'closest_distance' => round($cto_mais_proxima['distancia_rota_km'], 3),
                'closest_linear_distance' => $cto_mais_proxima['distancia_linear_km'],
                'closest_route_info' => $cto_mais_proxima['rota_completa'],
                'all_ctos_analyzed' => count($ctos_com_rota)
            ];
        }
    }

    private function montar_endereco_completo($dados) {
        $partes = [];
        
        if (!empty($dados['street'])) {
            $endereco = $dados['street'];
            if (!empty($dados['number'])) {
                $endereco .= ', ' . $dados['number'];
            }
            $partes[] = $endereco;
        }
        
        if (!empty($dados['neighborhood'])) {
            $partes[] = $dados['neighborhood'];
        }
        
        if (!empty($dados['city'])) {
            $partes[] = $dados['city'];
        }
        
        if (!empty($dados['state'])) {
            $partes[] = $dados['state'];
        }
        
        if (!empty($dados['cep'])) {
            $partes[] = 'CEP ' . $dados['cep'];
        }
        
        $partes[] = 'Brasil';
        
        return implode(', ', $partes);
    }

    private function extrair_coordenadas_cto($cto) {
        $ident = $cto['ident'] ?? 'sem_ident';
        
        // Extrair coordenadas do campo map_ll (formato "lat,lng" - SEM ESPAÇO)
        if (!isset($cto['map_ll'])) {
            error_log('[SGP_DEBUG] CTO ' . $ident . ' - Campo map_ll não existe');
            return null;
        }
        
        $coordenadas_str = trim($cto['map_ll']);
        
        // Verificar se não é null ou vazio
        if ($coordenadas_str === '' || $coordenadas_str === 'null' || $cto['map_ll'] === null) {
            error_log('[SGP_DEBUG] CTO ' . $ident . ' - map_ll vazio ou null: "' . $coordenadas_str . '"');
            return null;
        }
        
        // Separar por vírgula
        $coords = explode(',', $coordenadas_str);
        
        if (count($coords) !== 2) {
            error_log('[SGP_DEBUG] CTO ' . $ident . ' - map_ll formato inválido: "' . $coordenadas_str . '"');
            return null;
        }
        
        $lat = floatval(trim($coords[0]));
        $lng = floatval(trim($coords[1]));
        
        // Verificar se são coordenadas válidas (não zero)
        if ($lat == 0 || $lng == 0) {
            error_log('[SGP_DEBUG] CTO ' . $ident . ' - map_ll com coordenadas zeradas: "' . $coordenadas_str . '"');
            return null;
        }
        
        error_log('[SGP_DEBUG] CTO ' . $ident . ' - Coordenadas extraídas de map_ll: lat=' . $lat . ', lng=' . $lng);
        return ['lat' => $lat, 'lng' => $lng];
    }
    
    private function get_field_source($cto, $fields) {
        foreach ($fields as $field) {
            if (isset($cto[$field])) {
                return $field;
            }
        }
        return 'NENHUM';
    }

    // ==================== MÉTODOS DA API CENTRAL SGP ====================
    
    /**
     * Autentica cliente na API central do SGP
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @return array Resposta da API
     */
    public function authenticate_sgp_customer($cpfcnpj, $senha) {
        $response = $this->make_sgp_request('/api/central/contratos', [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha
        ]);
        
        // Se a autenticação foi bem-sucedida, armazenar credenciais para uso posterior
        if (isset($response['auth']) && $response['auth'] === true) {
            // Armazenar credenciais para uso em outras requisições
            $credentials = [
                'cpfcnpj' => $cpfcnpj,
                'senha' => $senha,
                'authenticated' => true
            ];
            set_transient('sgp_customer_credentials', $credentials, $this->cache_time);
            error_log('[SGP_API_DEBUG] Credenciais do cliente armazenadas para uso posterior');
        }
        
        return $response;
    }

    /**
     * Lista contratos do cliente
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @return array Resposta da API
     */
    public function listar_contratos($cpfcnpj, $senha) {
        return $this->make_sgp_request('/api/central/contratos', [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha
        ]);
    }

    /**
     * Lista títulos/faturas do cliente
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $contrato Número do contrato
     * @return array Lista de faturas (sempre retorna array, mesmo vazio)
     */
    public function listar_titulos($cpfcnpj, $senha, $contrato) {
        $token = get_option('sgp_api_token');
        $app = get_option('sgp_api_app');
        $response = $this->make_sgp_request('/api/central/titulos/', [
            'token' => $token,
            'app' => $app,
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha,
            'contrato' => $contrato
        ]);
        // Se houver erro, retorna array vazio
        if (empty($response) || isset($response['error'])) {
            return [];
        }
        // Retorna o array de faturas diretamente
        return $response;
    }

    /**
     * Lista ocorrências do cliente (novo endpoint)
     * @param string $contrato Número do contrato
     * @param array $params Parâmetros adicionais opcionais (status, contrato_status, datas, etc)
     * @return array Resposta da API
     */
    public function listar_ocorrencias($contrato, $params = []) {
        $token = get_option('sgp_api_token');
        $app = get_option('sgp_api_app');
        $body = array_merge([
            'token' => $token,
            'app' => $app,
            'contrato' => $contrato
        ], $params);
        return $this->make_sgp_request('/api/ura/ocorrencia/list/', $body);
    }

    /**
     * Cria novo chamado
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $contrato Número do contrato
     * @param string $conteudo Conteúdo do chamado
     * @param string $contato Nome do contato
     * @param string $contato_numero Número do contato
     * @param string $motivoos Motivo do chamado
     * @param string $sem_os Se é sem OS
     * @param string $ocorrenciatipo Tipo de ocorrência
     * @return array Resposta da API
     */
    public function criar_chamado($cpfcnpj, $senha, $contrato, $conteudo, $contato, $contato_numero, $motivoos, $sem_os, $ocorrenciatipo) {
        $params = [
            'token'    => get_option('sgp_api_token'),
            'app'      => get_option('sgp_api_app'),
            'cpfcnpj'  => $cpfcnpj,
            'senha'    => $senha,
            'contrato' => $contrato,
            'conteudo' => $conteudo,
            'contato'  => $contato,
            'contato_numero' => $contato_numero,
            'motivoos' => $motivoos,
            'sem_os'   => $sem_os,
            'ocorrenciatipo' => $ocorrenciatipo
        ];
        return $this->make_sgp_request('/api/central/chamado/', $params);
    }

    /**
     * Atualiza chamado existente
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $chamado_id ID do chamado
     * @param array $dados Dados para atualização
     * @return array Resposta da API
     */
    public function atualizar_chamado($cpfcnpj, $senha, $chamado_id, $dados) {
        $params = array_merge([
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha
        ], $dados);
        
        return $this->make_sgp_request('/api/central/chamado/update/' . $chamado_id . '/', $params);
    }

    /**
     * Cria anotação em chamado
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $chamado_id ID do chamado
     * @param string $anotacao Texto da anotação
     * @return array Resposta da API
     */
    public function criar_anotacao_chamado($cpfcnpj, $senha, $chamado_id, $anotacao) {
        return $this->make_sgp_request('/api/central/chamado/' . $chamado_id . '/anotacao', [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha,
            'anotacao' => $anotacao
        ]);
    }

    /**
     * Verifica acesso do cliente
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $contrato Número do contrato
     * @return array Resposta da API
     */
    public function verificar_acesso($cpfcnpj, $senha, $contrato) {
        return $this->make_sgp_request('/api/central/verificaacesso/', [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha,
            'contrato' => $contrato
        ]);
    }

    /**
     * Gera segunda via de fatura
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $contrato Número do contrato
     * @return array Resposta da API
     */
    public function fatura_segunda_via($cpfcnpj, $senha, $contrato) {
        return $this->make_sgp_request('/api/central/fatura2via/', [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha,
            'contrato' => $contrato
        ]);
    }

    /**
     * Gera código PIX para pagamento
     * @param string $cpfcnpj CPF ou CNPJ do cliente
     * @param string $senha Senha do cliente
     * @param string $contrato Número do contrato
     * @param string $fatura_id ID da fatura
     * @return array Resposta da API
     */
    public function gerar_pix($cpfcnpj, $senha, $contrato, $fatura_id) {
        return $this->make_sgp_request('/api/central/pagamento/pix/' . $fatura_id, [
            'cpfcnpj' => $cpfcnpj,
            'senha' => $senha,
            'contrato' => $contrato
        ]);
    }

    /**
     * Método para fazer requisições específicas da API SGP Central
     * @param string $endpoint Endpoint da API
     * @param array $data Dados a serem enviados
     * @return array Resposta da API
     */
    private function make_sgp_request($endpoint, $data = []) {
        if (empty($this->api_url)) {
            return ['error' => 'API URL não configurada'];
        }

        $url = rtrim($this->api_url, '/') . $endpoint;

        // Formatar CPF/CNPJ se existir
        if (isset($data['cpfcnpj'])) {
            $data['cpfcnpj'] = $this->formatar_cpfcnpj($data['cpfcnpj']);
        }
        // Garantir senha em texto puro
        if (isset($data['senha'])) {
            $data['senha'] = (string)$data['senha'];
        }

        // Log detalhado dos parâmetros
        $log_parametros = [];
        foreach ($data as $k => $v) {
            $log_parametros[] = $k . ' (' . gettype($v) . '): ' . var_export($v, true);
        }
        error_log('[SGP_API_DEBUG] ENVIO PARA ' . $endpoint . ' | Ordem dos parâmetros: ' . implode(', ', array_keys($data)));
        error_log('[SGP_API_DEBUG] VALORES E TIPOS: ' . implode(' | ', $log_parametros));

        // Logs de debug
        if ($endpoint !== '/api/central/contratos') {
            error_log('[SGP_API_DEBUG] Endpoint requer autenticação via parâmetros: ' . $endpoint);
        } else {
            error_log('[SGP_API_DEBUG] Endpoint de login (sem autenticação prévia): ' . $endpoint);
        }

        $args = [
            'method' => 'POST',
            'body' => $data,
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // Log da resposta para debug
        error_log('[SGP_API_DEBUG] Endpoint: ' . $endpoint . ' | HTTP Code: ' . $http_code);
        error_log('[SGP_API_DEBUG] Response: ' . substr($body, 0, 500) . '...');
        
        if ($http_code !== 200) {
            return ['error' => 'Erro HTTP: ' . $http_code, 'response' => $body];
        }

        // Tenta decodificar JSON
        $json = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Se não for JSON, retorna o HTML/texto como está
            return ['html_response' => $body];
        }

        return $json;
    }

    /**
     * Formata CPF ou CNPJ para o formato com máscara exigido pela API
     */
    private function formatar_cpfcnpj($cpfcnpj) {
        $cpfcnpj = preg_replace('/\D/', '', $cpfcnpj);
        if (strlen($cpfcnpj) === 14) {
            return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cpfcnpj);
        } elseif (strlen($cpfcnpj) === 11) {
            return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cpfcnpj);
        }
        return $cpfcnpj;
    }
}