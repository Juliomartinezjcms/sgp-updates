<?php
class SGP_API_Client {
    private $api_url;
    private $api_cpfcnpj;
    private $api_password;
    private $auth_token;
    private $cache_time;
    private $test_mode = false;
    private $api_token;

    public function init() {
        $this->api_url = get_option('sgp_api_url');
        $this->api_cpfcnpj = get_option('sgp_api_cpfcnpj');
        $this->api_password = get_option('sgp_api_password');
        $this->cache_time = SGP_INTEGRATION_API_CACHE_TIME;
        
        // Se não há credenciais configuradas, ativa modo de teste
        if (empty($this->api_url) || empty($this->api_cpfcnpj) || empty($this->api_password)) {
            $this->test_mode = true;
            sgp_integration_log('API não configurada - Modo de teste ativado', [], 'warning');
        } else {
            $this->authenticate();
        }
    }

    private function authenticate() {
        if (empty($this->api_url) || empty($this->api_cpfcnpj) || empty($this->api_password)) {
            sgp_integration_log('API credentials not configured', [], 'error');
            return false;
        }

        $response = $this->make_request('POST', '/api/central/contratos', [
            'cpfcnpj' => $this->api_cpfcnpj,
            'senha' => $this->api_password
        ], false); // Não usar token para login
        
        if (isset($response['token'])) {
            $this->auth_token = $response['token'];
            set_transient('sgp_api_token', $this->auth_token, $this->cache_time);
            return true;
        } else {
            sgp_integration_log('API authentication failed', $response, 'error');
            return false;
        }
    }

    public function check_coverage($cep, $numero = '') {
        // Modo de teste
        if ($this->test_mode) {
            return $this->get_test_coverage_response($cep, $numero);
        }
        
        $cache_key = 'sgp_coverage_' . $cep . '_' . $numero;
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }

        $response = $this->make_request('POST', '/api/coverage/check', [
            'cep' => preg_replace('/[^0-9]/', '', $cep),
            'numero' => $numero
        ]);
        
        if (!isset($response['error'])) {
            set_transient($cache_key, $response, $this->cache_time);
        }
        
        return $response;
    }

    public function authenticate_customer($credentials) {
        // Modo de teste
        if ($this->test_mode) {
            return $this->get_test_auth_response($credentials);
        }
        
        return $this->make_request('POST', '/api/customer/login', [
            'email' => $credentials['email'],
            'password' => $credentials['password']
        ], false);
    }

    public function create_lead($data) {
        // Modo de teste
        if ($this->test_mode) {
            return $this->get_test_lead_response($data);
        }
        
        $required_fields = ['name', 'email', 'phone', 'cep'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return ['error' => "Campo obrigatório não preenchido: {$field}"];
            }
        }

        // Validação de email
        if (!is_email($data['email'])) {
            return ['error' => 'E-mail inválido'];
        }

        // Validação de CEP
        if (strlen(preg_replace('/[^0-9]/', '', $data['cep'])) !== 8) {
            return ['error' => 'CEP inválido'];
        }

        $response = $this->make_request('POST', '/api/leads/create', $data);
        
        // Se configurado para salvar localmente
        if (get_option('sgp_store_leads_locally') && !isset($response['error'])) {
            $this->store_lead_locally($data, $response);
        }
        
        return $response;
    }

    public function password_recovery($email) {
        if (!is_email($email)) {
            return ['error' => 'E-mail inválido'];
        }

        return $this->make_request('POST', '/api/customer/password-recovery', [
            'email' => $email
        ], false);
    }

    public function validate_token($token) {
        return $this->make_request('GET', '/api/customer/validate-token', [
            'token' => $token
        ], false);
    }

    public function get_customer_invoices($period = 'all') {
        return $this->make_request('GET', '/api/customer/invoices', [
            'period' => $period
        ]);
    }

    public function get_customer_tickets() {
        return $this->make_request('GET', '/api/customer/tickets');
    }

    public function create_ticket($data) {
        $required_fields = ['subject', 'description', 'priority'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return ['error' => "Campo obrigatório não preenchido: {$field}"];
            }
        }

        return $this->make_request('POST', '/api/customer/tickets/create', $data);
    }

    public function update_customer_profile($data) {
        return $this->make_request('PUT', '/api/customer/profile', $data);
    }

    public function request_plan_change($plan_id) {
        return $this->make_request('POST', '/api/customer/plan-change', [
            'plan_id' => $plan_id
        ]);
    }

    public function get_available_plans($cep = '') {
        // Modo de teste
        if ($this->test_mode) {
            return $this->get_test_plans_response($cep);
        }
        
        $cache_key = 'sgp_plans_' . $cep;
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }

        $response = $this->make_request('GET', '/api/plans', [
            'cep' => $cep
        ]);
        
        if (!isset($response['error'])) {
            set_transient($cache_key, $response, $this->cache_time);
        }
        
        return $response;
    }

    public function check_lead_exists($email) {
        return $this->make_request('GET', '/api/leads/check', [
            'email' => $email
        ]);
    }

    public function set_api_url($url) {
        $this->api_url = $url;
    }

    public function set_api_token($token) {
        $this->api_token = $token;
    }

    public function get_api_token() {
        return $this->api_token;
    }

    private function get_token() {
        if (!empty($this->api_token)) return $this->api_token;
        return get_option('sgp_api_token');
    }

    public function call_endpoint($endpoint, $params = [], $method = 'POST') {
        $url = rtrim($this->api_url ?: get_option('sgp_api_url'), '/') . $endpoint;
        $body = array_merge(['token' => $this->get_token()], $params);
        $args = [
            'body' => $body
        ];
        if (strtoupper($method) === 'GET') {
            $url = add_query_arg($body, $url);
            $response = wp_remote_get($url, $args);
        } else {
            $response = wp_remote_post($url, $args);
        }
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        return $json ? $json : ['error' => 'Resposta inválida da API'];
    }

    // Exemplo de endpoint: segunda via de fatura
    public function get_fatura_segunda_via($contrato, $app = 'fortics') {
        return $this->call_endpoint('/api/ura/fatura2via/', [
            'contrato' => $contrato,
            'app' => $app
        ]);
    }

    // Exemplo de endpoint: enviar fatura
    public function enviar_fatura($contrato, $app = 'fortics') {
        return $this->call_endpoint('/api/ura/enviafatura/', [
            'contrato' => $contrato,
            'app' => $app
        ]);
    }

    private function get_headers() {
        $headers = [
            'Content-Type' => 'application/json',
        ];
        if (!empty($this->api_token)) {
            $headers['Authorization'] = 'Bearer ' . $this->api_token;
        }
        return $headers;
    }

    private function make_request($method, $endpoint, $data = [], $use_auth = true) {
        if (empty($this->api_url)) {
            return ['error' => 'API URL não configurada'];
        }
        $url = rtrim($this->api_url, '/') . $endpoint;
        $args = [
            'method' => $method,
            'headers' => $this->get_headers(),
        ];
        if ($method === 'GET') {
            $url = add_query_arg($data, $url);
        } else {
            $args['body'] = json_encode($data);
        }
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        return $json ? $json : ['error' => 'Resposta inválida da API'];
    }

    private function store_lead_locally($data, $api_response) {
        $post_data = [
            'post_title' => $data['name'],
            'post_type' => 'sgp_lead',
            'post_status' => 'publish',
            'meta_input' => [
                'sgp_email' => $data['email'],
                'sgp_phone' => $data['phone'],
                'sgp_cep' => $data['cep'],
                'sgp_api_id' => $api_response['id'] ?? '',
                'sgp_created_at' => current_time('mysql'),
                'sgp_status' => 'new'
            ]
        ];

        if (!empty($data['cpf'])) {
            $post_data['meta_input']['sgp_cpf'] = $data['cpf'];
        }

        if (!empty($data['address'])) {
            $post_data['meta_input']['sgp_address'] = $data['address'];
        }

        wp_insert_post($post_data);
    }

    // ==================== MÉTODOS DE TESTE ====================
    
    private function get_test_coverage_response($cep, $numero) {
        // Simula resposta de cobertura
        $cep_clean = preg_replace('/[^0-9]/', '', $cep);
        
        // CEPs que simulam cobertura disponível
        $available_ceps = ['12345678', '87654321', '11111111', '22222222'];
        
        if (in_array($cep_clean, $available_ceps)) {
            return [
                'available' => true,
                'message' => 'Cobertura disponível na sua região!',
                'plans' => [
                    [
                        'id' => 'plan_1',
                        'name' => 'Plano Básico',
                        'speed' => '50 Mbps',
                        'price' => 49.90,
                        'features' => ['Internet ilimitada', 'Suporte 24h']
                    ],
                    [
                        'id' => 'plan_2',
                        'name' => 'Plano Premium',
                        'speed' => '100 Mbps',
                        'price' => 79.90,
                        'features' => ['Internet ilimitada', 'Suporte 24h', 'WiFi grátis']
                    ]
                ]
            ];
        } else {
            return [
                'available' => false,
                'message' => 'Infelizmente ainda não atendemos sua região.',
                'plans' => []
            ];
        }
    }

    private function get_test_auth_response($credentials) {
        // Simula autenticação de cliente
        $test_users = [
            'teste@teste.com' => '123456',
            'cliente@teste.com' => '123456',
            'admin@teste.com' => '123456'
        ];
        
        if (isset($test_users[$credentials['email']]) && $test_users[$credentials['email']] === $credentials['password']) {
            return [
                'success' => true,
                'token' => 'test_token_' . time(),
                'customer' => [
                    'id' => '12345',
                    'name' => 'Cliente Teste',
                    'email' => $credentials['email'],
                    'phone' => '(11) 99999-9999',
                    'address' => 'Rua Teste, 123',
                    'city' => 'São Paulo',
                    'state' => 'SP'
                ]
            ];
        } else {
            return [
                'error' => 'Credenciais inválidas. Use: teste@teste.com / 123456'
            ];
        }
    }

    private function get_test_lead_response($data) {
        // Simula criação de lead
        return [
            'success' => true,
            'id' => 'lead_' . time(),
            'message' => 'Lead criado com sucesso! Entraremos em contato em breve.',
            'data' => $data
        ];
    }

    private function get_test_plans_response($cep) {
        // Simula lista de planos
        return [
            'plans' => [
                [
                    'id' => 'plan_1',
                    'name' => 'Plano Básico',
                    'speed' => '50 Mbps',
                    'price' => 49.90,
                    'features' => ['Internet ilimitada', 'Suporte 24h'],
                    'description' => 'Ideal para uso doméstico'
                ],
                [
                    'id' => 'plan_2',
                    'name' => 'Plano Premium',
                    'speed' => '100 Mbps',
                    'price' => 79.90,
                    'features' => ['Internet ilimitada', 'Suporte 24h', 'WiFi grátis'],
                    'description' => 'Perfeito para streaming e jogos'
                ],
                [
                    'id' => 'plan_3',
                    'name' => 'Plano Business',
                    'speed' => '200 Mbps',
                    'price' => 149.90,
                    'features' => ['Internet ilimitada', 'Suporte prioritário', 'IP fixo'],
                    'description' => 'Para empresas e home office'
                ]
            ]
        ];
    }

    public function get_api_url() {
        return $this->api_url;
    }
    public function get_api_cpfcnpj() {
        return $this->api_cpfcnpj;
    }
    public function get_api_password() {
        return $this->api_password;
    }

    public function test_token_connection() {
        $response = $this->make_request('GET', '/api/central/contratos', [], true);
        return (isset($response) && !isset($response['error']));
    }

    public function get_ctos() {
        $user = strtolower(trim(get_option('sgp_api_user')));
        $pass = strtolower(trim(get_option('sgp_api_pass')));
        $url = rtrim($this->api_url ?: get_option('sgp_api_url'), '/') . '/api/fttx/splitter/all/';
        $auth_base64 = base64_encode("$user:$pass");
        $args = [
            'headers' => [
                'Authorization' => 'Basic ' . $auth_base64
            ],
            'timeout' => 30 // timeout aumentado para 30 segundos
        ];
        // LOG explícito das credenciais e base64 (apenas para teste)
        sgp_integration_log('Credenciais usadas para CTOs', [
            'user' => $user,
            'pass' => $pass,
            'base64' => $auth_base64
        ], 'debug');
        error_log('[SGP] Solicitando CTOs: ' . $url . ' user: ' . $user . ' headers: ' . print_r($args['headers'], true) . ' timeout: ' . $args['timeout']);
        $start = microtime(true);
        $response = wp_remote_get($url, $args);
        $elapsed = microtime(true) - $start;
        sgp_integration_log('Tempo total da requisição CTOs', ['tempo' => $elapsed], 'debug');
        error_log('[SGP] Tempo total da requisição CTOs: ' . $elapsed . ' segundos');
        if (is_wp_error($response)) {
            sgp_integration_log('Erro ao buscar CTOs', ['erro' => $response->get_error_message(), 'tempo' => $elapsed], 'error');
            error_log('[SGP] Erro ao buscar CTOs: ' . $response->get_error_message() . ' tempo: ' . $elapsed . 's');
            return [];
        }
        $http_code = wp_remote_retrieve_response_code($response);
        $response_headers = wp_remote_retrieve_headers($response);
        sgp_integration_log('Resposta da API CTOs', [
            'http_code' => $http_code,
            'response_headers' => $response_headers,
            'tempo' => $elapsed
        ], 'debug');
        error_log('[SGP] Resposta da API CTOs: HTTP ' . $http_code . ' headers: ' . print_r($response_headers, true) . ' tempo: ' . $elapsed . 's');
        $body = wp_remote_retrieve_body($response);
        // NÃO logar o corpo bruto da resposta
        // sgp_integration_log('Corpo bruto da resposta CTOs', ['body' => $body], 'debug');
        // error_log('[SGP] Corpo bruto da resposta CTOs: ' . $body);
        if (empty($body)) {
            sgp_integration_log('Resposta vazia da API de CTOs', ['tempo' => $elapsed], 'error');
            error_log('[SGP] Resposta vazia da API de CTOs tempo: ' . $elapsed . 's');
            return [];
        }
        $json = json_decode($body, true);
        if (!is_array($json)) {
            sgp_integration_log('JSON inválido ao buscar CTOs', ['body' => $body, 'tempo' => $elapsed], 'error');
            error_log('[SGP] JSON inválido ao buscar CTOs: ' . $body . ' tempo: ' . $elapsed . 's');
            return [];
        }
        // Log resumido: total de CTOs
        $total_ctos = count($json);
        sgp_integration_log('CTOs retornadas', ['total' => $total_ctos, 'tempo' => $elapsed], 'info');
        error_log('[SGP] CTOs retornadas: ' . $total_ctos . ' tempo: ' . $elapsed . 's');
        return $json;
    }

    public function geocode_address($address) {
        $key = get_option('sgp_google_maps_key');
        $url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($address) . '&key=' . $key;
        $log_data = ['address' => $address, 'url' => $url];
        sgp_integration_log('Geocoding request', $log_data, 'info');
        error_log('[SGP] Geocoding request: ' . print_r($log_data, true));
        $response = wp_remote_get($url);
        if (is_wp_error($response)) {
            sgp_integration_log('Geocoding WP Error', ['error' => $response->get_error_message()], 'error');
            error_log('[SGP] Geocoding WP Error: ' . $response->get_error_message());
            return false;
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        sgp_integration_log('Geocoding response', ['address' => $address, 'response' => $data], 'info');
        error_log('[SGP] Geocoding response: ' . print_r(['address' => $address, 'response' => $data], true));
        if (!empty($data['results'][0]['geometry']['location'])) {
            return $data['results'][0]['geometry']['location'];
        }
        return false;
    }

    public function haversine($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 6371000;
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat/2) * sin($dLat/2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon/2) * sin($dLon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $earth_radius * $c;
    }

    public function consulta_viabilidade($cep) {
        $start_time = microtime(true);
        sgp_integration_log('Consulta viabilidade iniciada', ['cep' => $cep], 'info');
        error_log('[SGP] Consulta viabilidade iniciada: ' . $cep);
        
        // Geocodificação do CEP
        $latlng = $this->geocode_address($cep);
        $geo_time = microtime(true);
        sgp_integration_log('Tempo geocodificação CEP', ['cep' => $cep, 'tempo' => $geo_time - $start_time], 'debug');
        if (!$latlng) {
            sgp_integration_log('Falha ao localizar CEP', ['cep' => $cep], 'error');
            error_log('[SGP] Falha ao localizar CEP: ' . $cep);
            return ['error' => 'Não foi possível localizar o CEP.'];
        }
        sgp_integration_log('Coordenadas do CEP', ['cep' => $cep, 'latlng' => $latlng], 'debug');
        
        // Busca CTOs
        $ctos = $this->get_ctos();
        $ctos_time = microtime(true);
        sgp_integration_log('Tempo busca CTOs', ['tempo' => $ctos_time - $geo_time], 'debug');
        sgp_integration_log('CTOs encontrados', ['total' => count($ctos), 'ctos' => $ctos], 'info');
        error_log('[SGP] CTOs encontrados: ' . count($ctos));
        $ctos_sem_localizacao = 0;
        $cto_index = 0;
        foreach ($ctos as $cto) {
            $cto_index++;
            $cto_debug = [
                'index' => $cto_index,
                'ident' => $cto['ident'] ?? '',
                'endereco' => $cto['localization'] ?? '',
                'map_ll' => $cto['map_ll'] ?? '',
                'latitude' => $cto['latitude'] ?? '',
                'longitude' => $cto['longitude'] ?? '',
                'latlong' => $cto['latlong'] ?? ''
            ];
            $cto_latlng = null;
            $motivo_descarte = '';
            // Prioridade map_ll
            if (!empty($cto['map_ll'])) {
                $parts = explode(',', $cto['map_ll']);
                if (count($parts) === 2) {
                    $cto_latlng = [
                        'lat' => floatval($parts[0]),
                        'lng' => floatval($parts[1])
                    ];
                } else {
                    $motivo_descarte = 'map_ll inválido';
                }
            }
            // Latitude/Longitude
            if (!$cto_latlng && !empty($cto['latitude']) && !empty($cto['longitude'])) {
                $cto_latlng = [
                    'lat' => floatval($cto['latitude']),
                    'lng' => floatval($cto['longitude'])
                ];
            } elseif (!$cto_latlng && !empty($cto['latlong'])) {
                $parts = explode(',', $cto['latlong']);
                if (count($parts) === 2) {
                    $cto_latlng = [
                        'lat' => floatval($parts[0]),
                        'lng' => floatval($parts[1])
                    ];
                } else {
                    $motivo_descarte = 'latlong inválido';
                }
            }
            // Geocodificação do endereço da CTO
            if (!$cto_latlng) {
                $cto_address = $cto['localization'] ?? '';
                if (!$cto_address) {
                    $motivo_descarte = 'sem localização';
                    $ctos_sem_localizacao++;
                    $cto_debug['motivo'] = $motivo_descarte;
                    sgp_integration_log('CTO descartada', $cto_debug, 'warning');
                    error_log('[SGP] CTO descartada: ' . print_r($cto_debug, true));
                    continue;
                }
                $cto_latlng = $this->geocode_address($cto_address);
                if (!$cto_latlng) {
                    $motivo_descarte = 'falha geocodificação';
                    $ctos_sem_localizacao++;
                    $cto_debug['motivo'] = $motivo_descarte;
                    sgp_integration_log('CTO descartada', $cto_debug, 'warning');
                    error_log('[SGP] CTO descartada: ' . print_r($cto_debug, true));
                    continue;
                }
            }
            // Log coordenadas da CTO
            sgp_integration_log('CTO processada', [
                'index' => $cto_index,
                'ident' => $cto['ident'] ?? '',
                'latlng' => $cto_latlng,
                'motivo_descarte' => $motivo_descarte
            ], 'debug');
            // Cálculo da distância
            $dist_start = microtime(true);
            $dist = $this->haversine($latlng['lat'], $latlng['lng'], $cto_latlng['lat'], $cto_latlng['lng']);
            $dist_time = microtime(true) - $dist_start;
            $log_dist = [
                'cep' => $cep,
                'cto' => $cto['ident'] ?? '',
                'cto_address' => $cto['localization'] ?? '',
                'cto_latlng' => $cto_latlng,
                'distancia' => $dist,
                'tempo_distancia' => $dist_time
            ];
            sgp_integration_log('Distância calculada', $log_dist, 'info');
            error_log('[SGP] Distância calculada: ' . print_r($log_dist, true));
            if ($dist <= 300) {
                $log_cobertura = [
                    'cep' => $cep,
                    'cto' => $cto['ident'] ?? '',
                    'distancia' => $dist,
                    'tempo_total' => microtime(true) - $start_time
                ];
                sgp_integration_log('Cobertura encontrada', $log_cobertura, 'info');
                error_log('[SGP] Cobertura encontrada: ' . print_r($log_cobertura, true));
                return [
                    'atende' => true,
                    'cto' => $cto,
                    'distancia' => $dist
                ];
            }
        }
        sgp_integration_log('CTOs sem localização', ['total' => $ctos_sem_localizacao], 'warning');
        error_log('[SGP] CTOs sem localização: ' . $ctos_sem_localizacao);
        sgp_integration_log('Fora da área de cobertura', ['cep' => $cep, 'tempo_total' => microtime(true) - $start_time], 'info');
        error_log('[SGP] Fora da área de cobertura: ' . $cep);
        return ['atende' => false];
    }

    public function consulta_viabilidade_completa($dados_endereco) {
        $start_time = microtime(true);
        $endereco_completo = $this->montar_endereco_completo($dados_endereco);
        sgp_integration_log('Consulta viabilidade completa iniciada', [
            'dados' => $dados_endereco,
            'endereco_completo' => $endereco_completo
        ], 'info');
        error_log('[SGP] Consulta viabilidade completa iniciada: ' . $endereco_completo);
        $latlng = $this->geocode_address($endereco_completo);
        $geo_time = microtime(true);
        sgp_integration_log('Tempo geocodificação endereço completo', [
            'endereco' => $endereco_completo,
            'tempo' => $geo_time - $start_time
        ], 'debug');
        if (!$latlng) {
            sgp_integration_log('Falha ao localizar endereço completo', [
                'endereco' => $endereco_completo
            ], 'error');
            error_log('[SGP] Falha ao localizar endereço completo: ' . $endereco_completo);
            return [
                'error' => 'Não foi possível localizar o endereço informado.',
                'available' => false
            ];
        }
        sgp_integration_log('Coordenadas do endereço completo', [
            'endereco' => $endereco_completo,
            'latlng' => $latlng
        ], 'debug');
        $ctos = $this->get_ctos();
        $ctos_time = microtime(true);
        $total_ctos = count($ctos);
        // Filtrar CTOs na mesma cidade e no mesmo CEP
        $cidade = strtolower($dados_endereco['city']);
        $cep = preg_replace('/[^0-9]/', '', $dados_endereco['cep']);
        $ctos_mesma_cidade = 0;
        $ctos_mesmo_cep = 0;
        foreach ($ctos as $cto) {
            $cto_cidade = '';
            $cto_cep = '';
            if (!empty($cto['localization'])) {
                $parts = explode(',', $cto['localization']);
                if (count($parts) >= 2) {
                    $cto_cidade = strtolower(trim($parts[count($parts)-3] ?? ''));
                    $cto_cep = preg_replace('/[^0-9]/', '', trim($parts[count($parts)-2] ?? ''));
                }
            }
            if ($cto_cidade && strpos($cidade, $cto_cidade) !== false) {
                $ctos_mesma_cidade++;
            }
            if ($cto_cep && $cto_cep === $cep) {
                $ctos_mesmo_cep++;
            }
        }
        sgp_integration_log('Resumo CTOs localização', [
            'total' => $total_ctos,
            'mesma_cidade' => $ctos_mesma_cidade,
            'mesmo_cep' => $ctos_mesmo_cep
        ], 'info');
        error_log('[SGP] CTOs: total=' . $total_ctos . ' mesma_cidade=' . $ctos_mesma_cidade . ' mesmo_cep=' . $ctos_mesmo_cep);
        // Busca CTO mais próxima e verifica raio de 750m
        $ctos_sem_localizacao = 0;
        $cto_mais_proxima = null;
        $distancia_mais_proxima = PHP_FLOAT_MAX;
        foreach ($ctos as $cto) {
            $cto_latlng = $this->extrair_coordenadas_cto($cto);
            if (!$cto_latlng) {
                $ctos_sem_localizacao++;
                continue;
            }
            $dist = $this->haversine($latlng['lat'], $latlng['lng'], $cto_latlng['lat'], $cto_latlng['lng']);
            // Log da distância calculada
            sgp_integration_log('Distância calculada', [
                'endereco' => $endereco_completo,
                'cto' => $cto['ident'] ?? '',
                'cto_latlng' => $cto_latlng,
                'distancia' => $dist
            ], 'debug');
            // Verifica se está dentro do novo raio de cobertura (750m)
            if ($dist <= 750) {
                sgp_integration_log('Cobertura encontrada', [
                    'endereco' => $endereco_completo,
                    'cto' => $cto['ident'] ?? '',
                    'distancia' => $dist,
                    'tempo_total' => microtime(true) - $start_time
                ], 'info');
                return [
                    'available' => true,
                    'address' => $endereco_completo,
                    'cto' => $cto,
                    'distance' => round($dist, 2),
                    'plans' => $this->get_available_plans($dados_endereco['cep'])
                ];
            }
            // Guarda a CTO mais próxima para referência
            if ($dist < $distancia_mais_proxima) {
                $distancia_mais_proxima = $dist;
                $cto_mais_proxima = $cto;
            }
        }
        // Logar a menor distância encontrada e a CTO mais próxima
        sgp_integration_log('CTO mais próxima', [
            'cto' => $cto_mais_proxima['ident'] ?? 'N/A',
            'distancia' => round($distancia_mais_proxima, 2)
        ], 'info');
        error_log('[SGP] CTO mais próxima: ' . ($cto_mais_proxima['ident'] ?? 'N/A') . ' distancia=' . round($distancia_mais_proxima, 2) . 'm');
        sgp_integration_log('CTOs sem localização', ['total' => $ctos_sem_localizacao], 'warning');
        sgp_integration_log('Fora da área de cobertura', [
            'endereco' => $endereco_completo,
            'cto_mais_proxima' => $cto_mais_proxima['ident'] ?? 'N/A',
            'distancia_mais_proxima' => round($distancia_mais_proxima, 2),
            'tempo_total' => microtime(true) - $start_time
        ], 'info');
        return [
            'available' => false,
            'address' => $endereco_completo,
            'closest_cto' => $cto_mais_proxima,
            'closest_distance' => round($distancia_mais_proxima, 2)
        ];
    }

    private function montar_endereco_completo($dados) {
        $partes = [];
        
        // Adiciona rua e número
        if (!empty($dados['street']) && !empty($dados['number'])) {
            $partes[] = $dados['street'] . ', ' . $dados['number'];
        }
        
        // Adiciona complemento se existir
        if (!empty($dados['complement'])) {
            $partes[] = $dados['complement'];
        }
        
        // Adiciona bairro
        if (!empty($dados['neighborhood'])) {
            $partes[] = $dados['neighborhood'];
        }
        
        // Adiciona cidade e estado
        if (!empty($dados['city']) && !empty($dados['state'])) {
            $partes[] = $dados['city'] . ' - ' . $dados['state'];
        }
        
        // Adiciona CEP
        if (!empty($dados['cep'])) {
            $partes[] = $dados['cep'];
        }
        
        // Adiciona Brasil
        $partes[] = 'Brasil';
        
        return implode(', ', $partes);
    }

    private function extrair_coordenadas_cto($cto) {
        // Prioridade 1: map_ll
        if (!empty($cto['map_ll'])) {
            $parts = explode(',', $cto['map_ll']);
            if (count($parts) === 2) {
                return [
                    'lat' => floatval($parts[0]),
                    'lng' => floatval($parts[1])
                ];
            }
        }
        
        // Prioridade 2: latitude/longitude
        if (!empty($cto['latitude']) && !empty($cto['longitude'])) {
            return [
                'lat' => floatval($cto['latitude']),
                'lng' => floatval($cto['longitude'])
            ];
        }
        
        // Prioridade 3: latlong
        if (!empty($cto['latlong'])) {
            $parts = explode(',', $cto['latlong']);
            if (count($parts) === 2) {
                return [
                    'lat' => floatval($parts[0]),
                    'lng' => floatval($parts[1])
                ];
            }
        }
        
        // Prioridade 4: geocodificação do endereço
        if (!empty($cto['localization'])) {
            return $this->geocode_address($cto['localization']);
        }
        
        return null;
    }
}