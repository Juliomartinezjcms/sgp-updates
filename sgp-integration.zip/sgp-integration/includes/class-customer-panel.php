<?php
class Customer_Panel {
    private $api_client;

    public function __construct($api_client) {
        $this->api_client = $api_client;
    }

    public function init() {
        add_shortcode('sgp_customer_panel', [$this, 'render_customer_panel']);
        $this->register_ajax_handlers();
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function enqueue_scripts() {
        if (has_shortcode(get_the_content(), 'sgp_customer_panel')) {
            wp_enqueue_script(
                'sgp-customer-panel',
                SGP_INTEGRATION_URL . 'assets/js/customer-panel.js',
                ['jquery', 'sgp-integration-frontend'],
                SGP_INTEGRATION_VERSION,
                true
            );
        }
    }

    public function render_customer_panel($atts = []) {
        $atts = shortcode_atts([
            'show_login' => 'true',
            'redirect_url' => home_url('/area-do-cliente')
        ], $atts);

        if (!is_user_logged_in()) {
            if ($atts['show_login'] === 'true') {
                return $this->render_login_form();
            } else {
                return '<p>' . __('Faça login para acessar sua área do cliente.', 'sgp-integration') . '</p>';
            }
        }
        
        $user = wp_get_current_user();
        if (!in_array('sgp_customer', $user->roles)) {
            return '<p>' . __('Acesso restrito a clientes SGP.', 'sgp-integration') . '</p>';
        }
        
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/customer-dashboard.php';
        return ob_get_clean();
    }

    private function render_login_form() {
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/customer-login.php';
        return ob_get_clean();
    }

    public function register_ajax_handlers() {
        // Login
        add_action('wp_ajax_nopriv_customer_login', [$this, 'ajax_customer_login']);
        add_action('wp_ajax_customer_login', [$this, 'ajax_customer_login']);
        
        // Recuperação de senha
        add_action('wp_ajax_nopriv_customer_password_recovery', [$this, 'ajax_password_recovery']);
        add_action('wp_ajax_customer_password_recovery', [$this, 'ajax_password_recovery']);
        
        // Verificação de sessão
        add_action('wp_ajax_nopriv_customer_check_session', [$this, 'ajax_check_session']);
        add_action('wp_ajax_customer_check_session', [$this, 'ajax_check_session']);

        // Logout
        add_action('wp_ajax_customer_logout', [$this, 'ajax_customer_logout']);

        // Faturas
        add_action('wp_ajax_get_customer_invoices', [$this, 'ajax_get_invoices']);

        // Tickets
        add_action('wp_ajax_get_customer_tickets', [$this, 'ajax_get_tickets']);
        add_action('wp_ajax_create_customer_ticket', [$this, 'ajax_create_ticket']);

        // Perfil
        add_action('wp_ajax_update_customer_profile', [$this, 'ajax_update_profile']);

        // Planos
        add_action('wp_ajax_request_plan_change', [$this, 'ajax_request_plan_change']);
    }

    public function ajax_customer_login() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $email = sanitize_email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($email) || empty($password)) {
            wp_send_json_error([
                'message' => __('Preencha todos os campos obrigatórios.', 'sgp-integration'),
                'fields' => empty($email) ? ['email'] : ['password']
            ]);
        }
        
        // Integração com a API do SGP
        $response = $this->api_client->authenticate_customer([
            'email' => $email,
            'password' => $password
        ]);
        
        if (isset($response['error'])) {
            // Incrementa tentativas de login
            $transient_name = 'sgp_login_attempts_' . $_SERVER['REMOTE_ADDR'];
            $attempts = get_transient($transient_name) ?: 0;
            set_transient($transient_name, $attempts + 1, SGP_LOGIN_TIMEOUT);
            
            wp_send_json_error([
                'message' => $response['error']
            ]);
        }

        // Login bem-sucedido
        if (isset($response['token'])) {
            // Cria ou atualiza usuário WordPress
            $user_id = $this->create_or_update_customer_user($response['customer'], $email);
            
            if ($user_id) {
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id, true);
                
                // Armazena token SGP
                update_user_meta($user_id, 'sgp_auth_token', $response['token']);
                
                wp_send_json_success([
                    'redirect_url' => home_url('/area-do-cliente'),
                    'message' => __('Login realizado com sucesso!', 'sgp-integration')
                ]);
            }
        }
        
        wp_send_json_error([
            'message' => __('Erro ao processar login.', 'sgp-integration')
        ]);
    }

    public function ajax_password_recovery() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $email = sanitize_email($_POST['email'] ?? '');
        
        if (!is_email($email)) {
            wp_send_json_error(['message' => __('E-mail inválido.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->password_recovery($email);
        
        if (isset($response['error'])) {
            wp_send_json_error([
                'message' => $response['error']
            ]);
        }
        
        wp_send_json_success([
            'message' => __('Enviamos um e-mail com instruções para redefinir sua senha.', 'sgp-integration')
        ]);
    }

    public function ajax_check_session() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $token = sanitize_text_field($_POST['token'] ?? '');
        
        if (empty($token)) {
            wp_send_json_error(['message' => __('Sessão inválida.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->validate_token($token);
        
        if (isset($response['error'])) {
            wp_send_json_error([
                'message' => __('Sessão expirada.', 'sgp-integration')
            ]);
        }
        
        wp_send_json_success([
            'redirect_url' => home_url('/area-do-cliente')
        ]);
    }

    public function ajax_customer_logout() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            delete_user_meta($user_id, 'sgp_auth_token');
            wp_logout();
        }
        
        wp_send_json_success([
            'redirect_url' => home_url(),
            'message' => __('Logout realizado com sucesso.', 'sgp-integration')
        ]);
    }

    public function ajax_get_invoices() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $period = sanitize_text_field($_POST['period'] ?? 'all');
        $response = $this->api_client->get_customer_invoices($period);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_get_tickets() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->get_customer_tickets();
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_create_ticket() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $data = [
            'subject' => sanitize_text_field($_POST['subject'] ?? ''),
            'description' => sanitize_textarea_field($_POST['description'] ?? ''),
            'priority' => sanitize_text_field($_POST['priority'] ?? 'medium')
        ];
        
        $response = $this->api_client->create_ticket($data);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_update_profile() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $data = [
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'address' => sanitize_text_field($_POST['address'] ?? '')
        ];
        
        $response = $this->api_client->update_customer_profile($data);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_request_plan_change() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $plan_id = sanitize_text_field($_POST['plan_id'] ?? '');
        
        if (empty($plan_id)) {
            wp_send_json_error(['message' => __('Plano não especificado.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->request_plan_change($plan_id);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    private function create_or_update_customer_user($customer_data, $email) {
        $user = get_user_by('email', $email);
        
        if ($user) {
            // Atualiza usuário existente
            $user_data = [
                'ID' => $user->ID,
                'display_name' => $customer_data['name'] ?? $user->display_name,
                'first_name' => $customer_data['name'] ?? $user->first_name
            ];
            
            wp_update_user($user_data);
            
            // Adiciona role se não tiver
            if (!in_array('sgp_customer', $user->roles)) {
                $user->add_role('sgp_customer');
            }
            
            return $user->ID;
        } else {
            // Cria novo usuário
            $user_data = [
                'user_login' => $email,
                'user_email' => $email,
                'user_pass' => wp_generate_password(),
                'display_name' => $customer_data['name'] ?? '',
                'first_name' => $customer_data['name'] ?? '',
                'role' => 'sgp_customer'
            ];
            
            $user_id = wp_insert_user($user_data);
            
            if (is_wp_error($user_id)) {
                return false;
            }
            
            return $user_id;
        }
    }
}