<?php
class Customer_Panel {
    private $api_client;

    public function __construct($api_client) {
        $this->api_client = $api_client;
    }

    public function init() {
        add_shortcode('sgp_customer_panel', [$this, 'render_customer_panel']);
        $this->register_ajax_handlers();
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function enqueue_scripts() {
        if (has_shortcode(get_the_content(), 'sgp_customer_panel')) {
            wp_enqueue_script(
                'sgp-customer-panel',
                SGP_INTEGRATION_URL . 'assets/js/customer-panel.js',
                ['jquery', 'sgp-integration-frontend'],
                SGP_INTEGRATION_VERSION,
                true
            );
        }
    }

    public function render_customer_panel($atts = []) {
        $atts = shortcode_atts([
            'show_login' => 'true',
            'redirect_url' => home_url('/area-do-cliente')
        ], $atts);

        if (!is_user_logged_in()) {
            if ($atts['show_login'] === 'true') {
                return $this->render_login_form();
            } else {
                return '<p>' . __('Faça login para acessar sua área do cliente.', 'sgp-integration') . '</p>';
            }
        }
        
        $user = wp_get_current_user();
        if (!in_array('sgp_customer', $user->roles)) {
            return '<p>' . __('Acesso restrito a clientes SGP.', 'sgp-integration') . '</p>';
        }
        
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/customer-dashboard.php';
        return ob_get_clean();
    }

    private function render_login_form() {
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/customer-login.php';
        return ob_get_clean();
    }

    public function register_ajax_handlers() {
        // Login
        add_action('wp_ajax_nopriv_customer_login', [$this, 'ajax_customer_login']);
        add_action('wp_ajax_customer_login', [$this, 'ajax_customer_login']);
        
        // Recuperação de senha
        add_action('wp_ajax_nopriv_customer_password_recovery', [$this, 'ajax_password_recovery']);
        add_action('wp_ajax_customer_password_recovery', [$this, 'ajax_password_recovery']);
        
        // Verificação de sessão
        add_action('wp_ajax_nopriv_customer_check_session', [$this, 'ajax_check_session']);
        add_action('wp_ajax_customer_check_session', [$this, 'ajax_check_session']);

        // Logout
        add_action('wp_ajax_customer_logout', [$this, 'ajax_customer_logout']);
        
        // Verificação de sessão
        add_action('wp_ajax_verify_customer_session', [$this, 'ajax_verify_customer_session']);

        // Faturas/Títulos
        add_action('wp_ajax_get_customer_invoices', [$this, 'ajax_get_invoices']);
        add_action('wp_ajax_get_customer_contracts', [$this, 'ajax_get_contracts']);
        add_action('wp_ajax_generate_invoice_pix', [$this, 'ajax_generate_pix']);
        add_action('wp_ajax_get_second_copy', [$this, 'ajax_get_second_copy']);

        // Chamados/Tickets
        add_action('wp_ajax_get_customer_tickets', [$this, 'ajax_get_tickets']);
        add_action('wp_ajax_create_customer_ticket', [$this, 'ajax_create_ticket']);
        add_action('wp_ajax_update_customer_ticket', [$this, 'ajax_update_ticket']);
        add_action('wp_ajax_add_ticket_note', [$this, 'ajax_add_ticket_note']);

        // Perfil
        add_action('wp_ajax_update_customer_profile', [$this, 'ajax_update_profile']);
        add_action('wp_ajax_verify_customer_access', [$this, 'ajax_verify_access']);

        // Planos
        add_action('wp_ajax_request_plan_change', [$this, 'ajax_request_plan_change']);
    }

    public function ajax_customer_login() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $cpfcnpj = sanitize_text_field($_POST['cpfcnpj'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($cpfcnpj) || empty($password)) {
            wp_send_json_error([
                'message' => __('Preencha todos os campos obrigatórios.', 'sgp-integration'),
                'fields' => empty($cpfcnpj) ? ['cpfcnpj'] : ['password']
            ]);
        }
        
        // Remove caracteres especiais do CPF/CNPJ
        $cpfcnpj = preg_replace('/[^0-9]/', '', $cpfcnpj);
        
        // Validação de CPF/CNPJ
        if (strlen($cpfcnpj) !== 11 && strlen($cpfcnpj) !== 14) {
            wp_send_json_error([
                'message' => __('CPF/CNPJ inválido.', 'sgp-integration')
            ]);
        }
        
        // Integração com a API do SGP
        $response = $this->api_client->authenticate_sgp_customer($cpfcnpj, $password);
        
        if (isset($response['error'])) {
            // Incrementa tentativas de login
            $transient_name = 'sgp_login_attempts_' . $_SERVER['REMOTE_ADDR'];
            $attempts = get_transient($transient_name) ?: 0;
            set_transient($transient_name, $attempts + 1, SGP_LOGIN_TIMEOUT);
            
            wp_send_json_error([
                'message' => $response['error']
            ]);
        }

        // Login bem-sucedido - verifica se há contratos
        if (isset($response['auth']) && $response['auth'] === true && isset($response['contratos'])) {
            // Cria ou atualiza usuário WordPress
            $user_id = $this->create_or_update_customer_user($response, $cpfcnpj);
            
            if ($user_id) {
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id, true);
                
                // Armazena dados SGP básicos
                update_user_meta($user_id, 'sgp_cpfcnpj', $cpfcnpj);
                update_user_meta($user_id, 'sgp_password', base64_encode($password)); // Armazena senha encoded
                
                // Busca contratos detalhados com endereço e ordenação
                $contratos_detalhados = $this->buscar_contratos_detalhados($cpfcnpj, $password, $response['contratos']);
                
                // Salva contratos detalhados
                update_user_meta($user_id, 'sgp_contracts', json_encode($contratos_detalhados));
                update_user_meta($user_id, 'sgp_contracts_last_update', current_time('mysql'));
                
        
                
                wp_send_json_success([
                    'redirect_url' => home_url('/area-do-cliente'),
                    'message' => __('Login realizado com sucesso!', 'sgp-integration'),
                    'contracts_count' => count($contratos_detalhados)
                ]);
            }
        }
        
        wp_send_json_error([
            'message' => __('Erro ao processar login ou credenciais inválidas.', 'sgp-integration')
        ]);
    }

    /**
     * Busca contratos detalhados com endereço e ordenação
     */
    private function buscar_contratos_detalhados($cpfcnpj, $password, $contratos_basicos) {
        $contratos_processados = [];
        

        
        foreach ($contratos_basicos as $contrato) {
            $contrato_id = $contrato['contrato'] ?? '';
            
            // Dados básicos do contrato
            $contrato_data = [
                'contrato' => $contrato_id,
                'razaosocial' => $contrato['razaosocial'] ?? '',
                'status' => $contrato['status'] ?? '',
                'planointernet' => $contrato['planointernet'] ?? '',
                'vencimento' => $contrato['vencimento'] ?? '',
                'endereco' => '', // Será preenchido abaixo
                'data_criacao' => $contrato['data_criacao'] ?? $contrato['created_at'] ?? '',
                'data_ativacao' => $contrato['data_ativacao'] ?? $contrato['activated_at'] ?? '',
            ];
            
            // Processa endereço usando função dedicada
            $contrato_data['endereco'] = $this->processar_endereco_contrato($contrato, $cpfcnpj, $password, $contrato_id);
            
            // Normaliza data para ordenação (se não houver data específica, usa o número do contrato como fallback)
            if (empty($contrato_data['data_criacao']) && empty($contrato_data['data_ativacao'])) {
                // Usa o número do contrato como indicador de ordem (contratos maiores = mais novos)
                $contrato_data['sort_order'] = intval($contrato_id);
            } else {
                // Usa a data mais recente disponível
                $data_ordenacao = $contrato_data['data_criacao'] ?: $contrato_data['data_ativacao'];
                $contrato_data['sort_order'] = strtotime($data_ordenacao) ?: intval($contrato_id);
            }
            
            $contratos_processados[] = $contrato_data;
        }
        
        // Ordena contratos: mais novos primeiro
        usort($contratos_processados, function($a, $b) {
            return $b['sort_order'] - $a['sort_order'];
        });
        
        // Remove campo temporário de ordenação
        foreach ($contratos_processados as &$contrato) {
            unset($contrato['sort_order']);
        }
        

        
        return $contratos_processados;
    }

    /**
     * Processa endereço do contrato, lidando com formatos estruturados ou simples
     */
    private function processar_endereco_contrato($contrato, $cpfcnpj = null, $password = null, $contrato_id = null) {
        // 1. Verifica endereço simples primeiro
        if (isset($contrato['endereco']) && is_string($contrato['endereco']) && !empty($contrato['endereco'])) {
            return $contrato['endereco'];
        }
        
        // 2. Processa endereço de instalação estruturado
        if (isset($contrato['endereco_instalacao']) && is_array($contrato['endereco_instalacao'])) {
            return $this->formatar_endereco_estruturado($contrato['endereco_instalacao']);
        }
        
        // 3. Processa endereço de cobrança estruturado como fallback
        if (isset($contrato['endereco_cobranca']) && is_array($contrato['endereco_cobranca'])) {
            return $this->formatar_endereco_estruturado($contrato['endereco_cobranca']);
        }
        
        // 4. Tenta montar endereço a partir de campos separados
        if (isset($contrato['logradouro'])) {
            $endereco_parts = [];
            if (!empty($contrato['logradouro'])) {
                $endereco_parts[] = $contrato['logradouro'];
            }
            if (!empty($contrato['numero'])) {
                $endereco_parts[] = $contrato['numero'];
            }
            if (!empty($contrato['bairro'])) {
                $endereco_parts[] = $contrato['bairro'];
            }
            if (!empty($contrato['cidade'])) {
                $endereco_parts[] = $contrato['cidade'];
            }
            if (!empty($endereco_parts)) {
                return implode(', ', $endereco_parts);
            }
        }
        
        // 5. Se não conseguir extrair endereço e temos credenciais, busca via API (apenas para contratos ativos)
        if ($cpfcnpj && $password && $contrato_id) {
            $status = trim($contrato['status'] ?? '');
            if (stripos($status, 'ativo') !== false || empty($status)) {
                try {
                    $access_info = $this->api_client->verificar_acesso($cpfcnpj, $password, $contrato_id);
                    if (isset($access_info['endereco']) && is_string($access_info['endereco'])) {
                        return $access_info['endereco'];
                    } elseif (isset($access_info['localizacao']) && is_string($access_info['localizacao'])) {
                        return $access_info['localizacao'];
                    }
                } catch (Exception $e) {

                }
            }
        }
        
        return 'Endereço não disponível';
    }

    /**
     * Formata um objeto de endereço estruturado em string
     */
    private function formatar_endereco_estruturado($endereco_obj) {
        if (!is_array($endereco_obj)) {
            return 'Endereço inválido';
        }
        
        $partes = [];
        
        // Logradouro
        if (!empty($endereco_obj['logradouro'])) {
            $logradouro = $endereco_obj['logradouro'];
            
            // Adiciona número se disponível
            if (!empty($endereco_obj['numero'])) {
                $logradouro .= ', ' . $endereco_obj['numero'];
            }
            
            $partes[] = $logradouro;
        }
        
        // Complemento
        if (!empty($endereco_obj['complemento'])) {
            $partes[] = $endereco_obj['complemento'];
        }
        
        // Bairro
        if (!empty($endereco_obj['bairro'])) {
            $partes[] = $endereco_obj['bairro'];
        }
        
        // Cidade e UF
        $cidade_uf = [];
        if (!empty($endereco_obj['cidade'])) {
            $cidade_uf[] = $endereco_obj['cidade'];
        }
        if (!empty($endereco_obj['uf'])) {
            $cidade_uf[] = $endereco_obj['uf'];
        }
        if (!empty($cidade_uf)) {
            $partes[] = implode(' - ', $cidade_uf);
        }
        
        // CEP
        if (!empty($endereco_obj['cep'])) {
            $partes[] = 'CEP: ' . $endereco_obj['cep'];
        }
        
        return !empty($partes) ? implode(', ', $partes) : 'Endereço incompleto';
    }

    public function ajax_password_recovery() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $email = sanitize_email($_POST['email'] ?? '');
        
        if (!is_email($email)) {
            wp_send_json_error(['message' => __('E-mail inválido.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->password_recovery($email);
        
        if (isset($response['error'])) {
            wp_send_json_error([
                'message' => $response['error']
            ]);
        }
        
        wp_send_json_success([
            'message' => __('Enviamos um e-mail com instruções para redefinir sua senha.', 'sgp-integration')
        ]);
    }

    public function ajax_check_session() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        $token = sanitize_text_field($_POST['token'] ?? '');
        
        if (empty($token)) {
            wp_send_json_error(['message' => __('Sessão inválida.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->validate_token($token);
        
        if (isset($response['error'])) {
            wp_send_json_error([
                'message' => __('Sessão expirada.', 'sgp-integration')
            ]);
        }
        
        wp_send_json_success([
            'redirect_url' => home_url('/area-do-cliente')
        ]);
    }

    public function ajax_customer_logout() {
        check_ajax_referer('sgp-customer-nonce', 'nonce');
        
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            delete_user_meta($user_id, 'sgp_auth_token');
            wp_logout();
        }
        
        wp_send_json_success([
            'redirect_url' => home_url(),
            'message' => __('Logout realizado com sucesso.', 'sgp-integration')
        ]);
    }

    public function ajax_verify_customer_session() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        // Verifica se o usuário está logado
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'message' => __('Usuário não está logado.', 'sgp-integration'),
                'code' => 'not_logged_in'
            ]);
        }
        
        // Verifica se o usuário tem a role correta
        $user = wp_get_current_user();
        if (!in_array('sgp_customer', $user->roles)) {
            wp_send_json_error([
                'message' => __('Usuário não tem permissão de cliente SGP.', 'sgp-integration'),
                'code' => 'invalid_role'
            ]);
        }
        
        // Verifica se os dados SGP ainda existem
        $user_id = get_current_user_id();
        $sgp_cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        
        if (empty($sgp_cpfcnpj)) {
            wp_send_json_error([
                'message' => __('Dados SGP não encontrados.', 'sgp-integration'),
                'code' => 'missing_sgp_data'
            ]);
        }
        
        // Tudo OK - sessão válida
        wp_send_json_success([
            'message' => __('Sessão válida.', 'sgp-integration'),
            'user_id' => $user_id,
            'cpfcnpj' => $sgp_cpfcnpj
        ]);
    }

    public function ajax_get_contracts() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        $senha_log = (strlen($password) > 6) ? substr($password,0,3).'***'.substr($password,-3) : $password;
        

        
        $response = $this->api_client->listar_contratos($cpfcnpj, $password);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        $contratos = $response['contratos'] ?? [];
        
        if (!is_array($contratos)) {
            wp_send_json_success([]);
        }

        // LOG DETALHADO DOS CONTRATOS RECEBIDOS DA API
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_DEBUG] [ajax_get_contracts] Contratos recebidos da API:');
            foreach ($contratos as $index => $contrato) {
                $status_original = $contrato['status'] ?? 'N/A';
                $contrato_id = $contrato['contrato'] ?? 'N/A';
                error_log("[SGP_DEBUG] Contrato {$index}: ID={$contrato_id}, Status='{$status_original}'");
            }
        }
        
        // Processa e enriquece os dados dos contratos
        $contratos_processados = [];
        
        foreach ($contratos as $contrato) {
            $contrato_id = $contrato['contrato'] ?? '';
            
            // Dados básicos do contrato
            $contrato_data = [
                'contrato' => $contrato_id,
                'razaosocial' => $contrato['razaosocial'] ?? '',
                'status' => $contrato['status'] ?? '',
                'planointernet' => $contrato['planointernet'] ?? '',
                'vencimento' => $contrato['vencimento'] ?? '',
                'endereco' => '', // Será preenchido abaixo
                'data_criacao' => $contrato['data_criacao'] ?? $contrato['created_at'] ?? '', // Para ordenação
                'data_ativacao' => $contrato['data_ativacao'] ?? $contrato['activated_at'] ?? '',
            ];
            
            // Processa endereço usando função dedicada
            $contrato_data['endereco'] = $this->processar_endereco_contrato($contrato, $cpfcnpj, $password, $contrato_id);
            
            // Normaliza data para ordenação (se não houver data específica, usa o número do contrato como fallback)
            if (empty($contrato_data['data_criacao']) && empty($contrato_data['data_ativacao'])) {
                // Usa o número do contrato como indicador de ordem (contratos maiores = mais novos)
                $contrato_data['sort_order'] = intval($contrato_id);
            } else {
                // Usa a data mais recente disponível
                $data_ordenacao = $contrato_data['data_criacao'] ?: $contrato_data['data_ativacao'];
                $contrato_data['sort_order'] = strtotime($data_ordenacao) ?: intval($contrato_id);
            }
            
            $contratos_processados[] = $contrato_data;
        }
        
        // Ordena contratos: mais novos primeiro
        usort($contratos_processados, function($a, $b) {
            return $b['sort_order'] - $a['sort_order'];
        });
        
        // Remove campo temporário de ordenação
        foreach ($contratos_processados as &$contrato) {
            unset($contrato['sort_order']);
        }
        
        // Loga apenas um resumo dos contratos processados
        $resumo = array_map(function($c) {
            // Garante que o endereço seja string antes de usar substr()
            $endereco_str = '';
            if (is_string($c['endereco'])) {
                $endereco_str = $c['endereco'];
            } elseif (is_array($c['endereco'])) {
                $endereco_str = json_encode($c['endereco']);
            } else {
                $endereco_str = 'N/A';
            }
            
            return [
                'contrato' => $c['contrato'],
                'status' => $c['status'],
                'razaosocial' => $c['razaosocial'],
                'endereco' => strlen($endereco_str) > 50 ? substr($endereco_str, 0, 50) . '...' : $endereco_str
            ];
        }, $contratos_processados);
        

        
        wp_send_json_success($contratos_processados);
    }

    public function ajax_get_invoices() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        $period = sanitize_text_field($_POST['period'] ?? 'all');

        // Validação básica dos dados
        if (empty($cpfcnpj) || empty($password) || empty($contrato)) {
            // Validação silenciosa - não retorna erro
            return;
        }

        // LOG BÁSICO DE DEBUG
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_FATURAS] Consulta iniciada - Contrato: ' . $contrato . ' | Período: ' . $period);
        }
        
        // Obtém o status do contrato para incluir na resposta
        $contract_status = $this->get_contract_status($contrato);
        $status_message = $this->get_contract_status_message($contrato);
        
        // Chama a API SGP
        $response = $this->api_client->listar_titulos($cpfcnpj, $password, $contrato);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_FATURAS] Resposta da API: ' . (is_array($response) ? 'Array com ' . count($response) . ' itens' : 'Não é array'));
        }

        // Trata erros da API
        if (isset($response['error'])) {
            wp_send_json_error([
                'message' => $response['error'],
                'contract_id' => $contrato,
                'contract_status' => $contract_status
            ]);
        }
        
        // Trata resposta HTML (não JSON)
        if (isset($response['html_response'])) {
            wp_send_json_error([
                'message' => 'API retornou dados inválidos',
                'contract_id' => $contrato,
                'contract_status' => $contract_status
            ]);
        }
        
        // Processa e normaliza as faturas
        $faturas = $this->process_invoices_data($response, $period);
        
        // Monta resposta estruturada
        $response_data = [
            'faturas' => $faturas,
            'contract_status' => $contract_status,
            'status_message' => $status_message,
            'is_inactive' => $contract_status !== 'active',
            'contract_id' => $contrato,
            'period' => $period,
            'total_invoices' => count($faturas)
        ];
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_FATURAS] Resposta final: ' . count($faturas) . ' faturas encontradas');
        }
        
        wp_send_json_success($response_data);
    }
    
    /**
     * Processa e normaliza dados de faturas da API
     */
    private function process_invoices_data($response, $period = 'all') {
        if (!is_array($response)) {
            return [];
        }
        
        $faturas = [];
        
        // Extrai faturas de diferentes estruturas de resposta
        if (isset($response['faturas']) && is_array($response['faturas'])) {
            $faturas = $response['faturas'];
        } elseif (isset($response['links']) && is_array($response['links'])) {
            $faturas = $response['links'];
        } elseif (isset($response[0]) && is_array($response[0])) {
            $faturas = $response;
        } else {
            // Tenta encontrar array de faturas em outras estruturas
            foreach ($response as $key => $value) {
                if (is_array($value) && !empty($value) && isset($value[0]) && is_array($value[0])) {
                    $first_item = $value[0];
                    $invoice_fields = ['fatura', 'valor', 'vencimento', 'status', 'id', 'numero'];
                    
                    if (array_intersect(array_keys($first_item), $invoice_fields)) {
                        $faturas = $value;
                        break;
                    }
                }
            }
        }
        
        // Normaliza cada fatura
        $normalized_faturas = [];
        foreach ($faturas as $fatura) {
            if (!is_array($fatura)) continue;
            
            $normalized_fatura = $this->normalize_invoice_data($fatura);
            
            // Aplica filtro por período se necessário
            if ($this->should_include_invoice($normalized_fatura, $period)) {
                $normalized_faturas[] = $normalized_fatura;
            }
        }
        
        // Ordena faturas por vencimento (mais recentes primeiro)
        usort($normalized_faturas, function($a, $b) {
            $date_a = $this->parse_date($a['vencimento']);
            $date_b = $this->parse_date($b['vencimento']);
            
            if (!$date_a || !$date_b) return 0;
            
            return $date_b <=> $date_a;
        });
        
        return $normalized_faturas;
    }
    
    /**
     * Normaliza dados de uma fatura individual
     */
    private function normalize_invoice_data($fatura) {
        $normalized = [
            // Mapeamento fiel à resposta da API SGP
            'fatura'           => $fatura['numero_documento'] ?? $fatura['fatura'] ?? $fatura['id'] ?? $fatura['numero'] ?? 'N/A',
            'numero'           => $fatura['numero_documento'] ?? $fatura['fatura'] ?? $fatura['id'] ?? $fatura['numero'] ?? 'N/A',
            'vencimento'       => $this->normalize_date($fatura['vencimento_atualizado'] ?? $fatura['vencimento'] ?? null),
            'valor'            => $this->normalize_currency($fatura['valorcorrigido'] ?? $fatura['valor'] ?? 0),
            'status'           => $fatura['status'] ?? 'N/A',
            'link'             => $fatura['link'] ?? null,
            'id'               => $fatura['id'] ?? null,
            'gerarpix'         => $fatura['gerarpix'] ?? false,
            'linhadigitavel'   => $fatura['linhadigitavel'] ?? null,
            'data_pagamento'   => $this->normalize_date($fatura['data_pagamento'] ?? null),
            'statusid'         => $fatura['statusid'] ?? null,
            'codigopix'        => $fatura['codigopix'] ?? null,
            // Campo para debug e compatibilidade
            'original_data'    => $fatura
        ];
        return $normalized;
    }
    
    /**
     * Normaliza data para formato d/m/Y
     */
    private function normalize_date($date) {
        if (!$date) return 'N/A';
        
        $date_formats = [
            'Y-m-d',
            'd/m/Y',
            'Y/m/d',
            'd-m-Y'
        ];
        
        foreach ($date_formats as $format) {
            $date_obj = DateTime::createFromFormat($format, $date);
            if ($date_obj && $date_obj->format($format) === $date) {
                return $date_obj->format('d/m/Y');
            }
        }
        
        return $date;
    }
    
    /**
     * Normaliza valor monetário
     */
    private function normalize_currency($value) {
        if (!$value || $value === 0) return 0;
        
        if (is_numeric($value)) {
            return (float) $value;
        }
        
        // Remove formatação se for string
        $cleaned = preg_replace('/[^0-9,.-]/', '', $value);
        $cleaned = str_replace(',', '.', $cleaned);
        
        return (float) $cleaned;
    }
    
    /**
     * Normaliza status da fatura
     */
    private function normalize_status($status) {
        if (!$status) return 'N/A';
        
        $status = strtoupper(trim($status));
        
        // Padronização de status
        $status_map = [
            'EM ABERTO' => 'EM ABERTO',
            'GERADO' => 'EM ABERTO',
            'PENDENTE' => 'EM ABERTO',
            'PAGO' => 'PAGO',
            'VENCIDO' => 'VENCIDO',
            'CANCELADO' => 'CANCELADO'
        ];
        
        return $status_map[$status] ?? $status;
    }
    
    /**
     * Verifica se a fatura deve ser incluída baseado no período
     */
    private function should_include_invoice($fatura, $period) {
        if ($period === 'all') return true;
        
        $vencimento = $this->parse_date($fatura['vencimento']);
        if (!$vencimento) return true;
        
        $now = new DateTime();
        
        switch ($period) {
            case 'last_3_months':
                $limit = $now->modify('-3 months');
                break;
            case 'last_6_months':
                $limit = $now->modify('-6 months');
                break;
            case 'current_year':
                $limit = new DateTime($now->format('Y-01-01'));
                break;
            default:
                return true;
        }
        
        return $vencimento >= $limit;
    }
    
    /**
     * Converte string de data para objeto DateTime
     */
    private function parse_date($date_string) {
        if (!$date_string || $date_string === 'N/A') return null;
        
        $date_formats = [
            'd/m/Y',
            'Y-m-d',
            'Y/m/d',
            'd-m-Y'
        ];
        
        foreach ($date_formats as $format) {
            $date_obj = DateTime::createFromFormat($format, $date_string);
            if ($date_obj && $date_obj->format($format) === $date_string) {
                return $date_obj;
            }
        }
        
        return null;
    }

    public function ajax_get_tickets() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        
        // Obtém o status do contrato para incluir na resposta
        $contract_status = $this->get_contract_status($contrato);
        $status_message = $this->get_contract_status_message($contrato);
        
        // Chama o novo endpoint de ocorrências
        $response = $this->api_client->listar_ocorrencias($contrato);
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_API_LOG] /api/ura/ocorrencia/list/ - Retorno: ' . print_r($response, true));
        }
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        // Inclui informações de status do contrato na resposta
        $response_data = [
            'chamados' => $response,
            'contract_status' => $contract_status,
            'status_message' => $status_message,
            'is_inactive' => $contract_status !== 'active'
        ];
        
        wp_send_json_success($response_data);
    }

    /**
     * Normaliza os dados de um chamado para o padrão esperado pelo frontend
     */
    private function normalize_ticket_data($ticket) {
        return [
            'id' => $ticket['os'] ?? $ticket['id'] ?? '',
            'subject' => $ticket['assunto'] ?? '',
            'department_label' => $ticket['departamento'] ?? '',
            'created_at' => $ticket['data_cadastro'] ?? '',
            'status' => $ticket['status'] ?? '',
            'status_label' => $this->get_status_label($ticket['status'] ?? null),
            // Inclua outros campos conforme necessário
            'oc_status' => $ticket['oc_status'] ?? '',
            'cliente' => $ticket['cliente'] ?? '',
            'data_agendamento' => $ticket['data_agendamento'] ?? '',
            'data_finalizacao' => $ticket['data_finalizacao'] ?? '',
        ];
    }

    /**
     * Traduz o status numérico para texto legível
     */
    private function get_status_label($status) {
        switch ($status) {
            case 1: return 'Aberto';
            case 2: return 'Em andamento';
            case 3: return 'Finalizado';
            default: return 'Desconhecido';
        }
    }

    public function ajax_create_ticket() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        $conteudo = sanitize_textarea_field($_POST['conteudo'] ?? '');
        $contato = sanitize_text_field($_POST['contato'] ?? '');
        $contato_numero = sanitize_text_field($_POST['contato_numero'] ?? '');
        $motivoos = sanitize_text_field($_POST['motivoos'] ?? '40');
        $sem_os = sanitize_text_field($_POST['sem_os'] ?? '1');
        $ocorrenciatipo = sanitize_text_field($_POST['ocorrenciatipo'] ?? '5');
        
        if (empty($cpfcnpj) || empty($password) || empty($contrato) || empty($conteudo)) {
            wp_send_json_error(['message' => __('Dados obrigatórios não preenchidos.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->criar_chamado(
            $cpfcnpj, $password, $contrato, $conteudo, 
            $contato, $contato_numero, $motivoos, $sem_os, $ocorrenciatipo
        );
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_update_ticket() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        
        $chamado_id = sanitize_text_field($_POST['chamado_id'] ?? '');
        $dados = [
            'os_anotacao' => sanitize_textarea_field($_POST['os_anotacao'] ?? ''),
            'os_observacao' => sanitize_textarea_field($_POST['os_observacao'] ?? ''),
            'os_data_agendamento' => sanitize_text_field($_POST['os_data_agendamento'] ?? ''),
            'os_status' => sanitize_text_field($_POST['os_status'] ?? ''),
            'ocorrencia_encerrar' => sanitize_text_field($_POST['ocorrencia_encerrar'] ?? ''),
            'ocorrencia_conteudo' => sanitize_textarea_field($_POST['ocorrencia_conteudo'] ?? '')
        ];
        
        if (empty($cpfcnpj) || empty($password) || empty($chamado_id)) {
            wp_send_json_error(['message' => __('Dados obrigatórios não preenchidos.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->atualizar_chamado($cpfcnpj, $password, $chamado_id, $dados);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_add_ticket_note() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        
        $chamado_id = sanitize_text_field($_POST['chamado_id'] ?? '');
        $anotacao = sanitize_textarea_field($_POST['anotacao'] ?? '');
        
        if (empty($cpfcnpj) || empty($password) || empty($chamado_id) || empty($anotacao)) {
            wp_send_json_error(['message' => __('Dados obrigatórios não preenchidos.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->criar_anotacao_chamado($cpfcnpj, $password, $chamado_id, $anotacao);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_verify_access() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        
        $senha_log = (strlen($password) > 6) ? substr($password,0,3).'***'.substr($password,-3) : $password;
        $response = $this->api_client->verificar_acesso($cpfcnpj, $password, $contrato);
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[SGP_API_LOG] /api/central/verificaacesso/ - Retorno: ' . print_r($response, true));
        }
        if (isset($response['error'])) {
            $mensagem = $response['error'];
            if (isset($response['response'])) {
                $detalhe = json_decode($response['response'], true);
                if (isset($detalhe['detail'])) {
                    $mensagem .= ' - ' . $detalhe['detail'];
                }
            }

            wp_send_json_error(['message' => $mensagem]);
        }

        wp_send_json_success($response);
    }

    public function ajax_get_second_copy() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        
        if (empty($cpfcnpj) || empty($password) || empty($contrato)) {
            wp_send_json_error(['message' => __('Dados necessários não encontrados.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->fatura_segunda_via($cpfcnpj, $password, $contrato);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_generate_pix() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $user_id = get_current_user_id();
        $cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
        $password = base64_decode(get_user_meta($user_id, 'sgp_password', true));
        $contrato = sanitize_text_field($_POST['contrato'] ?? '');
        $fatura_id = sanitize_text_field($_POST['fatura_id'] ?? '');
        
        if (empty($cpfcnpj) || empty($password) || empty($contrato) || empty($fatura_id)) {
            wp_send_json_error(['message' => __('Dados necessários não encontrados.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->gerar_pix($cpfcnpj, $password, $contrato, $fatura_id);

        // Verifica se houve erro explícito
        if (isset($response['error'])) {
            wp_send_json_error(['message' => $response['error']]);
        }

        // Verifica se veio código PIX válido
        if (!isset($response['codigo_pix']) || empty($response['codigo_pix'])) {
            wp_send_json_error(['message' => 'A API não retornou um código PIX válido. Verifique os parâmetros ou consulte o suporte.', 'debug' => $response]);
        }

        wp_send_json_success($response);
    }

    public function ajax_update_profile() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $data = [
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'address' => sanitize_text_field($_POST['address'] ?? '')
        ];
        
        $response = $this->api_client->update_customer_profile($data);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    public function ajax_request_plan_change() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => __('Usuário não autenticado.', 'sgp-integration')]);
        }
        
        $plan_id = sanitize_text_field($_POST['plan_id'] ?? '');
        
        if (empty($plan_id)) {
            wp_send_json_error(['message' => __('Plano não especificado.', 'sgp-integration')]);
        }
        
        $response = $this->api_client->request_plan_change($plan_id);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }
        
        wp_send_json_success($response);
    }

    private function create_or_update_customer_user($sgp_response, $cpfcnpj) {
        // Busca por usuário existente pelo CPF/CNPJ
        $existing_user = get_users([
            'meta_key' => 'sgp_cpfcnpj',
            'meta_value' => $cpfcnpj,
            'number' => 1
        ]);
        
        if (!empty($existing_user)) {
            $user = $existing_user[0];
            
            // Atualiza dados do usuário
            $user_data = [
                'ID' => $user->ID,
                'display_name' => $sgp_response['razaosocial'] ?? $user->display_name,
                'first_name' => $sgp_response['razaosocial'] ?? $user->first_name
            ];
            
            wp_update_user($user_data);
            
            // Adiciona role se não tiver
            if (!in_array('sgp_customer', $user->roles)) {
                $user->add_role('sgp_customer');
            }
            
            return $user->ID;
        } else {
            // Cria novo usuário
            $user_data = [
                'user_login' => 'sgp_' . $cpfcnpj,
                'user_email' => 'cliente_' . $cpfcnpj . '@' . parse_url(home_url(), PHP_URL_HOST),
                'user_pass' => wp_generate_password(),
                'display_name' => $sgp_response['razaosocial'] ?? 'Cliente SGP',
                'first_name' => $sgp_response['razaosocial'] ?? 'Cliente SGP',
                'role' => 'sgp_customer'
            ];
            
            $user_id = wp_insert_user($user_data);
            
            if (is_wp_error($user_id)) {
                return false;
            }
            
            // Salva CPF/CNPJ como meta
            update_user_meta($user_id, 'sgp_cpfcnpj', $cpfcnpj);
            
            return $user_id;
        }
    }

    private function get_contract_status($contrato) {
        $user_id = get_current_user_id();
        $contracts_json = get_user_meta($user_id, 'sgp_contracts', true);
        
        if (empty($contracts_json)) {
            return 'unknown';
        }
        
        $contracts = json_decode($contracts_json, true);
        if (!is_array($contracts)) {
            return 'unknown';
        }
        
        foreach ($contracts as $contract) {
            if (isset($contract['contrato']) && $contract['contrato'] == $contrato) {
                $status = trim($contract['status'] ?? '');
                if (empty($status)) {
                    return 'active';
                }
                return strtolower($status);
            }
        }
        
        return 'unknown';
    }

    private function get_contract_status_message($contrato) {
        $user_id = get_current_user_id();
        $contracts_json = get_user_meta($user_id, 'sgp_contracts', true);
        
        if (empty($contracts_json)) {
            return 'Status do contrato não disponível';
        }
        
        $contracts = json_decode($contracts_json, true);
        if (!is_array($contracts)) {
            return 'Status do contrato não disponível';
        }
        
        foreach ($contracts as $contract) {
            if (isset($contract['contrato']) && $contract['contrato'] == $contrato) {
                $status = trim($contract['status'] ?? '');
                if (empty($status)) {
                    return 'Contrato ativo';
                }
                return 'Contrato ' . $status;
            }
        }
        
        return 'Contrato não encontrado';
    }
}