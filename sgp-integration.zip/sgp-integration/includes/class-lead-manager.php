<?php
class Lead_Manager {
    private $api_client;

    public function __construct($api_client) {
        $this->api_client = $api_client;
    }

    public function init() {
        add_action('wp_ajax_check_coverage', [$this, 'ajax_check_coverage']);
        add_action('wp_ajax_nopriv_check_coverage', [$this, 'ajax_check_coverage']);
        add_action('wp_ajax_create_lead', [$this, 'ajax_create_lead']);
        add_action('wp_ajax_nopriv_create_lead', [$this, 'ajax_create_lead']);
        add_action('wp_ajax_get_available_plans', [$this, 'ajax_get_available_plans']);
        add_action('wp_ajax_nopriv_get_available_plans', [$this, 'ajax_get_available_plans']);
        
        // Shortcode para formulário de disponibilidade
        add_shortcode('sgp_availability_form', [$this, 'render_availability_form']);
        add_shortcode('sgp_plan_list', [$this, 'render_plan_list']);
    }

    public function render_availability_form($atts = []) {
        $atts = shortcode_atts([
            'show_plans' => 'true',
            'redirect_url' => ''
        ], $atts);

        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/availability-form.php';
        return ob_get_clean();
    }

    public function render_plan_list($atts = []) {
        $atts = shortcode_atts([
            'cep' => '',
            'show_prices' => 'true',
            'show_features' => 'true'
        ], $atts);

        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/plan-list.php';
        return ob_get_clean();
    }

    public function ajax_check_coverage() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        // Validação dos campos obrigatórios
        $required_fields = ['cep', 'street', 'number', 'neighborhood', 'city', 'state'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (!empty($missing_fields)) {
            wp_send_json_error([
                'message' => 'Preencha todos os campos obrigatórios: ' . implode(', ', $missing_fields)
            ]);
        }
        
        // Validação do CEP
        $cep = preg_replace('/[^0-9]/', '', $_POST['cep']);
        if (strlen($cep) !== 8) {
            wp_send_json_error(['message' => 'CEP inválido. Digite os 8 números.']);
        }
        
        // Validação do checkbox de termos
        if (empty($_POST['terms'])) {
            wp_send_json_error(['message' => 'Você deve concordar com os termos para continuar.']);
        }
        
        // Sanitiza os dados do endereço
        $dados_endereco = [
            'cep' => $cep,
            'street' => sanitize_text_field($_POST['street']),
            'number' => sanitize_text_field($_POST['number']),
            'complement' => sanitize_text_field($_POST['complement'] ?? ''),
            'neighborhood' => sanitize_text_field($_POST['neighborhood']),
            'city' => sanitize_text_field($_POST['city']),
            'state' => sanitize_text_field($_POST['state']),
            'reference' => sanitize_text_field($_POST['reference'] ?? '')
        ];
        
        // Log da consulta
        sgp_integration_log('Consulta de viabilidade iniciada', [
            'dados' => $dados_endereco,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ], 'info');
        
        // Executa a consulta de viabilidade completa
        $response = $this->api_client->consulta_viabilidade_completa($dados_endereco);
        
        // Log do resultado
        sgp_integration_log('Resultado da consulta de viabilidade', [
            'dados' => $dados_endereco,
            'resultado' => $response
        ], 'info');
        
        if (isset($response['error'])) {
            wp_send_json_error(['message' => $response['error']]);
        }
        
        // Retorna resposta formatada para o frontend
        if ($response['available']) {
            wp_send_json_success([
                'available' => true,
                'address' => $response['address'],
                'plans' => $response['plans'] ?? []
            ]);
        } else {
            wp_send_json_success([
                'available' => false,
                'address' => $response['address']
            ]);
        }
    }

    public function ajax_create_lead() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        $data = $this->sanitize_lead_data($_POST);
        
        // Validações adicionais
        $validation = $this->validate_lead_data($data);
        if ($validation !== true) {
            wp_send_json_error(['message' => $validation]);
        }

        $response = $this->api_client->create_lead($data);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }

        // Log do lead criado
        sgp_integration_log('Lead created', [
            'email' => $data['email'],
            'cep' => $data['cep'],
            'api_response' => $response
        ]);

        wp_send_json_success([
            'message' => __('Solicitação enviada com sucesso! Entraremos em contato em breve.', 'sgp-integration'),
            'lead_id' => $response['id'] ?? null
        ]);
    }

    public function ajax_get_available_plans() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        $cep = preg_replace('/[^0-9]/', '', $_POST['cep'] ?? '');
        
        if (!empty($cep) && strlen($cep) !== 8) {
            wp_send_json_error(['message' => __('CEP inválido.', 'sgp-integration')]);
        }

        $response = $this->api_client->get_available_plans($cep);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }

        wp_send_json_success($response);
    }

    private function sanitize_lead_data($post_data) {
        return [
            'name' => sanitize_text_field($post_data['name'] ?? ''),
            'email' => sanitize_email($post_data['email'] ?? ''),
            'phone' => sanitize_text_field($post_data['phone'] ?? ''),
            'cpf' => preg_replace('/[^0-9]/', '', $post_data['cpf'] ?? ''),
            'cep' => preg_replace('/[^0-9]/', '', $post_data['cep'] ?? ''),
            'numero' => sanitize_text_field($post_data['numero'] ?? ''),
            'address' => sanitize_text_field($post_data['address'] ?? ''),
            'city' => sanitize_text_field($post_data['city'] ?? ''),
            'state' => sanitize_text_field($post_data['state'] ?? ''),
            'plan_id' => sanitize_text_field($post_data['plan_id'] ?? ''),
            'source' => sanitize_text_field($post_data['source'] ?? 'website'),
            'utm_source' => sanitize_text_field($post_data['utm_source'] ?? ''),
            'utm_medium' => sanitize_text_field($post_data['utm_medium'] ?? ''),
            'utm_campaign' => sanitize_text_field($post_data['utm_campaign'] ?? ''),
            'notes' => sanitize_textarea_field($post_data['notes'] ?? ''),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => current_time('mysql')
        ];
    }

    private function validate_lead_data($data) {
        // Campos obrigatórios
        $required_fields = ['name', 'email', 'phone', 'cep'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return sprintf(__('Campo obrigatório não preenchido: %s', 'sgp-integration'), $field);
            }
        }

        // Validação de email
        if (!is_email($data['email'])) {
            return __('E-mail inválido.', 'sgp-integration');
        }

        // Validação de CEP
        if (strlen($data['cep']) !== 8) {
            return __('CEP inválido. Digite os 8 números.', 'sgp-integration');
        }

        // Validação de telefone (mínimo 10 dígitos)
        $phone_clean = preg_replace('/[^0-9]/', '', $data['phone']);
        if (strlen($phone_clean) < 10) {
            return __('Telefone inválido.', 'sgp-integration');
        }

        // Validação de CPF (se fornecido)
        if (!empty($data['cpf']) && !$this->validate_cpf($data['cpf'])) {
            return __('CPF inválido.', 'sgp-integration');
        }

        // Verificar se já existe lead com este email
        if ($this->lead_exists($data['email'])) {
            return __('Já existe uma solicitação com este e-mail. Entraremos em contato em breve.', 'sgp-integration');
        }

        return true;
    }

    private function validate_cpf($cpf) {
        // Remove caracteres não numéricos
        $cpf = preg_replace('/[^0-9]/', '', $cpf);
        
        // Verifica se tem 11 dígitos
        if (strlen($cpf) != 11) {
            return false;
        }
        
        // Verifica se todos os dígitos são iguais
        if (preg_match('/(\d)\1{10}/', $cpf)) {
            return false;
        }
        
        // Calcula os dígitos verificadores
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf[$c] * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf[$c] != $d) {
                return false;
            }
        }
        
        return true;
    }

    private function lead_exists($email) {
        // Verifica se existe lead local
        if (get_option('sgp_store_leads_locally')) {
            $existing_leads = get_posts([
                'post_type' => 'sgp_lead',
                'meta_query' => [
                    [
                        'key' => 'sgp_email',
                        'value' => $email,
                        'compare' => '='
                    ]
                ],
                'posts_per_page' => 1
            ]);
            
            if (!empty($existing_leads)) {
                return true;
            }
        }

        // Verifica na API (se disponível)
        $response = $this->api_client->check_lead_exists($email);
        return isset($response['exists']) && $response['exists'];
    }

    public function get_leads_stats() {
        if (!get_option('sgp_store_leads_locally')) {
            return [];
        }

        $total_leads = wp_count_posts('sgp_lead');
        $recent_leads = get_posts([
            'post_type' => 'sgp_lead',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ]);

        return [
            'total' => $total_leads->publish,
            'recent' => $recent_leads
        ];
    }

    public function export_leads($format = 'csv') {
        if (!get_option('sgp_store_leads_locally')) {
            return false;
        }

        $leads = get_posts([
            'post_type' => 'sgp_lead',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ]);

        if ($format === 'csv') {
            return $this->export_to_csv($leads);
        }

        return $leads;
    }

    private function export_to_csv($leads) {
        $filename = 'sgp-leads-' . date('Y-m-d-H-i-s') . '.csv';
        $filepath = wp_upload_dir()['basedir'] . '/' . $filename;
        
        $handle = fopen($filepath, 'w');
        
        // Cabeçalho
        fputcsv($handle, [
            'ID',
            'Nome',
            'E-mail',
            'Telefone',
            'CPF',
            'CEP',
            'Endereço',
            'Cidade',
            'Estado',
            'Plano',
            'Status',
            'Data de Criação'
        ]);
        
        foreach ($leads as $lead) {
            $meta = get_post_meta($lead->ID);
            fputcsv($handle, [
                $lead->ID,
                $lead->post_title,
                $meta['sgp_email'][0] ?? '',
                $meta['sgp_phone'][0] ?? '',
                $meta['sgp_cpf'][0] ?? '',
                $meta['sgp_cep'][0] ?? '',
                $meta['sgp_address'][0] ?? '',
                $meta['sgp_city'][0] ?? '',
                $meta['sgp_state'][0] ?? '',
                $meta['sgp_plan_id'][0] ?? '',
                $meta['sgp_status'][0] ?? 'new',
                $lead->post_date
            ]);
        }
        
        fclose($handle);
        
        return [
            'file' => $filepath,
            'url' => wp_upload_dir()['baseurl'] . '/' . $filename,
            'filename' => $filename
        ];
    }
}