<?php
class Lead_Manager {
    private $api_client;

    public function __construct($api_client) {
        $this->api_client = $api_client;
    }

    public function init() {
        add_action('wp_ajax_check_coverage', [$this, 'ajax_check_coverage']);
        add_action('wp_ajax_nopriv_check_coverage', [$this, 'ajax_check_coverage']);
        add_action('wp_ajax_create_lead', [$this, 'ajax_create_lead']);
        add_action('wp_ajax_nopriv_create_lead', [$this, 'ajax_create_lead']);
        add_action('wp_ajax_get_available_plans', [$this, 'ajax_get_available_plans']);
        add_action('wp_ajax_nopriv_get_available_plans', [$this, 'ajax_get_available_plans']);

        
        // Shortcode para formulário de disponibilidade
        add_shortcode('sgp_availability_form', [$this, 'render_availability_form']);
        add_shortcode('sgp_plan_list', [$this, 'render_plan_list']);
        // Shortcode para formulário de lead
        add_shortcode('sgp_lead_form', [$this, 'render_lead_form']);
        // Shortcode para formulário duplo (etapas)
        add_shortcode('sgp_duo_form', [$this, 'render_duo_form']);
    }

    public function render_availability_form($atts = []) {
        $atts = shortcode_atts([
            'show_plans' => 'true',
            'redirect_url' => ''
        ], $atts);

        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/availability-form.php';
        return ob_get_clean();
    }

    public function render_plan_list($atts = []) {
        $atts = shortcode_atts([
            'cep' => '',
            'show_prices' => 'true',
            'show_features' => 'true'
        ], $atts);

        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/plan-list.php';
        return ob_get_clean();
    }

    public function render_lead_form($atts = []) {
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/lead-form.php';
        return ob_get_clean();
    }

    public function render_duo_form($atts = []) {
        ob_start();
        include SGP_INTEGRATION_PATH . 'templates/duo-form.php';
        return ob_get_clean();
    }

    public function ajax_check_coverage() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        error_log('[SGP_DEBUG] ===== AJAX CHECK_COVERAGE INICIADO =====');
        error_log('[SGP_DEBUG] POST data: ' . print_r($_POST, true));
        
        // Validação dos campos obrigatórios
        $required_fields = ['cep', 'street', 'number', 'neighborhood', 'city', 'state'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (!empty($missing_fields)) {
            error_log('[SGP_DEBUG] ERRO: Campos obrigatórios em falta: ' . implode(', ', $missing_fields));
            wp_send_json_error([
                'message' => 'Preencha todos os campos obrigatórios: ' . implode(', ', $missing_fields)
            ]);
        }
        
        // Validação do CEP
        $cep = preg_replace('/[^0-9]/', '', $_POST['cep']);
        if (strlen($cep) !== 8) {
            error_log('[SGP_DEBUG] ERRO: CEP inválido: ' . $cep);
            wp_send_json_error(['message' => 'CEP inválido. Digite os 8 números.']);
        }
        
        // Validação do checkbox de termos
        if (empty($_POST['terms'])) {
            error_log('[SGP_DEBUG] ERRO: Termos não aceitos');
            wp_send_json_error(['message' => 'Você deve concordar com os termos para continuar.']);
        }
        
        // Sanitiza os dados do endereço
        $dados_endereco = [
            'cep' => $cep,
            'street' => sanitize_text_field($_POST['street']),
            'number' => sanitize_text_field($_POST['number']),
            'complement' => sanitize_text_field($_POST['complement'] ?? ''),
            'neighborhood' => sanitize_text_field($_POST['neighborhood']),
            'city' => sanitize_text_field($_POST['city']),
            'state' => sanitize_text_field($_POST['state']),
            'reference' => sanitize_text_field($_POST['reference'] ?? '')
        ];
        
        error_log('[SGP_DEBUG] Dados do endereço sanitizados: ' . print_r($dados_endereco, true));
        
        // Executa a consulta de viabilidade completa
        error_log('[SGP_DEBUG] Chamando consulta_viabilidade_completa...');
        $response = $this->api_client->consulta_viabilidade_completa($dados_endereco);
        error_log('[SGP_DEBUG] Resposta da consulta: ' . print_r($response, true));
        
        // Salva a consulta na tabela personalizada com os dados corretos do formulário
        $dados_para_salvar = [
            'cep' => $dados_endereco['cep'],
            'endereco' => $dados_endereco['street'],
            'numero' => $dados_endereco['number'],
            'bairro' => $dados_endereco['neighborhood'],
            'cidade' => $dados_endereco['city'],
            'estado' => $dados_endereco['state'],
            'resultado' => isset($response['available']) && $response['available'] ? 'Disponível' : 'Indisponível',
            'disponivel' => isset($response['available']) && $response['available'] ? 1 : 0,
        ];
        
        error_log('[SGP_DEBUG] Dados para salvar na tabela: ' . print_r($dados_para_salvar, true));
        
        // Preparar detalhes específicos apenas com distâncias DOS VALORES JÁ CALCULADOS
        $detalhes_distancias = null;
        if (isset($response['available']) && $response['available'] && isset($response['route_info'])) {
            // CASO APROVADO: Usar os valores que JÁ VIERAM CALCULADOS da consulta
            $metros_rota = $response['route_info']['distance_meters'];
            $metros_linear = isset($response['linear_distance']) ? round($response['linear_distance'] * 1000) : round($metros_rota * 0.92);
            
            $detalhes_distancias = "dist linha: {$metros_linear}m / dist rota: {$metros_rota}m";
        } elseif (isset($response['available']) && !$response['available'] && isset($response['closest_route_info'])) {
            // CASO NEGADO: Mostrar apenas distância da CTO mais próxima (formato simples)
            $metros_rota_closest = $response['closest_route_info']['distance_meters'];
            
            $detalhes_distancias = "CTO prox: {$metros_rota_closest}m";
        }
        
        $insert_id = \SGP_Integration::inserir_consulta($dados_para_salvar, $detalhes_distancias);
        error_log('[SGP_DEBUG] ID inserido na tabela consultas: ' . $insert_id);
        
        if (isset($response['error'])) {
            error_log('[SGP_DEBUG] ERRO na resposta da API: ' . $response['error']);
            wp_send_json_error(['message' => $response['error']]);
        }
        
        // Retorna resposta formatada para o frontend
        if (isset($response['available']) && $response['available']) {
            error_log('[SGP_DEBUG] ✅ Enviando resposta DISPONÍVEL para o frontend');
            wp_send_json_success([
                'available' => true,
                'address' => $response['address'],
                'plans' => $response['plans'] ?? []
            ]);
        } else {
            error_log('[SGP_DEBUG] ❌ Enviando resposta NÃO DISPONÍVEL para o frontend');
            wp_send_json_success([
                'available' => false,
                'address' => $response['address'] ?? 'Endereço não encontrado'
            ]);
        }
        
        error_log('[SGP_DEBUG] ===== AJAX CHECK_COVERAGE FINALIZADO =====');
    }

    public function ajax_create_lead() {
        // Verificar e criar tabelas se necessário
        $this->ensure_tables_exist();
        
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        $data = [
            'nome' => sanitize_text_field($_POST['nome'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'telefone' => sanitize_text_field($_POST['telefone'] ?? ''),
            // NOVO: Dados do endereço da etapa 1
            'cep' => sanitize_text_field($_POST['cep_endereco'] ?? ''),
            'endereco' => sanitize_text_field($_POST['endereco_completo'] ?? ''),
            'numero' => sanitize_text_field($_POST['numero_endereco'] ?? ''),
            'bairro' => sanitize_text_field($_POST['bairro_endereco'] ?? ''),
            'cidade' => sanitize_text_field($_POST['cidade_endereco'] ?? ''),
            'estado' => sanitize_text_field($_POST['estado_endereco'] ?? ''),
            'viabilidade_aprovada' => (int)($_POST['viabilidade_aprovada'] ?? 0),
        ];
        
        // Validação completa (dados pessoais + endereço + viabilidade)
        $required_fields = ['nome', 'email', 'telefone', 'cep', 'endereco', 'numero', 'bairro', 'cidade', 'estado'];
        $missing_fields = [];
        
        // Nota: viabilidade_aprovada não precisa estar nos required pois pode ser 0 (falso)
        
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (!empty($missing_fields)) {
            wp_send_json_error(['message' => 'Dados incompletos. Campos vazios: ' . implode(', ', $missing_fields)]);
        }
        
        // Salva na tabela personalizada
        $lead_id = \SGP_Integration::inserir_lead($data);
        
        if ($lead_id) {
            wp_send_json_success(['message' => 'Em breve entraremos em contato']);
        } else {
            wp_send_json_error(['message' => 'Erro ao cadastrar lead.']);
        }
    }

    // Função para garantir que as tabelas existem
    private function ensure_tables_exist() {
        global $wpdb;
        
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        // Verifica se as tabelas existem
        $leads_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads;
        $consultas_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas;
        
        if (!$leads_exists || !$consultas_exists) {
            $this->create_tables();
        }
    }
    
    // Função para criar as tabelas
    private function create_tables() {
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        $table_leads = $wpdb->prefix . 'sgp_leads';

        $sql_consultas = "CREATE TABLE $table_consultas (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            cep varchar(20) NOT NULL,
            endereco varchar(255) NOT NULL,
            numero varchar(50) NOT NULL,
            bairro varchar(100) NOT NULL,
            cidade varchar(100) NOT NULL,
            estado varchar(50) NOT NULL,
            resultado varchar(255) DEFAULT NULL,
            disponivel tinyint(1) DEFAULT 0,
            data_consulta datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            detalhes longtext DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql_leads = "CREATE TABLE $table_leads (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            nome varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            telefone varchar(50) NOT NULL,
            cep varchar(20) NOT NULL,
            endereco varchar(255) NOT NULL,
            numero varchar(50) NOT NULL,
            bairro varchar(100) NOT NULL,
            cidade varchar(100) NOT NULL,
            estado varchar(50) NOT NULL,
            viabilidade_aprovada tinyint(1) NOT NULL DEFAULT 0,
            data_lead datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $result_consultas = dbDelta($sql_consultas);
        $result_leads = dbDelta($sql_leads);
    }

    public function ajax_get_available_plans() {
        check_ajax_referer('sgp-integration-nonce', 'nonce');
        
        $cep = preg_replace('/[^0-9]/', '', $_POST['cep'] ?? '');
        
        if (!empty($cep) && strlen($cep) !== 8) {
            wp_send_json_error(['message' => __('CEP inválido.', 'sgp-integration')]);
        }

        $response = $this->api_client->get_available_plans($cep);
        
        if (isset($response['error'])) {
            wp_send_json_error($response);
        }

        wp_send_json_success($response);
    }

    private function sanitize_lead_data($post_data) {
        return [
            'name' => sanitize_text_field($post_data['name'] ?? ''),
            'email' => sanitize_email($post_data['email'] ?? ''),
            'phone' => sanitize_text_field($post_data['phone'] ?? ''),
            'cpf' => preg_replace('/[^0-9]/', '', $post_data['cpf'] ?? ''),
            'cep' => preg_replace('/[^0-9]/', '', $post_data['cep'] ?? ''),
            'numero' => sanitize_text_field($post_data['numero'] ?? ''),
            'address' => sanitize_text_field($post_data['address'] ?? ''),
            'city' => sanitize_text_field($post_data['city'] ?? ''),
            'state' => sanitize_text_field($post_data['state'] ?? ''),
            'plan_id' => sanitize_text_field($post_data['plan_id'] ?? ''),
            'source' => sanitize_text_field($post_data['source'] ?? 'website'),
            'utm_source' => sanitize_text_field($post_data['utm_source'] ?? ''),
            'utm_medium' => sanitize_text_field($post_data['utm_medium'] ?? ''),
            'utm_campaign' => sanitize_text_field($post_data['utm_campaign'] ?? ''),
            'notes' => sanitize_textarea_field($post_data['notes'] ?? ''),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => current_time('mysql')
        ];
    }

    private function validate_lead_data($data) {
        // Campos obrigatórios
        $required_fields = ['name', 'email', 'phone', 'cep'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                return sprintf(__('Campo obrigatório não preenchido: %s', 'sgp-integration'), $field);
            }
        }

        // Validação de email
        if (!is_email($data['email'])) {
            return __('E-mail inválido.', 'sgp-integration');
        }

        // Validação de CEP
        if (strlen($data['cep']) !== 8) {
            return __('CEP inválido. Digite os 8 números.', 'sgp-integration');
        }

        // Validação de telefone (mínimo 10 dígitos)
        $phone_clean = preg_replace('/[^0-9]/', '', $data['phone']);
        if (strlen($phone_clean) < 10) {
            return __('Telefone inválido.', 'sgp-integration');
        }

        // Validação de CPF (se fornecido)
        if (!empty($data['cpf']) && !$this->validate_cpf($data['cpf'])) {
            return __('CPF inválido.', 'sgp-integration');
        }

        // Verificar se já existe lead com este email
        if ($this->lead_exists($data['email'])) {
            return __('Já existe uma solicitação com este e-mail. Entraremos em contato em breve.', 'sgp-integration');
        }

        return true;
    }

    private function validate_cpf($cpf) {
        // Remove caracteres não numéricos
        $cpf = preg_replace('/[^0-9]/', '', $cpf);
        
        // Verifica se tem 11 dígitos
        if (strlen($cpf) != 11) {
            return false;
        }
        
        // Verifica se todos os dígitos são iguais
        if (preg_match('/(\d)\1{10}/', $cpf)) {
            return false;
        }
        
        // Calcula os dígitos verificadores
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf[$c] * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf[$c] != $d) {
                return false;
            }
        }
        
        return true;
    }

    private function lead_exists($email) {
        // Verifica se existe lead local
        if (get_option('sgp_store_leads_locally')) {
            $existing_leads = get_posts([
                'post_type' => 'sgp_lead',
                'meta_query' => [
                    [
                        'key' => 'sgp_email',
                        'value' => $email,
                        'compare' => '='
                    ]
                ],
                'posts_per_page' => 1
            ]);
            
            if (!empty($existing_leads)) {
                return true;
            }
        }

        // Verifica na API (se disponível)
        $response = $this->api_client->check_lead_exists($email);
        return isset($response['exists']) && $response['exists'];
    }

    public function get_leads_stats() {
        if (!get_option('sgp_store_leads_locally')) {
            return [];
        }

        $total_leads = wp_count_posts('sgp_lead');
        $recent_leads = get_posts([
            'post_type' => 'sgp_lead',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ]);

        return [
            'total' => $total_leads->publish,
            'recent' => $recent_leads
        ];
    }

    public function export_leads($format = 'csv') {
        if (!get_option('sgp_store_leads_locally')) {
            return false;
        }

        $leads = get_posts([
            'post_type' => 'sgp_lead',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ]);

        if ($format === 'csv') {
            return $this->export_to_csv($leads);
        }

        return $leads;
    }

    private function export_to_csv($leads) {
        $filename = 'sgp-leads-' . date('Y-m-d-H-i-s') . '.csv';
        $filepath = wp_upload_dir()['basedir'] . '/' . $filename;
        
        $handle = fopen($filepath, 'w');
        
        // Cabeçalho
        fputcsv($handle, [
            'ID',
            'Nome',
            'E-mail',
            'Telefone',
            'CPF',
            'CEP',
            'Endereço',
            'Cidade',
            'Estado',
            'Plano',
            'Status',
            'Data de Criação'
        ]);
        
        foreach ($leads as $lead) {
            $meta = get_post_meta($lead->ID);
            fputcsv($handle, [
                $lead->ID,
                $lead->post_title,
                $meta['sgp_email'][0] ?? '',
                $meta['sgp_phone'][0] ?? '',
                $meta['sgp_cpf'][0] ?? '',
                $meta['sgp_cep'][0] ?? '',
                $meta['sgp_address'][0] ?? '',
                $meta['sgp_city'][0] ?? '',
                $meta['sgp_state'][0] ?? '',
                $meta['sgp_plan_id'][0] ?? '',
                $meta['sgp_status'][0] ?? 'new',
                $lead->post_date
            ]);
        }
        
        fclose($handle);
        
        return [
            'file' => $filepath,
            'url' => wp_upload_dir()['baseurl'] . '/' . $filename,
            'filename' => $filename
        ];
    }
}