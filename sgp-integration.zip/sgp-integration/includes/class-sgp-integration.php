<?php
class SGP_Integration {
    private static $instance;
    private $api_client;
    private $lead_manager;
    private $customer_panel;
    private $admin;
    private $bloqueado = false;

    public static function get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        if (!sgp_licenca_valida()) {
            $this->bloqueado = true;
            $this->load_admin_menu_only(); // Garante que o menu de configurações aparece
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p><strong>Key inválida, entre em contato com o suporte.</strong></p></div>';
            });
            // Bloqueia todas as funcionalidades do plugin, exceto admin menu/config
            add_action('init', function() {
                if (!current_user_can('manage_options')) {
                    wp_die('Key inválida, entre em contato com o suporte.');
                }
            }, 0);
            return;
        }
        $this->load_dependencies();
    }

    private function load_dependencies() {
        require_once SGP_INTEGRATION_PATH . 'includes/api/class-sgp-api-client.php';
        require_once SGP_INTEGRATION_PATH . 'includes/class-lead-manager.php';
        require_once SGP_INTEGRATION_PATH . 'includes/class-customer-panel.php';
        require_once SGP_INTEGRATION_PATH . 'includes/admin/class-sgp-admin.php';
        
        $this->api_client = new SGP_API_Client();
        $this->lead_manager = new Lead_Manager($this->api_client);
        $this->customer_panel = new Customer_Panel($this->api_client);
        $this->admin = new SGP_Admin($this->api_client, $this->lead_manager);
    }

    // Carrega apenas o menu de configurações para admins
    private function load_admin_menu_only() {
        require_once SGP_INTEGRATION_PATH . 'includes/admin/class-sgp-admin.php';
        $this->admin = new SGP_Admin(null, null); // Passa null para dependências não usadas
        add_action('admin_menu', [$this->admin, 'add_admin_menu']);
        add_action('admin_init', [$this->admin, 'register_settings']);
    }

    public function initialize() {
        if ($this->bloqueado) return;
        $this->api_client->init();
        $this->lead_manager->init();
        $this->customer_panel->init();
        $this->admin->init();
    }

    public function get_api_client() {
        return $this->api_client;
    }

    public function get_customer_panel() {
        return $this->customer_panel;
    }

    public function get_lead_manager() {
        return $this->lead_manager;
    }

    public function get_admin() {
        return $this->admin;
    }

    public static function activate() {
        // Cria a role do cliente SGP
        sgp_add_customer_role();
        
        // Adiciona opções padrão
        add_option('sgp_api_url', '');
        add_option('sgp_api_email', '');
        add_option('sgp_api_password', '');
        add_option('sgp_store_leads_locally', '1');
        add_option('sgp_enable_logging', '1');
        add_option('sgp_cache_time', '3600');
        add_option('sgp_notification_email', get_option('admin_email'));
        
        // Novas opções de segurança
        add_option('sgp_force_https', '0');
        add_option('sgp_security_headers', '1');
        add_option('sgp_ip_whitelist', '');
        add_option('sgp_enable_2fa', '0');
        add_option('sgp_session_timeout', '3600');
        
        // Configuração de distância de cobertura
        add_option('sgp_coverage_distance', '200'); // 200 metros por padrão

        // Criação das tabelas personalizadas
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $charset_collate = $wpdb->get_charset_collate();
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        $table_leads = $wpdb->prefix . 'sgp_leads';

        $sql_consultas = "CREATE TABLE $table_consultas (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            cep varchar(20) NOT NULL,
            endereco varchar(255) NOT NULL,
            numero varchar(50) NOT NULL,
            bairro varchar(100) NOT NULL,
            cidade varchar(100) NOT NULL,
            estado varchar(50) NOT NULL,
            resultado varchar(255) DEFAULT NULL,
            disponivel tinyint(1) DEFAULT 0,
            data_consulta datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            detalhes longtext DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql_leads = "CREATE TABLE $table_leads (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            nome varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            telefone varchar(50) NOT NULL,
            cep varchar(20) NOT NULL,
            endereco varchar(255) NOT NULL,
            numero varchar(50) NOT NULL,
            bairro varchar(100) NOT NULL,
            cidade varchar(100) NOT NULL,
            estado varchar(50) NOT NULL,
            viabilidade_aprovada tinyint(1) NOT NULL DEFAULT 0,
            data_lead datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql_consultas);
        dbDelta($sql_leads);
        
        // Registra o tipo de post para leads
        if (get_option('sgp_store_leads_locally')) {
            register_post_type('sgp_lead', [
                'labels' => [
                    'name' => __('Leads SGP', 'sgp-integration'),
                    'singular_name' => __('Lead SGP', 'sgp-integration')
                ],
                'public' => false,
                'show_ui' => true,
                'show_in_menu' => 'sgp-integration',
                'capability_type' => 'post',
                'capabilities' => [
                    'create_posts' => false,
                ],
                'map_meta_cap' => true,
                'supports' => ['title', 'custom-fields']
            ]);
        }
        
        // Limpa cache
        wp_cache_flush();
        

        
        // Redireciona para configurações na primeira ativação
        add_option('sgp_first_activation', '1');
    }

    public static function deactivate() {
        // Limpa agendamentos
        wp_clear_scheduled_hook('sgp_integration_daily_cleanup');
        wp_clear_scheduled_hook('sgp_integration_hourly_api_sync');
        
        // Limpa cache da API
        delete_transient('sgp_api_token');
        

        
        // Limpa cache
        wp_cache_flush();
    }

    // Função para inserir consulta de viabilidade
    public static function inserir_consulta($dados, $detalhes = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'sgp_consultas';
        
        $insert_data = [
            'cep' => sanitize_text_field($dados['cep'] ?? ''),
            'endereco' => sanitize_text_field($dados['endereco'] ?? ''),
            'numero' => sanitize_text_field($dados['numero'] ?? ''),
            'bairro' => sanitize_text_field($dados['bairro'] ?? ''),
            'cidade' => sanitize_text_field($dados['cidade'] ?? ''),
            'estado' => sanitize_text_field($dados['estado'] ?? ''),
            'resultado' => sanitize_text_field($dados['resultado'] ?? ''),
            'disponivel' => isset($dados['disponivel']) ? (int)$dados['disponivel'] : 0,
            'data_consulta' => current_time('mysql'),
            'detalhes' => $detalhes ? wp_json_encode($detalhes) : null,
        ];
        
        $result = $wpdb->insert($table, $insert_data);
        
        if ($result) {
            return $wpdb->insert_id;
        } else {
            return false;
        }
    }

    // Função para inserir lead
    public static function inserir_lead($dados) {
        global $wpdb;
        $table = $wpdb->prefix . 'sgp_leads';
        
        // Verifica se a tabela existe
        $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) == $table;
        if (!$table_exists) {
            return false;
        }
        
        // Prepara os dados para inserção - VERSÃO COMPLETA (dados pessoais + endereço + viabilidade)
        $insert_data = [
            'nome' => sanitize_text_field($dados['nome'] ?? ''),
            'email' => sanitize_email($dados['email'] ?? ''),
            'telefone' => sanitize_text_field($dados['telefone'] ?? ''),
            'cep' => sanitize_text_field($dados['cep'] ?? ''),
            'endereco' => sanitize_text_field($dados['endereco'] ?? ''),
            'numero' => sanitize_text_field($dados['numero'] ?? ''),
            'bairro' => sanitize_text_field($dados['bairro'] ?? ''),
            'cidade' => sanitize_text_field($dados['cidade'] ?? ''),
            'estado' => sanitize_text_field($dados['estado'] ?? ''),
            'viabilidade_aprovada' => (int)($dados['viabilidade_aprovada'] ?? 0),
            'data_lead' => current_time('mysql'),
        ];
        
        // Query completa com todos os campos incluindo viabilidade
        $query = $wpdb->prepare(
            "INSERT INTO $table (nome, email, telefone, cep, endereco, numero, bairro, cidade, estado, viabilidade_aprovada, data_lead) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %s)",
            $insert_data['nome'],
            $insert_data['email'],
            $insert_data['telefone'],
            $insert_data['cep'],
            $insert_data['endereco'],
            $insert_data['numero'],
            $insert_data['bairro'],
            $insert_data['cidade'],
            $insert_data['estado'],
            $insert_data['viabilidade_aprovada'],
            $insert_data['data_lead']
        );
        
        // Executa a query
        $result = $wpdb->query($query);
        
        // Verifica se houve erro
        if ($result === false) {
            return false;
        }
        
        // Verifica se o insert_id foi gerado
        if ($wpdb->insert_id <= 0) {
            return false;
        }
        
        return $wpdb->insert_id;
    }
}

// Função global para checar se a licença é válida
if (!function_exists('sgp_licenca_valida')) {
    function sgp_licenca_valida() {
        $key = get_option('sgp_license_key', '');
        $status = get_option('sgp_license_status', 'invalid');
        $last_check = get_option('sgp_license_last_check', 0);
        // Se não há key, nunca é válido
        if (empty($key)) return false;
        // Se nunca checou ou faz mais de 7 dias, tenta validar agora
        if ($last_check == 0 || (time() - $last_check) > 7*24*60*60) {
            $result = sgp_validar_licenca_remota($key);
            update_option('sgp_license_status', $result['status']);
            update_option('sgp_license_last_check', time());
            $status = $result['status'];
        }
        return $status === 'valid';
    }
}