<?php
class SGP_Integration {
    private static $instance;
    private $api_client;
    private $lead_manager;
    private $customer_panel;
    private $admin;
    private $bloqueado = false;

    public static function get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        if (!sgp_licenca_valida()) {
            $this->bloqueado = true;
            $this->load_admin_menu_only(); // Garante que o menu de configurações aparece
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p><strong>Key inválida, entre em contato com o suporte.</strong></p></div>';
            });
            // Bloqueia todas as funcionalidades do plugin, exceto admin menu/config
            add_action('init', function() {
                if (!current_user_can('manage_options')) {
                    wp_die('Key inválida, entre em contato com o suporte.');
                }
            }, 0);
            return;
        }
        $this->load_dependencies();
    }

    private function load_dependencies() {
        require_once SGP_INTEGRATION_PATH . 'includes/api/class-sgp-api-client.php';
        require_once SGP_INTEGRATION_PATH . 'includes/class-lead-manager.php';
        require_once SGP_INTEGRATION_PATH . 'includes/class-customer-panel.php';
        require_once SGP_INTEGRATION_PATH . 'includes/admin/class-sgp-admin.php';
        
        $this->api_client = new SGP_API_Client();
        $this->lead_manager = new Lead_Manager($this->api_client);
        $this->customer_panel = new Customer_Panel($this->api_client);
        $this->admin = new SGP_Admin($this->api_client, $this->lead_manager);
    }

    // Carrega apenas o menu de configurações para admins
    private function load_admin_menu_only() {
        require_once SGP_INTEGRATION_PATH . 'includes/admin/class-sgp-admin.php';
        $this->admin = new SGP_Admin(null, null); // Passa null para dependências não usadas
        add_action('admin_menu', [$this->admin, 'add_admin_menu']);
        add_action('admin_init', [$this->admin, 'register_settings']);
    }

    public function initialize() {
        if ($this->bloqueado) return;
        $this->api_client->init();
        $this->lead_manager->init();
        $this->customer_panel->init();
        $this->admin->init();
    }

    public function get_api_client() {
        return $this->api_client;
    }

    public function get_customer_panel() {
        return $this->customer_panel;
    }

    public function get_lead_manager() {
        return $this->lead_manager;
    }

    public function get_admin() {
        return $this->admin;
    }

    public static function activate() {
        // Cria a role do cliente SGP
        sgp_add_customer_role();
        
        // Adiciona opções padrão
        add_option('sgp_api_url', '');
        add_option('sgp_api_email', '');
        add_option('sgp_api_password', '');
        add_option('sgp_store_leads_locally', '1');
        add_option('sgp_enable_logging', '1');
        add_option('sgp_cache_time', '3600');
        add_option('sgp_notification_email', get_option('admin_email'));
        
        // Novas opções de segurança
        add_option('sgp_force_https', '0');
        add_option('sgp_security_headers', '1');
        add_option('sgp_ip_whitelist', '');
        add_option('sgp_enable_2fa', '0');
        add_option('sgp_session_timeout', '3600');
        
        // Registra o tipo de post para leads
        if (get_option('sgp_store_leads_locally')) {
            register_post_type('sgp_lead', [
                'labels' => [
                    'name' => __('Leads SGP', 'sgp-integration'),
                    'singular_name' => __('Lead SGP', 'sgp-integration')
                ],
                'public' => false,
                'show_ui' => true,
                'show_in_menu' => 'sgp-integration',
                'capability_type' => 'post',
                'capabilities' => [
                    'create_posts' => false,
                ],
                'map_meta_cap' => true,
                'supports' => ['title', 'custom-fields']
            ]);
        }
        
        // Limpa cache
        wp_cache_flush();
        
        // Log de ativação
        sgp_integration_log('Plugin SGP Integration ativado', [
            'version' => SGP_INTEGRATION_VERSION,
            'timestamp' => current_time('mysql')
        ], 'info');
        
        // Redireciona para configurações na primeira ativação
        add_option('sgp_first_activation', '1');
    }

    public static function deactivate() {
        // Limpa agendamentos
        wp_clear_scheduled_hook('sgp_integration_daily_cleanup');
        wp_clear_scheduled_hook('sgp_integration_hourly_api_sync');
        
        // Limpa cache da API
        delete_transient('sgp_api_token');
        
        // Log de desativação
        sgp_integration_log('Plugin SGP Integration desativado', [
            'timestamp' => current_time('mysql')
        ], 'info');
        
        // Limpa cache
        wp_cache_flush();
    }
}

// Função global para checar se a licença é válida
if (!function_exists('sgp_licenca_valida')) {
    function sgp_licenca_valida() {
        $key = get_option('sgp_license_key', '');
        $status = get_option('sgp_license_status', 'invalid');
        $last_check = get_option('sgp_license_last_check', 0);
        // Se não há key, nunca é válido
        if (empty($key)) return false;
        // Se nunca checou ou faz mais de 7 dias, tenta validar agora
        if ($last_check == 0 || (time() - $last_check) > 7*24*60*60) {
            $result = sgp_validar_licenca_remota($key);
            update_option('sgp_license_status', $result['status']);
            update_option('sgp_license_last_check', time());
            $status = $result['status'];
        }
        return $status === 'valid';
    }
}