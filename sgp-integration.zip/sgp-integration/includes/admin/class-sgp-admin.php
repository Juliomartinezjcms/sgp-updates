<?php
class SGP_Admin {
    private $api_client;
    private $lead_manager;

    public function __construct($api_client, $lead_manager) {
        $this->api_client = $api_client;
        $this->lead_manager = $lead_manager;
    }

    public function init() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_sgp_test_api_connection', [$this, 'ajax_test_api_connection']);
        add_action('wp_ajax_sgp_export_leads', [$this, 'ajax_export_leads']);
        add_action('wp_ajax_sgp_clear_cache', [$this, 'ajax_clear_cache']);
        add_action('wp_ajax_sgp_check_updates', [$this, 'ajax_check_updates']);
        add_action('wp_ajax_sgp_update_plugin', [$this, 'ajax_update_plugin']);
        add_action('wp_ajax_sgp_filter_reports', [$this, 'ajax_filter_reports']);
        add_action('wp_ajax_sgp_get_charts_data', [$this, 'ajax_get_charts_data']);
        add_action('wp_ajax_sgp_export_leads_csv', [$this, 'ajax_export_leads_csv']);
        add_action('wp_ajax_sgp_export_consultas_csv', [$this, 'ajax_export_consultas_csv']);
    }

    public function add_admin_menu() {
        add_menu_page(
            'SGP Integration',
            'SGP Integration',
            'manage_options',
            'sgp-integration',
            [$this, 'admin_page'],
            'dashicons-admin-site-alt3',
            3
        );
        
        add_submenu_page(
            'sgp-integration',
            'Configurações',
            'Configurações',
            'manage_options',
            'sgp-integration',
            [$this, 'admin_page']
        );
        
        add_submenu_page(
            'sgp-integration',
            'Relatórios',
            'Relatórios',
            'manage_options',
            'sgp-reports',
            [$this, 'reports_page']
        );
    }

    public function register_settings() {
        register_setting('sgp_integration_options', 'sgp_api_url');
        register_setting('sgp_integration_options', 'sgp_api_token');
        register_setting('sgp_integration_options', 'sgp_api_user');
        register_setting('sgp_integration_options', 'sgp_api_pass');
        register_setting('sgp_integration_options', 'sgp_google_maps_key');
        register_setting('sgp_integration_options', 'sgp_store_leads_locally');
        register_setting('sgp_integration_options', 'sgp_enable_logging');
        register_setting('sgp_integration_options', 'sgp_cache_time');
        register_setting('sgp_integration_options', 'sgp_notification_email');
        register_setting('sgp_integration_options', 'sgp_coverage_distance');
        register_setting('sgp_integration_options', 'sgp_login_logo');
        register_setting('sgp_integration_options', 'sgp_api_app');
        
        // Novas opções de segurança
        register_setting('sgp_integration_options', 'sgp_force_https');
        register_setting('sgp_integration_options', 'sgp_security_headers');
        register_setting('sgp_integration_options', 'sgp_ip_whitelist');
        register_setting('sgp_integration_options', 'sgp_enable_2fa');
        register_setting('sgp_integration_options', 'sgp_session_timeout');
        register_setting('sgp_integration_options', 'sgp_enable_session_check');
    }

    public function enqueue_admin_scripts($hook) {
        // Carregar scripts em todas as páginas do plugin SGP
        if (strpos($hook, 'sgp-integration') === false && 
            strpos($hook, 'sgp-reports') === false) {
            return;
        }

        // Enqueue WordPress media scripts
        wp_enqueue_media();

        wp_enqueue_style(
            'sgp-admin',
            SGP_INTEGRATION_URL . 'assets/css/admin.css',
            [],
            SGP_INTEGRATION_VERSION
        );

        wp_enqueue_script(
            'sgp-admin',
            SGP_INTEGRATION_URL . 'assets/js/admin.js',
            ['jquery', 'media-upload', 'thickbox'],
            SGP_INTEGRATION_VERSION,
            true
        );

        wp_localize_script('sgp-admin', 'sgpAdminVars', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sgp-admin-nonce'),
            'i18n' => [
                'testingConnection' => __('Testando conexão...', 'sgp-integration'),
                'connectionSuccess' => __('Conexão bem-sucedida!', 'sgp-integration'),
                'connectionError' => __('Erro na conexão.', 'sgp-integration'),
                'exportingLeads' => __('Exportando leads...', 'sgp-integration'),
                'clearingCache' => __('Limpando cache...', 'sgp-integration'),
                'fillAllFields' => __('Preencha todos os campos da API.', 'sgp-integration')
            ]
        ]);
    }

    public function admin_page() {
        if (isset($_POST['submit'])) {
            $this->save_settings();
        }

        $api_url = get_option('sgp_api_url');
        $api_token = get_option('sgp_api_token');
        $api_user = get_option('sgp_api_user');
        $api_pass = get_option('sgp_api_pass');
        $google_maps_key = get_option('sgp_google_maps_key');
        $store_leads = get_option('sgp_store_leads_locally', '1');
        $enable_logging = get_option('sgp_enable_logging', '1');
        $cache_time = get_option('sgp_cache_time', '3600');
        $notification_email = get_option('sgp_notification_email');
        $coverage_distance = get_option('sgp_coverage_distance', '200');
        $login_logo = get_option('sgp_login_logo', '');
        $api_app = get_option('sgp_api_app');
        
        // Novas configurações de segurança
        $force_https = get_option('sgp_force_https', '0');
        $security_headers = get_option('sgp_security_headers', '1');
        $ip_whitelist = get_option('sgp_ip_whitelist', '');
        $enable_2fa = get_option('sgp_enable_2fa', '0');
        $session_timeout = get_option('sgp_session_timeout', '3600');
        $enable_session_check = get_option('sgp_enable_session_check', '1');

        include SGP_INTEGRATION_PATH . 'templates/admin/settings.php';
    }



    public function reports_page() {
        $stats = $this->get_reports_stats();
        $charts_data = $this->get_charts_data();
        $filtered_data = $this->get_filtered_data();
        include SGP_INTEGRATION_PATH . 'templates/admin/reports.php';
    }



    private function save_settings() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'sgp_integration_options')) {
            wp_die(__('Erro de segurança.', 'sgp-integration'));
        }

        update_option('sgp_api_url', sanitize_url($_POST['sgp_api_url']));
        update_option('sgp_api_token', sanitize_text_field($_POST['sgp_api_token']));
        update_option('sgp_api_user', sanitize_text_field($_POST['sgp_api_user']));
        update_option('sgp_api_pass', sanitize_text_field($_POST['sgp_api_pass']));
        update_option('sgp_google_maps_key', sanitize_text_field($_POST['sgp_google_maps_key']));
        update_option('sgp_store_leads_locally', isset($_POST['sgp_store_leads_locally']) ? '1' : '0');
        update_option('sgp_enable_logging', isset($_POST['sgp_enable_logging']) ? '1' : '0');
        update_option('sgp_cache_time', absint($_POST['sgp_cache_time']));
        update_option('sgp_notification_email', sanitize_email($_POST['sgp_notification_email']));
        update_option('sgp_coverage_distance', absint($_POST['sgp_coverage_distance']));
        update_option('sgp_login_logo', absint($_POST['sgp_login_logo']));
        update_option('sgp_api_app', sanitize_text_field($_POST['sgp_api_app']));
        
        // Novas configurações de segurança
        update_option('sgp_force_https', isset($_POST['sgp_force_https']) ? '1' : '0');
        update_option('sgp_security_headers', isset($_POST['sgp_security_headers']) ? '1' : '0');
        update_option('sgp_ip_whitelist', sanitize_textarea_field($_POST['sgp_ip_whitelist']));
        update_option('sgp_enable_2fa', isset($_POST['sgp_enable_2fa']) ? '1' : '0');
        update_option('sgp_session_timeout', absint($_POST['sgp_session_timeout']));
        update_option('sgp_enable_session_check', isset($_POST['sgp_enable_session_check']) ? '1' : '0');

        // Salvamento da licença
        if (isset($_POST['sgp_license_key'])) {
            $license_key = sanitize_text_field($_POST['sgp_license_key']);
            update_option('sgp_license_key', $license_key);
            // Valida imediatamente ao salvar
            $result = sgp_validar_licenca_remota($license_key);
            update_option('sgp_license_status', $result['status']);
            update_option('sgp_license_last_check', time());
        }

        // Limpa cache da API
        $this->clear_api_cache();

        add_settings_error(
            'sgp_integration',
            'settings_updated',
            __('Configurações salvas com sucesso!', 'sgp-integration'),
            'success'
        );
    }

    public function ajax_test_api_connection() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration')]);
        }
        $api_url = isset($_POST['api_url']) ? sanitize_url($_POST['api_url']) : '';
        $api_token = isset($_POST['api_token']) ? sanitize_text_field($_POST['api_token']) : '';
        if (empty($api_url) || empty($api_token)) {
            wp_send_json_error(['message' => __('Preencha todos os campos da API.', 'sgp-integration')]);
        }
        $test_client = new SGP_API_Client();
        $test_client->set_api_url($api_url);
        $test_client->set_api_token($api_token);
        $response = $test_client->get_fatura_segunda_via('1');
        if (isset($response['error'])) {
            wp_send_json_error(['message' => __('Falha na conexão. Verifique o token e a URL.', 'sgp-integration')]);
        } else {
            wp_send_json_success(['message' => __('Conexão bem-sucedida!', 'sgp-integration')]);
        }
    }

    public function ajax_export_leads() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration')]);
        }

        $format = sanitize_text_field($_POST['format'] ?? 'csv');
        $export_result = $this->lead_manager->export_leads($format);

        if ($export_result) {
            wp_send_json_success([
                'message' => __('Exportação concluída!', 'sgp-integration'),
                'download_url' => $export_result['url'],
                'filename' => $export_result['filename']
            ]);
        } else {
            wp_send_json_error(['message' => __('Erro na exportação.', 'sgp-integration')]);
        }
    }

    public function ajax_clear_cache() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration')]);
        }

        $this->clear_api_cache();
        
        wp_send_json_success(['message' => __('Cache limpo com sucesso!', 'sgp-integration')]);
    }

    private function clear_api_cache() {
        global $wpdb;
        
        // Remove transients relacionados ao SGP
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sgp_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_sgp_%'");
        
        // Limpa cache de autenticação
        delete_transient('sgp_api_token');
    }

    private function get_reports_stats() {
        global $wpdb;
        
        $stats = [
            'total_leads' => 0,
            'leads_today' => 0,
            'leads_this_month' => 0,
            'total_consultas' => 0,
            'consultas_today' => 0,
            'consultas_aprovadas' => 0,
            'consultas_negadas' => 0,
            'taxa_conversao' => 0,
            'api_errors' => 0
        ];

        // Estatísticas das tabelas personalizadas
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        // Verifica se as tabelas existem
        $leads_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads;
        $consultas_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas;
        
        if ($leads_exists) {
            // Total de leads
            $stats['total_leads'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads");
            
            // Leads de hoje
            $stats['leads_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads WHERE DATE(data_lead) = CURDATE()");
            
            // Leads deste mês
            $stats['leads_this_month'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads WHERE YEAR(data_lead) = YEAR(CURDATE()) AND MONTH(data_lead) = MONTH(CURDATE())");
        }
        
        if ($consultas_exists) {
            // Total de consultas
            $stats['total_consultas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas");
            
            // Consultas de hoje
            $stats['consultas_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE DATE(data_consulta) = CURDATE()");
            
            // Consultas aprovadas e negadas
            $stats['consultas_aprovadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE disponivel = 1");
            $stats['consultas_negadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE disponivel = 0");
            
            // Taxa de conversão (leads / consultas aprovadas)
            if ($stats['consultas_aprovadas'] > 0) {
                $stats['taxa_conversao'] = round(($stats['total_leads'] / $stats['consultas_aprovadas']) * 100, 2);
            }
        }

        return $stats;
    }
    
    public function get_charts_data() {
        global $wpdb;
        
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        $data = [
            'leads_por_mes' => [],
            'consultas_por_mes' => [],
            'leads_por_cidade' => [],
            'consultas_por_resultado' => [],
            'leads_ultimos_30_dias' => []
        ];
        
        // Leads por mês (últimos 12 meses)
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads) {
            $leads_por_mes = $wpdb->get_results("
                SELECT 
                    DATE_FORMAT(data_lead, '%Y-%m') as mes,
                    COUNT(*) as total
                FROM $table_leads 
                WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(data_lead, '%Y-%m')
                ORDER BY mes
            ");
            $data['leads_por_mes'] = $leads_por_mes;
            
            // Leads por cidade (top 3)
            $leads_por_cidade = $wpdb->get_results("
                SELECT cidade, COUNT(*) as total
                FROM $table_leads 
                GROUP BY cidade
                ORDER BY total DESC
                LIMIT 3
            ");
            $data['leads_por_cidade'] = $leads_por_cidade;
            
            // Leads por bairro (top 3)
            $leads_por_bairro = $wpdb->get_results("
                SELECT bairro, COUNT(*) as total
                FROM $table_leads 
                WHERE bairro != ''
                GROUP BY bairro
                ORDER BY total DESC
                LIMIT 3
            ");
            $data['leads_por_bairro'] = $leads_por_bairro;
            
            // Leads dos últimos 30 dias
            $leads_30_dias = $wpdb->get_results("
                SELECT 
                    DATE(data_lead) as data,
                    COUNT(*) as total
                FROM $table_leads 
                WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                GROUP BY DATE(data_lead)
                ORDER BY data
            ");
            $data['leads_ultimos_30_dias'] = $leads_30_dias;
        }
        
        // Consultas por mês (últimos 12 meses)
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas) {
            $consultas_por_mes = $wpdb->get_results("
                SELECT 
                    DATE_FORMAT(data_consulta, '%Y-%m') as mes,
                    COUNT(*) as total
                FROM $table_consultas 
                WHERE data_consulta >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(data_consulta, '%Y-%m')
                ORDER BY mes
            ");
            $data['consultas_por_mes'] = $consultas_por_mes;
            
            // Consultas por resultado
            $consultas_por_resultado = $wpdb->get_results("
                SELECT 
                    CASE WHEN disponivel = 1 THEN 'Aprovadas' ELSE 'Negadas' END as resultado,
                    COUNT(*) as total
                FROM $table_consultas 
                GROUP BY disponivel
            ");
            $data['consultas_por_resultado'] = $consultas_por_resultado;
            
            // Consultas por cidade (top 3)
            $consultas_por_cidade = $wpdb->get_results("
                SELECT cidade, COUNT(*) as total
                FROM $table_consultas 
                GROUP BY cidade
                ORDER BY total DESC
                LIMIT 3
            ");
            $data['consultas_por_cidade'] = $consultas_por_cidade;
            
            // Consultas por bairro (top 3)
            $consultas_por_bairro = $wpdb->get_results("
                SELECT bairro, COUNT(*) as total
                FROM $table_consultas 
                WHERE bairro != ''
                GROUP BY bairro
                ORDER BY total DESC
                LIMIT 3
            ");
            $data['consultas_por_bairro'] = $consultas_por_bairro;
        }
        
        return $data;
    }
    
    public function get_filtered_data($start_date = null, $end_date = null) {
        global $wpdb;
        
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        $where_leads = '';
        $where_consultas = '';
        
        if ($start_date && $end_date) {
            $where_leads = $wpdb->prepare(" WHERE DATE(data_lead) BETWEEN %s AND %s", $start_date, $end_date);
            $where_consultas = $wpdb->prepare(" WHERE DATE(data_consulta) BETWEEN %s AND %s", $start_date, $end_date);
        }
        
        $data = [
            'leads' => [],
            'consultas' => []
        ];
        
        // Buscar leads filtrados
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads) {
            $data['leads'] = $wpdb->get_results("
                SELECT * FROM $table_leads 
                $where_leads
                ORDER BY data_lead DESC
                LIMIT 100
            ");
        }
        
        // Buscar consultas filtradas
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas) {
            $data['consultas'] = $wpdb->get_results("
                SELECT * FROM $table_consultas 
                $where_consultas
                ORDER BY data_consulta DESC
                LIMIT 100
            ");
        }
        
        return $data;
    }
    
    public function get_filtered_stats($start_date = null, $end_date = null) {
        global $wpdb;
        
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        $where_leads = '';
        $where_consultas = '';
        
        if ($start_date && $end_date) {
            $where_leads = $wpdb->prepare(" WHERE DATE(data_lead) BETWEEN %s AND %s", $start_date, $end_date);
            $where_consultas = $wpdb->prepare(" WHERE DATE(data_consulta) BETWEEN %s AND %s", $start_date, $end_date);
        }
        
        $stats = [
            'total_leads' => 0,
            'leads_today' => 0,
            'leads_this_month' => 0,
            'total_consultas' => 0,
            'consultas_today' => 0,
            'consultas_aprovadas' => 0,
            'consultas_negadas' => 0,
            'taxa_conversao' => 0,
            'api_errors' => 0
        ];
        
        // Verifica se as tabelas existem
        $leads_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads;
        $consultas_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas;
        
        if ($leads_exists) {
            // Total de leads no período
            $stats['total_leads'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads $where_leads");
            
            // Leads de hoje (apenas se o período incluir hoje)
            if (!$start_date || !$end_date || (date('Y-m-d') >= $start_date && date('Y-m-d') <= $end_date)) {
                $stats['leads_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads WHERE DATE(data_lead) = CURDATE()");
            }
            
            // Leads deste mês (apenas se o período incluir este mês)
            $current_month_start = date('Y-m-01');
            if (!$start_date || !$end_date || ($current_month_start >= $start_date && $current_month_start <= $end_date)) {
                $stats['leads_this_month'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_leads WHERE YEAR(data_lead) = YEAR(CURDATE()) AND MONTH(data_lead) = MONTH(CURDATE())");
            }
        }
        
        if ($consultas_exists) {
            // Total de consultas no período
            $stats['total_consultas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas $where_consultas");
            
            // Consultas de hoje (apenas se o período incluir hoje)
            if (!$start_date || !$end_date || (date('Y-m-d') >= $start_date && date('Y-m-d') <= $end_date)) {
                $stats['consultas_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE DATE(data_consulta) = CURDATE()");
            }
            
            // Consultas aprovadas e negadas no período
            if ($where_consultas) {
                $stats['consultas_aprovadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas $where_consultas AND disponivel = 1");
                $stats['consultas_negadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas $where_consultas AND disponivel = 0");
            } else {
                $stats['consultas_aprovadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE disponivel = 1");
                $stats['consultas_negadas'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_consultas WHERE disponivel = 0");
            }
            
            // Taxa de conversão (leads / consultas aprovadas)
            if ($stats['consultas_aprovadas'] > 0) {
                $stats['taxa_conversao'] = round(($stats['total_leads'] / $stats['consultas_aprovadas']) * 100, 2);
            }
        }

        return $stats;
    }
    
    public function get_filtered_charts_data($start_date = null, $end_date = null) {
        global $wpdb;
        
        $table_leads = $wpdb->prefix . 'sgp_leads';
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        $where_leads = '';
        $where_consultas = '';
        
        if ($start_date && $end_date) {
            $where_leads = $wpdb->prepare(" WHERE DATE(data_lead) BETWEEN %s AND %s", $start_date, $end_date);
            $where_consultas = $wpdb->prepare(" WHERE DATE(data_consulta) BETWEEN %s AND %s", $start_date, $end_date);
        }
        
        $data = [
            // Gráficos de localização (slides)
            'leads_por_cidade' => [],
            'leads_por_bairro' => [],
            'consultas_por_cidade' => [],
            'consultas_por_bairro' => [],
            
            // Gráfico de resultado das consultas (pizza)
            'consultas_por_resultado' => [],
            
            // Gráfico mensal (linha)
            'leads_por_mes' => [],
            'consultas_por_mes' => [],
            
            // Gráfico últimos 30 dias
            'leads_ultimos_30_dias' => []
        ];
        
        // ==================== LEADS POR CIDADE E BAIRRO ====================
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_leads)) == $table_leads) {
            if ($where_leads) {
                $leads_por_cidade = $wpdb->get_results("
                    SELECT cidade, COUNT(*) as total
                    FROM $table_leads 
                    $where_leads
                    GROUP BY cidade
                    ORDER BY total DESC
                    LIMIT 3
                ");
                
                $leads_por_bairro = $wpdb->get_results("
                    SELECT bairro, COUNT(*) as total
                    FROM $table_leads 
                    $where_leads AND bairro != ''
                    GROUP BY bairro
                    ORDER BY total DESC
                    LIMIT 3
                ");
            } else {
                $leads_por_cidade = $wpdb->get_results("
                    SELECT cidade, COUNT(*) as total
                    FROM $table_leads 
                    GROUP BY cidade
                    ORDER BY total DESC
                    LIMIT 3
                ");
                
                $leads_por_bairro = $wpdb->get_results("
                    SELECT bairro, COUNT(*) as total
                    FROM $table_leads 
                    WHERE bairro != ''
                    GROUP BY bairro
                    ORDER BY total DESC
                    LIMIT 3
                ");
            }
            
            $data['leads_por_cidade'] = $leads_por_cidade;
            $data['leads_por_bairro'] = $leads_por_bairro;
            
            // ==================== LEADS POR MÊS ====================
            if ($where_leads) {
                $leads_por_mes = $wpdb->get_results("
                    SELECT 
                        DATE_FORMAT(data_lead, '%Y-%m') as mes,
                        COUNT(*) as total
                    FROM $table_leads 
                    WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) 
                    AND " . substr($where_leads, 7) . "
                    GROUP BY DATE_FORMAT(data_lead, '%Y-%m')
                    ORDER BY mes
                ");
            } else {
                $leads_por_mes = $wpdb->get_results("
                    SELECT 
                        DATE_FORMAT(data_lead, '%Y-%m') as mes,
                        COUNT(*) as total
                    FROM $table_leads 
                    WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                    GROUP BY DATE_FORMAT(data_lead, '%Y-%m')
                    ORDER BY mes
                ");
            }
            $data['leads_por_mes'] = $leads_por_mes;
            
            // ==================== LEADS ÚLTIMOS 30 DIAS ====================
            if ($where_leads) {
                $leads_30_dias = $wpdb->get_results("
                    SELECT 
                        DATE(data_lead) as data,
                        COUNT(*) as total
                    FROM $table_leads 
                    WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    AND " . substr($where_leads, 7) . "
                    GROUP BY DATE(data_lead)
                    ORDER BY data
                ");
            } else {
                $leads_30_dias = $wpdb->get_results("
                    SELECT 
                        DATE(data_lead) as data,
                        COUNT(*) as total
                    FROM $table_leads 
                    WHERE data_lead >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                    GROUP BY DATE(data_lead)
                    ORDER BY data
                ");
            }
            $data['leads_ultimos_30_dias'] = $leads_30_dias;
        }
        
        // ==================== CONSULTAS POR CIDADE E BAIRRO ====================
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_consultas)) == $table_consultas) {
            if ($where_consultas) {
                $consultas_por_cidade = $wpdb->get_results("
                    SELECT cidade, COUNT(*) as total
                    FROM $table_consultas 
                    $where_consultas
                    GROUP BY cidade
                    ORDER BY total DESC
                    LIMIT 3
                ");
                
                $consultas_por_bairro = $wpdb->get_results("
                    SELECT bairro, COUNT(*) as total
                    FROM $table_consultas 
                    $where_consultas AND bairro != ''
                    GROUP BY bairro
                    ORDER BY total DESC
                    LIMIT 3
                ");
            } else {
                $consultas_por_cidade = $wpdb->get_results("
                    SELECT cidade, COUNT(*) as total
                    FROM $table_consultas 
                    GROUP BY cidade
                    ORDER BY total DESC
                    LIMIT 3
                ");
                
                $consultas_por_bairro = $wpdb->get_results("
                    SELECT bairro, COUNT(*) as total
                    FROM $table_consultas 
                    WHERE bairro != ''
                    GROUP BY bairro
                    ORDER BY total DESC
                    LIMIT 3
                ");
            }
            
            $data['consultas_por_cidade'] = $consultas_por_cidade;
            $data['consultas_por_bairro'] = $consultas_por_bairro;
            
            // ==================== CONSULTAS POR RESULTADO (PIZZA) ====================
            if ($where_consultas) {
                $consultas_por_resultado = $wpdb->get_results("
                    SELECT 
                        CASE WHEN disponivel = 1 THEN 'Aprovadas' ELSE 'Negadas' END as resultado,
                        COUNT(*) as total
                    FROM $table_consultas 
                    $where_consultas
                    GROUP BY disponivel
                ");
            } else {
                $consultas_por_resultado = $wpdb->get_results("
                    SELECT 
                        CASE WHEN disponivel = 1 THEN 'Aprovadas' ELSE 'Negadas' END as resultado,
                        COUNT(*) as total
                    FROM $table_consultas 
                    GROUP BY disponivel
                ");
            }
            $data['consultas_por_resultado'] = $consultas_por_resultado;
            
            // ==================== CONSULTAS POR MÊS ====================
            if ($where_consultas) {
                $consultas_por_mes = $wpdb->get_results("
                    SELECT 
                        DATE_FORMAT(data_consulta, '%Y-%m') as mes,
                        COUNT(*) as total
                    FROM $table_consultas 
                    WHERE data_consulta >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                    AND " . substr($where_consultas, 7) . "
                    GROUP BY DATE_FORMAT(data_consulta, '%Y-%m')
                    ORDER BY mes
                ");
            } else {
                $consultas_por_mes = $wpdb->get_results("
                    SELECT 
                        DATE_FORMAT(data_consulta, '%Y-%m') as mes,
                        COUNT(*) as total
                    FROM $table_consultas 
                    WHERE data_consulta >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                    GROUP BY DATE_FORMAT(data_consulta, '%Y-%m')
                    ORDER BY mes
                ");
            }
            $data['consultas_por_mes'] = $consultas_por_mes;
        }
        
        return $data;
    }

    public function send_notification_email($lead_data) {
        $notification_email = get_option('sgp_notification_email');
        
        if (empty($notification_email)) {
            return false;
        }

        $subject = sprintf(__('Novo lead recebido - %s', 'sgp-integration'), get_bloginfo('name'));
        
        $message = sprintf(
            __("Um novo lead foi recebido:\n\nNome: %s\nE-mail: %s\nTelefone: %s\nCEP: %s\n\nAcesse o painel administrativo para mais detalhes.", 'sgp-integration'),
            $lead_data['name'],
            $lead_data['email'],
            $lead_data['phone'],
            $lead_data['cep']
        );

        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        
        return wp_mail($notification_email, $subject, $message, $headers);
    }

    public function get_status_label($status) {
        $labels = [
            'new' => __('Novo', 'sgp-integration'),
            'contacted' => __('Contactado', 'sgp-integration'),
            'converted' => __('Convertido', 'sgp-integration'),
            'lost' => __('Perdido', 'sgp-integration'),
            'pending' => __('Pendente', 'sgp-integration')
        ];
        
        return $labels[$status] ?? $status;
    }

    public function ajax_check_updates() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        $log = [];
        $log[] = 'Iniciando verificação de atualização...';
        if (!current_user_can('manage_options')) {
            $log[] = 'Permissão negada.';
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration'), 'log' => $log]);
        }
        $update_url = 'https://juliomartinezjcms.github.io/sgp-updates/update.json';
        $log[] = 'Buscando update.json em: ' . $update_url;
        $response = wp_remote_get($update_url, [
            'timeout' => 15,
            'sslverify' => false
        ]);
        if (is_wp_error($response)) {
            $log[] = 'Erro ao buscar update.json: ' . $response->get_error_message();
            wp_send_json_error(['message' => __('Erro ao verificar atualizações: ' . $response->get_error_message(), 'sgp-integration'), 'log' => $log]);
        }
        $log[] = 'Resposta recebida. Status: ' . wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $log[] = 'Corpo da resposta: <pre>' . esc_html($body) . '</pre>';
        $update_data = json_decode($body, true);
        if (!$update_data || !isset($update_data['version'])) {
            $log[] = 'Falha ao decodificar JSON ou campo "version" ausente.';
            wp_send_json_error(['message' => __('Dados de atualização inválidos.', 'sgp-integration'), 'log' => $log]);
        }
        $current_version = SGP_INTEGRATION_VERSION;
        $new_version = $update_data['version'];
        $log[] = 'Versão atual: ' . $current_version;
        $log[] = 'Nova versão encontrada: ' . $new_version;
        if (version_compare($new_version, $current_version, '>')) {
            $log[] = 'Nova versão disponível!';
            wp_send_json_success([
                'update_available' => true,
                'current_version' => $current_version,
                'new_version' => $new_version,
                'release_date' => $update_data['release_date'] ?? __('Data não disponível', 'sgp-integration'),
                'changelog' => $update_data['changelog'] ?? __('Changelog não disponível', 'sgp-integration'),
                'download_url' => $update_data['download_url'] ?? '',
                'log' => $log
            ]);
        } else {
            $log[] = 'Plugin já está na última versão.';
            wp_send_json_success([
                'update_available' => false,
                'current_version' => $current_version,
                'new_version' => $new_version,
                'log' => $log
            ]);
        }
    }

    public function ajax_update_plugin() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        $log = [];
        $log[] = 'Iniciando atualização do plugin...';
        error_log('[SGP] Iniciando atualização do plugin...');
        if (!current_user_can('manage_options')) {
            $log[] = 'Permissão negada.';
            error_log('[SGP] Permissão negada.');
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration'), 'log' => $log]);
        }
        
        // Inclui o sistema de arquivos do WordPress
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        error_log('[SGP] Sistema de arquivos do WordPress incluído.');
        
        if (!WP_Filesystem()) {
            $log[] = 'Sistema de arquivos não disponível.';
            error_log('[SGP] Sistema de arquivos não disponível.');
            wp_send_json_error(['message' => __('Sistema de arquivos não disponível.', 'sgp-integration'), 'log' => $log]);
        }
        global $wp_filesystem;
        $update_url = 'https://juliomartinezjcms.github.io/sgp-updates/update.json';
        $log[] = 'Buscando update.json em: ' . $update_url;
        error_log('[SGP] Buscando update.json em: ' . $update_url);
        $response = wp_remote_get($update_url, [
            'timeout' => 15,
            'sslverify' => false
        ]);
        if (is_wp_error($response)) {
            $log[] = 'Erro ao buscar update.json: ' . $response->get_error_message();
            error_log('[SGP] Erro ao buscar update.json: ' . $response->get_error_message());
            wp_send_json_error(['message' => __('Erro ao obter informações da atualização.', 'sgp-integration'), 'log' => $log]);
        }
        $log[] = 'Resposta recebida. Status: ' . wp_remote_retrieve_response_code($response);
        error_log('[SGP] Resposta recebida. Status: ' . wp_remote_retrieve_response_code($response));
        $body = wp_remote_retrieve_body($response);
        $log[] = 'Corpo da resposta: <pre>' . esc_html($body) . '</pre>';
        error_log('[SGP] Corpo da resposta: ' . $body);
        $update_data = json_decode($body, true);
        if (!$update_data || !isset($update_data['download_url'])) {
            $log[] = 'Falha ao decodificar JSON ou campo "download_url" ausente.';
            error_log('[SGP] Falha ao decodificar JSON ou campo download_url ausente.');
            wp_send_json_error(['message' => __('URL de download não encontrada.', 'sgp-integration'), 'log' => $log]);
        }
        $download_url = $update_data['download_url'];
        $plugin_dir = WP_PLUGIN_DIR . '/sgp-integration/';
        $log[] = 'Baixando arquivo ZIP: ' . $download_url;
        error_log('[SGP] Baixando arquivo ZIP: ' . $download_url);
        $temp_file = download_url($download_url);
        if (is_wp_error($temp_file)) {
            $log[] = 'Erro ao baixar arquivo ZIP: ' . $temp_file->get_error_message();
            error_log('[SGP] Erro ao baixar arquivo ZIP: ' . $temp_file->get_error_message());
            wp_send_json_error(['message' => __('Erro ao baixar arquivo de atualização.', 'sgp-integration'), 'log' => $log]);
        }
        $log[] = 'Arquivo ZIP baixado em: ' . $temp_file;
        error_log('[SGP] Arquivo ZIP baixado em: ' . $temp_file);
        $log[] = 'Extraindo arquivo ZIP para: ' . WP_PLUGIN_DIR;
        error_log('[SGP] Extraindo arquivo ZIP para: ' . WP_PLUGIN_DIR);
        $unzipped = unzip_file($temp_file, WP_PLUGIN_DIR);
        if (is_wp_error($unzipped)) {
            @unlink($temp_file);
            $log[] = 'Erro ao extrair arquivo ZIP: ' . $unzipped->get_error_message();
            error_log('[SGP] Erro ao extrair arquivo ZIP: ' . $unzipped->get_error_message());
            wp_send_json_error(['message' => __('Erro ao extrair arquivo de atualização.', 'sgp-integration'), 'log' => $log]);
        }
        @unlink($temp_file);
        $log[] = 'Arquivo temporário removido.';
        error_log('[SGP] Arquivo temporário removido.');
        $this->clear_api_cache();
        wp_clean_plugins_cache();
        $log[] = 'Cache limpo.';
        error_log('[SGP] Cache limpo.');
        $msg = sprintf(__('Plugin atualizado com sucesso para a versão %s!', 'sgp-integration'), $update_data['version']);
        error_log('[SGP] ' . $msg);
        wp_send_json_success([
            'message' => $msg,
            'log' => $log
        ]);
    }
    
    public function ajax_filter_reports() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration')]);
        }

        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $end_date = sanitize_text_field($_POST['end_date'] ?? '');
        
        $filtered_data = $this->get_filtered_data($start_date, $end_date);
        $filtered_stats = $this->get_filtered_stats($start_date, $end_date);
        $filtered_charts = $this->get_filtered_charts_data($start_date, $end_date);
        
        wp_send_json_success([
            'leads' => $filtered_data['leads'],
            'consultas' => $filtered_data['consultas'],
            'stats' => $filtered_stats,
            'charts' => $filtered_charts
        ]);
    }
    
    public function ajax_get_charts_data() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permissão negada.', 'sgp-integration')]);
        }

        $charts_data = $this->get_charts_data();
        
        wp_send_json_success($charts_data);
    }
    
    public function ajax_export_leads_csv() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permissão negada.', 'sgp-integration'));
        }

        global $wpdb;
        $table_leads = $wpdb->prefix . 'sgp_leads';
        
        $start_date = sanitize_text_field($_GET['start_date'] ?? '');
        $end_date = sanitize_text_field($_GET['end_date'] ?? '');
        
        $where = '';
        if ($start_date && $end_date) {
            $where = $wpdb->prepare(" WHERE DATE(data_lead) BETWEEN %s AND %s", $start_date, $end_date);
        }
        
        $leads = $wpdb->get_results("
            SELECT * FROM $table_leads 
            $where
            ORDER BY data_lead DESC
        ");
        
        // Headers para download
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="leads-' . date('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // BOM para UTF-8
        echo "\xEF\xBB\xBF";
        
        $output = fopen('php://output', 'w');
        
        // Cabeçalhos CSV
        fputcsv($output, [
            'ID',
            'Nome',
            'Email', 
            'Telefone',
            'CEP',
            'Endereço',
            'Número',
            'Bairro',
            'Cidade',
            'Estado',
            'Viabilidade Aprovada',
            'Observações',
            'Data Lead'
        ], ';');
        
        // Dados
        foreach ($leads as $lead) {
            fputcsv($output, [
                $lead->id,
                $lead->nome,
                $lead->email,
                $lead->telefone,
                $lead->cep,
                $lead->endereco,
                $lead->numero,
                $lead->bairro,
                $lead->cidade,
                $lead->estado,
                $lead->viabilidade_aprovada ? 'Sim' : 'Não',
                $lead->observacoes,
                date_i18n('d/m/Y H:i', strtotime($lead->data_lead))
            ], ';');
        }
        
        fclose($output);
        exit;
    }
    
    public function ajax_export_consultas_csv() {
        check_ajax_referer('sgp-admin-nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permissão negada.', 'sgp-integration'));
        }

        global $wpdb;
        $table_consultas = $wpdb->prefix . 'sgp_consultas';
        
        $start_date = sanitize_text_field($_GET['start_date'] ?? '');
        $end_date = sanitize_text_field($_GET['end_date'] ?? '');
        
        $where = '';
        if ($start_date && $end_date) {
            $where = $wpdb->prepare(" WHERE DATE(data_consulta) BETWEEN %s AND %s", $start_date, $end_date);
        }
        
        $consultas = $wpdb->get_results("
            SELECT * FROM $table_consultas 
            $where
            ORDER BY data_consulta DESC
        ");
        
        // Headers para download
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="consultas-' . date('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // BOM para UTF-8
        echo "\xEF\xBB\xBF";
        
        $output = fopen('php://output', 'w');
        
        // Cabeçalhos CSV
        fputcsv($output, [
            'ID',
            'CEP',
            'Endereço',
            'Número',
            'Bairro',
            'Cidade',
            'Estado',
            'Disponível',
            'Detalhes',
            'Data Consulta'
        ], ';');
        
        // Dados
        foreach ($consultas as $consulta) {
            fputcsv($output, [
                $consulta->id,
                $consulta->cep,
                $consulta->endereco,
                $consulta->numero,
                $consulta->bairro,
                $consulta->cidade,
                $consulta->estado,
                $consulta->disponivel ? 'Sim' : 'Não',
                $consulta->detalhes,
                date_i18n('d/m/Y H:i', strtotime($consulta->data_consulta))
            ], ';');
        }
        
        fclose($output);
        exit;
    }
    

}

// Função para validar a licença remotamente
if (!function_exists('sgp_validar_licenca_remota')) {
    function sgp_validar_licenca_remota($key) {
        $endpoint = 'https://juliocesarmartinez.com.br/valida_key.php?key=' . urlencode($key);
        $response = wp_remote_get($endpoint, ['timeout' => 10]);
        if (is_wp_error($response)) {
            return ['status' => 'invalid'];
        }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return [
            'status' => isset($data['status']) ? $data['status'] : 'invalid'
        ];
    }
}
