/**
 * admin.js - Lógica para o painel administrativo
 */

jQuery(document).ready(function($) {
    // =============================================
    // TESTE DE CONEXÃO COM API
    // =============================================
    
    $('#test-api-connection').on('click', function() {
        const $button = $(this);
        const $status = $('#connection-status');
        
        // Validação dos campos
        const apiUrl = $('#sgp_api_url').val();
        const apiEmail = $('#sgp_api_email').val();
        const apiPassword = $('#sgp_api_password').val();
        
        if (!apiUrl || !apiEmail || !apiPassword) {
            $status.html('<span style="color: red;">✗ ' + sgpAdminVars.i18n.fillAllFields + '</span>');
            return;
        }
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.testingConnection);
        $status.html('');
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_test_api_connection',
                api_url: apiUrl,
                api_email: apiEmail,
                api_password: apiPassword,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span style="color: green;">✓ ' + response.data.message + '</span>');
                } else {
                    $status.html('<span style="color: red;">✗ ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $status.html('<span style="color: red;">✗ ' + sgpAdminVars.i18n.connectionError + '</span>');
            },
            complete: function() {
                $button.prop('disabled', false).text('Testar Conexão');
            }
        });
    });
    
    // =============================================
    // EXPORTAÇÃO DE LEADS
    // =============================================
    
    $('.export-leads-btn').on('click', function() {
        const format = $(this).data('format');
        exportLeads(format);
    });
    
    function exportLeads(format) {
        const $button = $(event.target);
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.exportingLeads);
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_export_leads',
                format: format,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Cria link de download
                    const link = document.createElement('a');
                    link.href = response.data.download_url;
                    link.download = response.data.filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    showAdminNotice(response.data.message, 'success');
                } else {
                    showAdminNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showAdminNotice('Erro na exportação', 'error');
            },
            complete: function() {
                $button.prop('disabled', false).text(format === 'csv' ? 'Exportar CSV' : 'Exportar JSON');
            }
        });
    }
    
    // =============================================
    // LIMPEZA DE CACHE
    // =============================================
    
    $('.clear-cache-btn').on('click', function() {
        if (confirm('Tem certeza que deseja limpar o cache?')) {
            const $button = $(this);
            
            $button.prop('disabled', true).text(sgpAdminVars.i18n.clearingCache);
            
            $.ajax({
                url: sgpAdminVars.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'sgp_clear_cache',
                    nonce: sgpAdminVars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAdminNotice(response.data.message, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAdminNotice(response.data.message, 'error');
                    }
                },
                error: function() {
                    showAdminNotice('Erro ao limpar cache', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Limpar Cache');
                }
            });
        }
    });
    
    // =============================================
    // VALIDAÇÃO DE CAMPOS
    // =============================================
    
    $('#sgp_api_url').on('blur', function() {
        const url = $(this).val();
        if (url && !isValidUrl(url)) {
            $(this).addClass('error');
            showFieldError($(this), 'URL inválida');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    $('#sgp_api_email').on('blur', function() {
        const email = $(this).val();
        if (email && !isValidEmail(email)) {
            $(this).addClass('error');
            showFieldError($(this), 'E-mail inválido');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    $('#sgp_cache_time').on('blur', function() {
        const time = parseInt($(this).val());
        if (time < 300 || time > 86400) {
            $(this).addClass('error');
            showFieldError($(this), 'Tempo deve estar entre 300 e 86400 segundos');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    $('#sgp_coverage_distance').on('blur', function() {
        const distance = parseInt($(this).val());
        if (distance < 50 || distance > 1000) {
            $(this).addClass('error');
            showFieldError($(this), 'Distância deve estar entre 50 e 1000 metros');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
    
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showFieldError($field, message) {
        let $error = $field.siblings('.field-error');
        if ($error.length === 0) {
            $error = $('<div class="field-error" style="color: red; font-size: 12px; margin-top: 5px;"></div>');
            $field.after($error);
        }
        $error.text(message);
    }
    
    function hideFieldError($field) {
        $field.siblings('.field-error').remove();
    }
    
    function showAdminNotice(message, type) {
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = `
            <div class="notice ${noticeClass} is-dismissible">
                <p>${message}</p>
            </div>
        `;
        
        $('.wrap h1').after(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $('.notice').fadeOut();
        }, 5000);
    }
    
    // =============================================
    // TOGGLES E INTERAÇÕES
    // =============================================
    
    // Toggle de seções
    $('.sgp-toggle-section').on('click', function() {
        const $section = $($(this).data('target'));
        $section.toggle();
        $(this).text($section.is(':visible') ? 'Ocultar' : 'Mostrar');
    });
    
    // Confirmação antes de salvar
    $('form').on('submit', function() {
        const hasErrors = $('.error').length > 0;
        if (hasErrors) {
            alert('Por favor, corrija os erros antes de salvar.');
            return false;
        }
    });
    
    // Auto-save de configurações
    let saveTimeout;
    $('input, select, textarea').on('change', function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(function() {
            // Implementar auto-save se necessário
        }, 2000);
    });
    
    // =============================================
    // RELATÓRIOS - FILTROS E GRÁFICOS
    // =============================================
    
    // Filtrar relatórios
    window.filterReports = function() {
        const startDate = $('#start_date').val();
        const endDate = $('#end_date').val();
        
        if (!startDate || !endDate) {
            alert('Por favor, selecione ambas as datas.');
            return;
        }
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_filter_reports',
                start_date: startDate,
                end_date: endDate,
                nonce: sgpAdminVars.nonce
            },
            beforeSend: function() {
                $('#filter-btn').prop('disabled', true).text('Filtrando...');
            },
            success: function(response) {
                if (response.success) {
                    updateStats(response.data.stats);
                    updateCharts(response.data.charts);
                    updateTables(response.data.leads, response.data.consultas);
                } else {
                    alert('Erro ao filtrar relatórios: ' + response.data.message);
                }
            },
            error: function() {
                alert('Erro na requisição AJAX');
            },
            complete: function() {
                $('#filter-btn').prop('disabled', false).text('Filtrar');
            }
        });
    };
    
    // Limpar filtros
    window.clearFilters = function() {
        $('#start_date').val('');
        $('#end_date').val('');
        location.reload();
    };
    
    // Atualizar estatísticas (cards)
    function updateStats(stats) {
        $('.stat-card .stat-number').each(function() {
            const $card = $(this).closest('.stat-card');
            const cardType = $card.find('.stat-label').text().toLowerCase();
            
            if (cardType.includes('leads')) {
                $(this).text(stats.total_leads || 0);
                $card.find('.stat-today').text('Hoje: ' + (stats.leads_today || 0));
            } else if (cardType.includes('consultas')) {
                $(this).text(stats.total_consultas || 0);
                $card.find('.stat-today').text('Hoje: ' + (stats.consultas_today || 0));
            } else if (cardType.includes('aprovadas')) {
                $(this).text(stats.consultas_aprovadas || 0);
            } else if (cardType.includes('conversão')) {
                $(this).text((stats.taxa_conversao || 0) + '%');
            } else if (cardType.includes('negadas')) {
                $(this).text(stats.consultas_negadas || 0);
            } else if (cardType.includes('mês')) {
                $(this).text(stats.leads_this_month || 0);
            }
        });
    }
    
    // Atualizar gráficos
    function updateCharts(chartsData) {
        console.log('updateCharts chamada com dados:', chartsData);
        console.log('window.resultadoChart existe?', !!window.resultadoChart);
        console.log('window.leadsConsultasChart existe?', !!window.leadsConsultasChart);
        console.log('window.locationChart existe?', !!window.locationChart);
        console.log('window.leads30DiasChart existe?', !!window.leads30DiasChart);
        
        // ==================== 1. GRÁFICO DE RESULTADO DAS CONSULTAS (Pizza) ====================
        if (window.resultadoChart) {
            console.log('Atualizando gráfico de pizza:', chartsData.consultas_por_resultado);
            
            // Verificar se há dados no período filtrado
            if (chartsData.consultas_por_resultado && chartsData.consultas_por_resultado.length > 0) {
                // Há dados - mostrar normalmente
                const labels = chartsData.consultas_por_resultado.map(item => item.resultado);
                const data = chartsData.consultas_por_resultado.map(item => parseInt(item.total));
                
                window.resultadoChart.data.labels = labels;
                window.resultadoChart.data.datasets[0].data = data;
                window.resultadoChart.data.datasets[0].backgroundColor = data.map((value, index) => {
                    const label = labels[index];
                    return label === 'Aprovadas' ? '#00a32a' : '#d63638';
                });
            } else {
                // Não há dados - mostrar gráfico zerado
                console.log('Período sem dados - zerando gráfico de pizza');
                window.resultadoChart.data.labels = ['Sem dados'];
                window.resultadoChart.data.datasets[0].data = [0];
                window.resultadoChart.data.datasets[0].backgroundColor = ['#cccccc'];
            }
            
            window.resultadoChart.update();
            console.log('Gráfico de pizza atualizado');
        } else {
            console.log('Não foi possível atualizar gráfico de pizza');
        }
        
        // ==================== 2. GRÁFICO DE LEADS E CONSULTAS POR MÊS (Linha) ====================
        if (window.leadsConsultasChart && chartsData.leads_por_mes && chartsData.consultas_por_mes) {
            console.log('Atualizando gráfico mensal');
            // Preparar dados dos últimos 12 meses
            const meses = [];
            const leadsData = [];
            const consultasData = [];
            
            for (let i = 11; i >= 0; i--) {
                const date = new Date();
                date.setMonth(date.getMonth() - i);
                const mesAno = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
                meses.push(date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }));
                
                const leadMes = chartsData.leads_por_mes.find(item => item.mes === mesAno);
                const consultaMes = chartsData.consultas_por_mes.find(item => item.mes === mesAno);
                
                leadsData.push(leadMes ? parseInt(leadMes.total) : 0);
                consultasData.push(consultaMes ? parseInt(consultaMes.total) : 0);
            }
            
            window.leadsConsultasChart.data.labels = meses;
            window.leadsConsultasChart.data.datasets[0].data = leadsData;
            window.leadsConsultasChart.data.datasets[1].data = consultasData;
            window.leadsConsultasChart.update();
            console.log('Gráfico mensal atualizado');
        } else {
            console.log('Não foi possível atualizar gráfico mensal');
        }
        
        // ==================== 3. GRÁFICO DE LOCALIZAÇÃO (Slides) ====================
        if (window.chartsData && window.createLocationChart) {
            console.log('Atualizando gráfico de localização');
            // Atualizar dados globais
            window.chartsData.leads_por_cidade = chartsData.leads_por_cidade || [];
            window.chartsData.leads_por_bairro = chartsData.leads_por_bairro || [];
            window.chartsData.consultas_por_cidade = chartsData.consultas_por_cidade || [];
            window.chartsData.consultas_por_bairro = chartsData.consultas_por_bairro || [];
            
            // Recriar gráfico de localização com dados filtrados
            const currentSlide = window.currentSlideChart || 0;
            const locationType = $('#location-chart-type').val() || 'cidade';
            window.createLocationChart(currentSlide, locationType);
            console.log('Gráfico de localização atualizado');
        } else {
            console.log('Não foi possível atualizar gráfico de localização');
        }
        
        // ==================== 4. GRÁFICO DOS ÚLTIMOS 30 DIAS ====================
        if (window.leads30DiasChart && chartsData.leads_ultimos_30_dias) {
            console.log('Atualizando gráfico dos últimos 30 dias');
            const dias = [];
            const leadsUltimos30 = [];
            
            for (let i = 29; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const dataStr = date.getFullYear() + '-' + 
                               String(date.getMonth() + 1).padStart(2, '0') + '-' + 
                               String(date.getDate()).padStart(2, '0');
                
                dias.push(date.getDate() + '/' + (date.getMonth() + 1));
                
                const leadDia = chartsData.leads_ultimos_30_dias.find(item => item.data === dataStr);
                leadsUltimos30.push(leadDia ? parseInt(leadDia.total) : 0);
            }
            
            window.leads30DiasChart.data.labels = dias;
            window.leads30DiasChart.data.datasets[0].data = leadsUltimos30;
            window.leads30DiasChart.update();
            console.log('Gráfico dos últimos 30 dias atualizado');
        } else {
            console.log('Não foi possível atualizar gráfico dos últimos 30 dias');
        }
    }

    
    // Atualizar tabelas
    function updateTables(leads, consultas) {
        // Atualizar tabela de leads
        const $leadsTable = $('#leads-table tbody');
        $leadsTable.empty();
        
        if (leads && leads.length > 0) {
            leads.forEach(function(lead) {
                const row = `
                    <tr>
                        <td>${lead.id}</td>
                        <td>${lead.nome}</td>
                        <td>${lead.email}</td>
                        <td>${lead.telefone}</td>
                        <td>${lead.cidade}</td>
                        <td>${lead.bairro || '-'}</td>
                        <td>${new Date(lead.data_lead).toLocaleDateString('pt-BR')}</td>
                    </tr>
                `;
                $leadsTable.append(row);
            });
        } else {
            $leadsTable.append('<tr><td colspan="7">Nenhum lead encontrado no período selecionado.</td></tr>');
        }
        
        // Atualizar tabela de consultas
        const $consultasTable = $('#consultas-table tbody');
        $consultasTable.empty();
        
        if (consultas && consultas.length > 0) {
            consultas.forEach(function(consulta) {
                const row = `
                    <tr>
                        <td>${consulta.id}</td>
                        <td>${consulta.cep}</td>
                        <td>${consulta.endereco}</td>
                        <td>${consulta.cidade}</td>
                        <td>${consulta.bairro || '-'}</td>
                        <td>${consulta.disponivel == 1 ? 'Sim' : 'Não'}</td>
                        <td>${new Date(consulta.data_consulta).toLocaleDateString('pt-BR')}</td>
                    </tr>
                `;
                $consultasTable.append(row);
            });
        } else {
            $consultasTable.append('<tr><td colspan="7">Nenhuma consulta encontrada no período selecionado.</td></tr>');
        }
    }
    
    // Filtros rápidos
    $('.quick-filter').on('click', function() {
        const days = $(this).data('days');
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - days);
        
        $('#start_date').val(startDate.toISOString().split('T')[0]);
        $('#end_date').val(endDate.toISOString().split('T')[0]);
        
        filterReports();
    });
    
    // Exportação CSV
    $('.export-csv').on('click', function() {
        const type = $(this).data('type');
        const startDate = $('#start_date').val();
        const endDate = $('#end_date').val();
        
        let url = sgpAdminVars.ajaxUrl + '?action=sgp_export_' + type + '_csv&nonce=' + sgpAdminVars.nonce;
        if (startDate && endDate) {
            url += '&start_date=' + startDate + '&end_date=' + endDate;
        }
        
        window.open(url, '_blank');
    });
}); 