/**
 * admin.js - Lógica para o painel administrativo
 */

jQuery(document).ready(function($) {
    // =============================================
    // TESTE DE CONEXÃO COM API
    // =============================================
    
    $('#test-api-connection').on('click', function() {
        const $button = $(this);
        const $status = $('#connection-status');
        
        // Validação dos campos
        const apiUrl = $('#sgp_api_url').val();
        const apiEmail = $('#sgp_api_email').val();
        const apiPassword = $('#sgp_api_password').val();
        
        if (!apiUrl || !apiEmail || !apiPassword) {
            $status.html('<span style="color: red;">✗ ' + sgpAdminVars.i18n.fillAllFields + '</span>');
            return;
        }
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.testingConnection);
        $status.html('');
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_test_api_connection',
                api_url: apiUrl,
                api_email: apiEmail,
                api_password: apiPassword,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span style="color: green;">✓ ' + response.data.message + '</span>');
                } else {
                    $status.html('<span style="color: red;">✗ ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $status.html('<span style="color: red;">✗ ' + sgpAdminVars.i18n.connectionError + '</span>');
            },
            complete: function() {
                $button.prop('disabled', false).text('Testar Conexão');
            }
        });
    });
    
    // =============================================
    // EXPORTAÇÃO DE LEADS
    // =============================================
    
    $('.export-leads-btn').on('click', function() {
        const format = $(this).data('format');
        exportLeads(format);
    });
    
    function exportLeads(format) {
        const $button = $(event.target);
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.exportingLeads);
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_export_leads',
                format: format,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Cria link de download
                    const link = document.createElement('a');
                    link.href = response.data.download_url;
                    link.download = response.data.filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    showAdminNotice(response.data.message, 'success');
                } else {
                    showAdminNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showAdminNotice('Erro na exportação', 'error');
            },
            complete: function() {
                $button.prop('disabled', false).text(format === 'csv' ? 'Exportar CSV' : 'Exportar JSON');
            }
        });
    }
    
    // =============================================
    // LIMPEZA DE CACHE
    // =============================================
    
    $('.clear-cache-btn').on('click', function() {
        if (confirm('Tem certeza que deseja limpar o cache?')) {
            const $button = $(this);
            
            $button.prop('disabled', true).text(sgpAdminVars.i18n.clearingCache);
            
            $.ajax({
                url: sgpAdminVars.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'sgp_clear_cache',
                    nonce: sgpAdminVars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAdminNotice(response.data.message, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAdminNotice(response.data.message, 'error');
                    }
                },
                error: function() {
                    showAdminNotice('Erro ao limpar cache', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Limpar Cache');
                }
            });
        }
    });
    
    // =============================================
    // VALIDAÇÃO DE CAMPOS
    // =============================================
    
    $('#sgp_api_url').on('blur', function() {
        const url = $(this).val();
        if (url && !isValidUrl(url)) {
            $(this).addClass('error');
            showFieldError($(this), 'URL inválida');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    $('#sgp_api_email').on('blur', function() {
        const email = $(this).val();
        if (email && !isValidEmail(email)) {
            $(this).addClass('error');
            showFieldError($(this), 'E-mail inválido');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    $('#sgp_cache_time').on('blur', function() {
        const time = parseInt($(this).val());
        if (time < 300 || time > 86400) {
            $(this).addClass('error');
            showFieldError($(this), 'Tempo deve estar entre 300 e 86400 segundos');
        } else {
            $(this).removeClass('error');
            hideFieldError($(this));
        }
    });
    
    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    
    function isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
    
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showFieldError($field, message) {
        let $error = $field.siblings('.field-error');
        if ($error.length === 0) {
            $error = $('<div class="field-error" style="color: red; font-size: 12px; margin-top: 5px;"></div>');
            $field.after($error);
        }
        $error.text(message);
    }
    
    function hideFieldError($field) {
        $field.siblings('.field-error').remove();
    }
    
    function showAdminNotice(message, type) {
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = `
            <div class="notice ${noticeClass} is-dismissible">
                <p>${message}</p>
            </div>
        `;
        
        $('.wrap h1').after(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $('.notice').fadeOut();
        }, 5000);
    }
    
    // =============================================
    // TOGGLES E INTERAÇÕES
    // =============================================
    
    // Toggle de seções
    $('.sgp-toggle-section').on('click', function() {
        const $section = $($(this).data('target'));
        $section.toggle();
        $(this).text($section.is(':visible') ? 'Ocultar' : 'Mostrar');
    });
    
    // Confirmação antes de salvar
    $('form').on('submit', function() {
        const hasErrors = $('.error').length > 0;
        if (hasErrors) {
            alert('Por favor, corrija os erros antes de salvar.');
            return false;
        }
    });
    
    // Auto-save de configurações
    let saveTimeout;
    $('input, select, textarea').on('change', function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(function() {
            // Implementar auto-save se necessário
        }, 2000);
    });
}); 