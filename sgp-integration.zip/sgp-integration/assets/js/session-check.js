window.sgpSessionCheck = (function($) {
    let isEnabled = false;
    let isInitialized = false;

    function checkSessionValidity() {
        // Só executa se estiver habilitado
        if (!isEnabled) return;
        
        if (window.sgpSessionCheckInProgress) return;
        window.sgpSessionCheckInProgress = true;
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'verify_customer_session',
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            timeout: 5000,
            success: function(response) {
                if (!response.success) {
                    redirectToLogin('Sua sessão expirou. Faça login novamente.');
                }
            },
            error: function() {
                redirectToLogin('Erro ao verificar sessão. Faça login novamente.');
            },
            complete: function() {
                window.sgpSessionCheckInProgress = false;
            }
        });
    }

    function startPeriodicSessionCheck() {
        // Só executa se estiver habilitado
        if (!isEnabled) return;
        
        if (window.sgpSessionCheckInterval) clearInterval(window.sgpSessionCheckInterval);
        window.sgpSessionCheckInterval = setInterval(function() {
            if (!document.hidden) checkSessionValidity();
        }, 300000);
        
        // Removido: listeners de visibilidade e foco para evitar verificações extras
        // document.addEventListener('visibilitychange', function() {
        //     if (!document.hidden && isEnabled) checkSessionValidity();
        // });
        // window.addEventListener('focus', function() {
        //     if (isEnabled) checkSessionValidity();
        // });
        // window.addEventListener('pageshow', function(event) {
        //     if (event.persisted && isEnabled) checkSessionValidity();
        // });
    }

    function preventPageCache() {
        if (window.sgpSessionCachePreventionInitialized) return;
        window.sgpSessionCachePreventionInitialized = true;
        
        window.addEventListener('pageshow', function(event) {
            if (event.persisted && isEnabled) checkSessionValidity();
        });
        
        window.addEventListener('focus', function() {
            if (isEnabled) checkSessionValidity();
        });
        
        if ($('meta[http-equiv="Cache-Control"]').length === 0) {
            $('head').append('<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">');
            $('head').append('<meta http-equiv="Pragma" content="no-cache">');
            $('head').append('<meta http-equiv="Expires" content="0">');
        }
        
        window.addEventListener('beforeunload', function() {
            if ('caches' in window) {
                caches.keys().then(function(names) {
                    names.forEach(function(name) { caches.delete(name); });
                });
            }
        });
    }

    function redirectToLogin(message) {
        clearLocalData();
        if (message) {
            const overlay = $('<div>', { 
                css: { 
                    position: 'fixed', 
                    top: 0, 
                    left: 0, 
                    width: '100%', 
                    height: '100%', 
                    backgroundColor: 'rgba(0,0,0,0.8)', 
                    zIndex: 99999, 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center' 
                } 
            });
            const messageBox = $('<div>', { 
                css: { 
                    backgroundColor: 'white', 
                    padding: '30px', 
                    borderRadius: '8px', 
                    textAlign: 'center', 
                    maxWidth: '400px', 
                    margin: '20px' 
                }, 
                html: `<h3 style="color: #ff7b00; margin-bottom: 15px;">⚠️ Sessão Expirada</h3><p style="margin-bottom: 20px;">${message}</p><div style="color: #666; font-size: 14px;"><div class="sgp-spinner" style="display: inline-block; margin-right: 10px;"></div>Redirecionando...</div>` 
            });
            overlay.append(messageBox);
            $('body').append(overlay);
            setTimeout(() => { window.location.replace(window.location.origin); }, 2000);
        } else {
            window.location.replace(window.location.origin);
        }
    }

    function clearLocalData() {
        if (typeof(Storage) !== "undefined") {
            localStorage.removeItem('sgp_customer_data');
            sessionStorage.removeItem('sgp_customer_data');
        }
    }

    function init() {
        if (isInitialized) return;
        isInitialized = true;
        
        // Verifica se a verificação de sessão está habilitada
        if (typeof sgpCustomerVars !== 'undefined' && sgpCustomerVars.enableSessionCheck) {
            isEnabled = true;
            
            // Inicia verificações apenas se estiver habilitado
            checkSessionValidity();
            startPeriodicSessionCheck();
        }
        
        // Sempre previne cache (independente da flag)
        preventPageCache();
    }

    function enable() {
        isEnabled = true;
        if (isInitialized) {
            checkSessionValidity();
            startPeriodicSessionCheck();
        }
    }

    function disable() {
        isEnabled = false;
        if (window.sgpSessionCheckInterval) {
            clearInterval(window.sgpSessionCheckInterval);
            window.sgpSessionCheckInterval = null;
        }
    }

    return {
        init,
        enable,
        disable,
        checkSessionValidity,
        startPeriodicSessionCheck,
        preventPageCache,
        redirectToLogin,
        clearLocalData,
        isEnabled: function() { return isEnabled; }
    };
})(jQuery); 