jQuery(document).ready(function($) {
    // =============================================
    // MÁSCARAS E VALIDAÇÕES
    // =============================================
    
    // Máscara para CEP
    $('.sgp-mask-cep').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        if (value.length > 5) {
            value = value.substring(0,5) + '-' + value.substring(5,8);
        }
        $(this).val(value);
    });

    // Máscara para CPF/CNPJ
    $('.sgp-cpfcnpj-mask, #sgp-login-cpfcnpj').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        
        if (value.length <= 11) {
            // Formatar como CPF: 000.000.000-00
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        } else {
            // Formatar como CNPJ: 00.000.000/0000-00
            value = value.replace(/^(\d{2})(\d)/, '$1.$2');
            value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
            value = value.replace(/\.(\d{3})(\d)/, '.$1/$2');
            value = value.replace(/(\d{4})(\d)/, '$1-$2');
        }
        
        $(this).val(value);
    });

    // Máscara para telefone
    $('.sgp-phone-mask').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        
        if (value.length <= 10) {
            // Telefone fixo: (00) 0000-0000
            value = value.replace(/(\d{2})(\d)/, '($1) $2');
            value = value.replace(/(\d{4})(\d)/, '$1-$2');
        } else {
            // Celular: (00) 00000-0000
            value = value.replace(/(\d{2})(\d)/, '($1) $2');
            value = value.replace(/(\d{5})(\d)/, '$1-$2');
        }
        
        $(this).val(value);
    });

    // =============================================
    // PREENCHIMENTO AUTOMÁTICO POR CEP
    // =============================================
    
    $('#sgp-cep').on('blur', function() {
        const cep = $(this).val().replace(/\D/g, '');
        
        if (cep.length === 8) {
            // Mostra indicador de carregamento
            $(this).addClass('sgp-loading');
            
            // Consulta CEP via API ViaCEP
            $.getJSON(`https://viacep.com.br/ws/${cep}/json/`, function(data) {
                if (!data.erro) {
                    // Preenche apenas bairro, cidade e estado
                    if (data.bairro) $('#sgp-neighborhood').val(data.bairro);
                    if (data.localidade) $('#sgp-city').val(data.localidade);
                    if (data.uf) $('#sgp-state').val(data.uf);
                    // Foca no campo número se bairro foi preenchido
                    if (data.bairro) {
                        $('#sgp-number').focus();
                    }
                } else {
                    showAlert('CEP não encontrado. Verifique e tente novamente.', 'error');
                }
            }).fail(function() {
                showAlert('Erro ao consultar CEP. Tente novamente.', 'error');
            }).always(function() {
                $('#sgp-cep').removeClass('sgp-loading');
            });
        }
    });

    // =============================================
    // CONSULTA DE DISPONIBILIDADE
    // =============================================
    
    $('#sgp-availability-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $results = $('#sgp-coverage-results');
        
        // Validação completa dos campos obrigatórios
        const requiredFields = ['cep', 'street', 'number', 'neighborhood', 'city', 'state'];
        const missingFields = [];
        
        requiredFields.forEach(field => {
            const $field = $form.find(`[name="${field}"]`);
            if (!$field.val().trim()) {
                missingFields.push($field.prev('label').text().replace('*', '').trim());
                $field.addClass('sgp-input-error');
            } else {
                $field.removeClass('sgp-input-error');
            }
        });
        
        // Validação do checkbox de termos
        if (!$form.find('[name="terms"]').is(':checked')) {
            showAlert('Você deve concordar com os termos para continuar.', 'error');
            return;
        }
        
        if (missingFields.length > 0) {
            showAlert(`Preencha os campos obrigatórios: ${missingFields.join(', ')}`, 'error');
            return;
        }
        
        // Validação do CEP
        const cep = $form.find('[name="cep"]').val().replace(/\D/g, '');
        if (cep.length !== 8) {
            showAlert('CEP inválido. Digite os 8 números.', 'error');
            return;
        }
        
        // Mostra loader
        toggleLoading($button, true);
        
        // Limpa resultados anteriores
        resetResults($results);
        
        // Envia requisição AJAX
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleAvailabilityResponse(response.data);
                } else {
                    showAlert(response.data.message || 'Erro na consulta. Tente novamente.', 'error');
                }
            },
            error: function(xhr) {
                const errorMsg = xhr.responseJSON?.data?.message || 'Erro na comunicação com o servidor.';
                showAlert(errorMsg, 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    });
    
    // Remove classe de erro ao digitar
    $('.sgp-input').on('input', function() {
        $(this).removeClass('sgp-input-error');
    });

    // =============================================
    // LOGIN DO CLIENTE
    // =============================================
    
    $('#sgp-customer-login-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-login-message');
        
        // Validação básica - CORRIGIDO PARA CPF/CNPJ
        const cpfcnpj = $form.find('[name="cpfcnpj"]').val();
        const password = $form.find('[name="password"]').val();
        
        if (!cpfcnpj || !password) {
            showAlert('Preencha todos os campos obrigatórios.', 'error', $message);
            return;
        }
        
        // Validação do CPF/CNPJ
        const cpfcnpjClean = cpfcnpj.replace(/\D/g, '');
        if (cpfcnpjClean.length !== 11 && cpfcnpjClean.length !== 14) {
            showAlert('CPF/CNPJ inválido. Verifique os dados informados.', 'error', $message);
            return;
        }
        
        // Mostra loader
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        // Envia requisição AJAX
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleLoginSuccess(response.data, $message);
                } else {
                    handleLoginError(response.data, $message);
                }
            },
            error: function(xhr) {
                const errorMsg = xhr.responseJSON?.data?.message || 'Erro na comunicação com o servidor.';
                showAlert(errorMsg, 'error', $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    });
    
    // =============================================
    // RECUPERAÇÃO DE SENHA
    // =============================================
    
    $('#sgp-recover-password-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-recover-message');
        
        // Validação básica
        if (!$form.find('[name="email"]').val()) {
            showAlert('Informe seu e-mail cadastrado.', 'error', $message);
            return;
        }
        
        // Mostra loader
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        // Envia requisição AJAX
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleRecoverySuccess(response.data, $message, $form);
                } else {
                    handleRecoveryError(response.data, $message);
                }
            },
            error: function(xhr) {
                const errorMsg = xhr.responseJSON?.data?.message || 'Erro na comunicação com o servidor.';
                showAlert(errorMsg, 'error', $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    });
    
    // =============================================
    // CONTROLE DE MODAL
    // =============================================
    
    // Abre modal de recuperação
    $('a[href="#recover-password"]').on('click', function(e) {
        e.preventDefault();
        $('#sgp-recover-password-modal').show();
    });
    
    // Fecha modal
    $('.sgp-close-modal').on('click', function() {
        $(this).closest('.sgp-modal').hide();
    });
    
    // Fecha modal ao clicar fora
    $(window).on('click', function(e) {
        if ($(e.target).hasClass('sgp-modal')) {
            $(e.target).hide();
        }
    });
    
    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    
    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        
        if (isLoading) {
            $button.find('.sgp-btn-text').hide();
            $button.find('.sgp-btn-loading').show();
        } else {
            $button.find('.sgp-btn-text').show();
            $button.find('.sgp-btn-loading').hide();
        }
    }
    
    function showAlert(message, type, $container = null) {
        const $target = $container || $('#sgp-login-message');
        const alertClass = type === 'error' ? 'sgp-alert-error' : 'sgp-alert-success';
        
        $target.removeClass('sgp-alert-success sgp-alert-error')
               .addClass('sgp-alert ' + alertClass)
               .html(message)
               .show();
               
        // Auto-hide após 5 segundos se for success
        if (type === 'success') {
            setTimeout(() => {
                $target.fadeOut();
            }, 5000);
        }
    }
    
    function resetResults($container) {
        $container.hide()
            .find('#sgp-coverage-status')
            .removeClass('sgp-status-success sgp-status-error sgp-status-warning')
            .empty();
        
        $('#sgp-address-confirmation').hide();
        $('#sgp-confirmed-address').empty();
        $('.sgp-plans-list').empty();
        $('#sgp-plans-container').hide();
        $('#sgp-lead-form-container').hide();
    }
    
    function renderPlans(plans) {
        const $container = $('.sgp-plans-list');
        $container.empty();
        
        plans.forEach(plan => {
            const template = $('#sgp-plan-template').html()
                .replace(/{{name}}/g, plan.name)
                .replace(/{{price}}/g, formatCurrency(plan.price))
                .replace(/{{download_speed}}/g, plan.download_speed)
                .replace(/{{upload_speed}}/g, plan.upload_speed)
                .replace(/{{type}}/g, plan.type)
                .replace(/{{id}}/g, plan.id);
            
            $container.append(template);
        });
    }
    
    function formatCurrency(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    }
    
    function handleAvailabilityResponse(data) {
        const $results = $('#sgp-coverage-results');
        const $status = $('#sgp-coverage-status');
        const $addressConfirmation = $('#sgp-address-confirmation');
        const $confirmedAddress = $('#sgp-confirmed-address');
        
        // Mostra o endereço consultado
        if (data.address) {
            $confirmedAddress.text(data.address);
            $addressConfirmation.show();
        }
        
        // Define o status baseado na resposta
        if (data.available) {
            $status.removeClass('sgp-status-warning sgp-status-error').addClass('sgp-status-success')
                .html('<span class="sgp-status-icon" style="font-size:2rem;vertical-align:middle;">✅</span> <span class="sgp-status-text" style="font-size:1.2rem;font-weight:600;margin-left:0.5rem;">Atendemos sua região!</span>');
            // Mostra planos se disponíveis
            if (data.plans && data.plans.length > 0) {
                renderPlans(data.plans);
                $('#sgp-plans-container').show();
                $('#sgp-lead-form-container').show();
            }
        } else {
            $status.removeClass('sgp-status-success sgp-status-error').addClass('sgp-status-warning')
                .html('<strong>⚠️ Fora da área de cobertura</strong><br>Infelizmente não atendemos sua região no momento. Entre em contato conosco para verificar futuras expansões.');
        }
        
        // Mostra resultados
        $results.show();
        
        // Scroll suave para os resultados
        $('html, body').animate({
            scrollTop: $results.offset().top - 50
        }, 500);
    }
    
    function handleLoginSuccess(data, $message) {
        showAlert('Login realizado com sucesso! Redirecionando...', 'success', $message);
        
        // Armazena o token JWT (se aplicável)
        if (data.token) {
            localStorage.setItem('sgp_auth_token', data.token);
        }
        
        // Redireciona ou recarrega a página
        setTimeout(() => {
            window.location.href = data.redirect_url || window.location.href;
        }, 1500);
    }
    
    function handleLoginError(data, $message) {
        const errorMsg = data.message || 'CPF/CNPJ ou senha incorretos. Tente novamente.';
        showAlert(errorMsg, 'error', $message);
    }
    
    function handleRecoverySuccess(data, $message, $form) {
        showAlert('Enviamos um e-mail com instruções para redefinir sua senha.', 'success', $message);
        $form[0].reset();
    }
    
    function handleRecoveryError(data, $message) {
        const errorMsg = data.message || 'Erro ao solicitar recuperação de senha.';
        showAlert(errorMsg, 'error', $message);
    }
    
    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    
    // Armazena textos originais dos botões
    $('button[type="submit"]').each(function() {
        const $btnText = $(this).find('.sgp-btn-text, .sgp-button-text');
        if ($btnText.length) {
            $(this).data('original-text', $btnText.text());
        }
    });
    
    // Aplica máscara automaticamente em campos de CPF/CNPJ
    $('[name="cpfcnpj"], .sgp-cpfcnpj-mask').trigger('input');

    // =============================================
    // PAINEL DO CLIENTE - FUNCIONALIDADES
    // =============================================

    // Troca de abas
    $('.sgp-nav-item').on('click', function(e) {
        e.preventDefault();
        const tabId = $(this).data('tab');
        // Ativa a aba clicada
        $('.sgp-nav-item').removeClass('active');
        $(this).addClass('active');
        // Mostra o conteúdo correspondente
        $('.sgp-tab-pane').removeClass('active');
        $(`#${tabId}`).addClass('active');
        // Carrega conteúdo dinâmico se necessário
        if (tabId === 'invoices') {
            loadInvoices();
        } else if (tabId === 'tickets') {
            loadTickets();
        }
    });

    // Carrega faturas via AJAX
    function loadInvoices() {
        const $container = $('.sgp-invoices-content');
        const $loading = $('.sgp-invoices-loading');
        $container.empty();
        $loading.show();
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_customer_invoices',
                period: $('#sgp-invoice-period').val(),
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderInvoices(response.data);
                } else {
                    $container.html('<div class="sgp-alert sgp-alert-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                $container.html('<div class="sgp-alert sgp-alert-error">Erro ao carregar faturas</div>');
            },
            complete: function() {
                $loading.hide();
            }
        });
    }

    // Renderiza a lista de faturas
    function renderInvoices(data) {
        const $container = $('.sgp-invoices-content');
        // Garante que está pegando o array de faturas
        const invoices = data.faturas || [];
        if (!Array.isArray(invoices) || invoices.length === 0) {
            $container.html('<p class="sgp-no-results">Nenhuma fatura encontrada</p>');
            return;
        }
        const table = `
            <table class="sgp-invoices-table">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Emissão</th>
                        <th>Vencimento</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoices.map(invoice => `
                        <tr>
                            <td>#${invoice.numero_documento || invoice.id || 'N/A'}</td>
                            <td>${invoice.vencimento_atualizado || invoice.vencimento || 'N/A'}</td>
                            <td>${invoice.vencimento || 'N/A'}</td>
                            <td>R$ ${(invoice.valorcorrigido || invoice.valor || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</td>
                            <td><span class="sgp-status-badge sgp-status-${(invoice.status || '').toLowerCase()}">${invoice.status || 'N/A'}</span></td>
                            <td>
                                ${invoice.link ? `<a href="${invoice.link}" target="_blank" class="sgp-button sgp-button-secondary">Boleto</a>` : ''}
                                ${invoice.gerarpix ? `<button class="sgp-button sgp-button-primary sgp-pay-invoice-btn" data-invoice-id="${invoice.id}">PIX</button>` : ''}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        $container.html(table);
    }

    // Carrega chamados via AJAX
    function loadTickets() {
        const $container = $('.sgp-tickets-content');
        const $loading = $('.sgp-tickets-loading');
        $container.empty();
        $loading.show();
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_customer_tickets',
                period: $('#sgp-ticket-period').val(),
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderTickets(response.data);
                } else {
                    $container.html('<div class="sgp-alert sgp-alert-error">' + response.data.message + '</div>');
                }
            },
            error: function() {
                $container.html('<div class="sgp-alert sgp-alert-error">Erro ao carregar chamados</div>');
            },
            complete: function() {
                $loading.hide();
            }
        });
    }

    // Renderiza a lista de chamados
    function renderTickets(tickets) {
        const $container = $('.sgp-tickets-content');
        if (tickets.length === 0) {
            $container.html('<p class="sgp-no-results">Nenhum chamado encontrado</p>');
            return;
        }
        const table = `
            <table class="sgp-tickets-table">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Título</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${tickets.map(ticket => `
                        <tr>
                            <td>#${ticket.id}</td>
                            <td>${ticket.title}</td>
                            <td><span class="sgp-status-badge sgp-status-${ticket.status}">${ticket.status_label}</span></td>
                            <td>
                                <button class="sgp-button sgp-button-secondary sgp-view-ticket-btn" data-ticket-id="${ticket.id}">
                                    Visualizar
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        $container.html(table);
    }
});

// =============================================
// LISTAGEM DE PLANOS - FUNCIONALIDADES
// =============================================

jQuery(document).ready(function($) {
    // Filtragem de planos
    $('.sgp-filter-select').on('change', function() {
        filterPlans();
    });

    // Seleção para comparação
    $('.sgp-compare-plan').on('click', function() {
        const $card = $(this).closest('.sgp-plan-card');
        const planId = $card.data('plan-id');
        
        $card.toggleClass('selected');
        updateComparisonButton();
    });

    // Botão de comparação
    $('#sgp-compare-plans').on('click', function() {
        openComparisonModal();
    });

    // Limpar comparação
    $('#sgp-clear-comparison').on('click', function() {
        $('.sgp-plan-card').removeClass('selected');
        updateComparisonButton();
    });

    // Fechar modal
    $('.sgp-close-modal').on('click', function() {
        $('#sgp-comparison-modal').removeClass('show');
    });

    // Função para filtrar planos
    function filterPlans() {
        const type = $('#sgp-plan-type').val();
        const speed = $('#sgp-plan-speed').val();
        const price = $('#sgp-plan-price').val();
        
        $('.sgp-plan-card').each(function() {
            const $card = $(this);
            const cardType = $card.data('type');
            const cardSpeed = parseInt($card.data('download-speed'));
            const cardPrice = parseFloat($card.data('price'));
            
            const typeMatch = type === 'all' || cardType === type;
            const speedMatch = speed === 'all' || (
                (speed === '100' && cardSpeed <= 100) ||
                (speed === '300' && cardSpeed <= 300) ||
                (speed === '600' && cardSpeed <= 600) ||
                (speed === '1000' && cardSpeed > 1000)
            );
            const priceMatch = price === 'all' || (
                (price === '100' && cardPrice <= 100) ||
                (price === '200' && cardPrice <= 200) ||
                (price === '300' && cardPrice <= 300) ||
                (price === '500' && cardPrice > 500)
            );
            
            if (typeMatch && speedMatch && priceMatch) {
                $card.show();
            } else {
                $card.hide();
            }
        });
    }

    // Atualiza o botão de comparação
    function updateComparisonButton() {
        const selectedCount = $('.sgp-plan-card.selected').length;
        const $button = $('#sgp-compare-plans');
        
        if (selectedCount > 0) {
            $button.prop('disabled', false);
            $button.html(`<i class="sgp-icon sgp-icon-compare"></i> Comparar (${selectedCount})`);
        } else {
            $button.prop('disabled', true);
            $button.html('<i class="sgp-icon sgp-icon-compare"></i> Comparar (0)');
        }
    }

    // Abre o modal de comparação
    function openComparisonModal() {
        const selectedPlans = $('.sgp-plan-card.selected');
        const template = $('#sgp-comparison-plan-template').html();
        
        if (selectedPlans.length < 2) {
            alert('Selecione pelo menos 2 planos para comparar');
            return;
        }
        
        // Limpa comparações anteriores
        $('.sgp-comparison-table td.sgp-comparison-plan').remove();
        
        // Adiciona cada plano selecionado
        selectedPlans.each(function() {
            const $card = $(this);
            const planData = {
                id: $card.data('plan-id'),
                name: $card.find('.sgp-plan-name').text(),
                price: $card.find('.sgp-price-value').text()
            };
            
            const planHtml = template
                .replace(/{{id}}/g, planData.id)
                .replace(/{{name}}/g, planData.name)
                .replace(/{{price}}/g, planData.price);
                
            $('.sgp-comparison-table thead tr').append(planHtml);
        });
        
        // Preenche os dados de comparação
        selectedPlans.each(function() {
            const $card = $(this);
            const planId = $card.data('plan-id');
            
            // Preço
            $(`.sgp-comparison-table tbody tr:nth-child(1)`).append(
                `<td>${$card.find('.sgp-price-value').text()}</td>`
            );
            
            // Download
            $(`.sgp-comparison-table tbody tr:nth-child(2)`).append(
                `<td>${$card.find('.sgp-speed-item:nth-child(1) .sgp-speed-value').text()} Mbps</td>`
            );
            
            // Upload
            $(`.sgp-comparison-table tbody tr:nth-child(3)`).append(
                `<td>${$card.find('.sgp-speed-item:nth-child(2) .sgp-speed-value').text()} Mbps</td>`
            );
            
            // Tipo
            $(`.sgp-comparison-table tbody tr:nth-child(4)`).append(
                `<td>${$card.find('.sgp-badge').text()}</td>`
            );
            
            // Features
            const features = $card.find('.sgp-feature-item').map(function() {
                return $(this).text().trim();
            }).get().join(', ');
            
            $(`.sgp-comparison-table tbody tr:nth-child(5)`).append(
                `<td>${features}</td>`
            );
        });
        
        // Mostra o modal
        $('#sgp-comparison-modal').addClass('show');
    }

    // Selecionar plano no modal de comparação
    $(document).on('click', '.sgp-select-plan-in-comparison', function() {
        const planId = $(this).closest('td').data('plan-id');
        // Aqui você implementaria a ação de contratação
        alert(`Contratar plano ${planId}`);
    });
});