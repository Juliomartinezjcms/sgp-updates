/**
 * customer-panel.js - Lógica específica para a área do cliente logado
 * Depende: jQuery, sgpIntegrationVars (localizado no frontend)
 */

jQuery(document).ready(function($) {
    // =============================================
    // CONSTANTES E VARIÁVEIS GLOBAIS
    // =============================================
    const CUSTOMER_API = {
        invoices: 'get_customer_invoices',
        tickets: 'get_customer_tickets',
        update_profile: 'update_customer_profile',
        change_plan: 'request_plan_change'
    };

    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    initCustomerPanel();

    function initCustomerPanel() {
        // Carrega dados iniciais baseado na aba ativa
        loadActiveTabData();
        
        // Event Listeners
        bindEvents();
        
        // Verifica se há hash na URL (para abas diretas)
        checkUrlHash();
    }

    // =============================================
    // CONTROLE DE ABAS
    // =============================================
    function loadActiveTabData() {
        const activeTab = $('.sgp-nav-item.active').data('tab');
        
        switch(activeTab) {
            case 'invoices':
                loadInvoices();
                break;
            case 'tickets':
                loadTickets();
                break;
            case 'profile':
                setupProfileEdit();
                break;
        }
    }

    function checkUrlHash() {
        if (window.location.hash) {
            const tabId = window.location.hash.substring(1);
            const $tab = $(`.sgp-nav-item[data-tab="${tabId}"]`);
            
            if ($tab.length) {
                $('.sgp-nav-item').removeClass('active');
                $tab.addClass('active');
                
                $('.sgp-tab-pane').removeClass('active');
                $(`#${tabId}`).addClass('active');
                
                loadActiveTabData();
            }
        }
    }

    // =============================================
    // EVENT BINDING
    // =============================================
    function bindEvents() {
        // Navegação entre abas
        $('.sgp-nav-item').on('click', function(e) {
            e.preventDefault();
            switchTab($(this));
        });

        // Faturas
        $(document).on('change', '#sgp-invoice-period', loadInvoices);
        $(document).on('click', '.sgp-pay-invoice-btn', payInvoice);

        // Chamados
        $(document).on('click', '.sgp-new-ticket-btn', showNewTicketModal);
        $(document).on('submit', '#sgp-new-ticket-form', submitNewTicket);

        // Perfil
        $(document).on('click', '.sgp-edit-profile-btn', enableProfileEdit);
        $(document).on('click', '.sgp-cancel-edit-btn', cancelProfileEdit);
        $(document).on('submit', '#sgp-profile-form', updateProfile);

        // Planos
        $(document).on('click', '.sgp-change-plan-btn', showPlanChangeModal);
        $(document).on('click', '#sgp-confirm-plan-change', confirmPlanChange);
    }

    function switchTab($tab) {
        const tabId = $tab.data('tab');
        
        // Atualiza UI
        $('.sgp-nav-item').removeClass('active');
        $tab.addClass('active');
        
        $('.sgp-tab-pane').removeClass('active');
        $(`#${tabId}`).addClass('active');
        
        // Atualiza URL sem recarregar
        history.pushState(null, null, `#${tabId}`);
        
        // Carrega dados da aba
        loadActiveTabData();
    }

    // =============================================
    // FATURAS
    // =============================================
    function loadInvoices() {
        const $container = $('.sgp-invoices-content');
        const $loading = $('.sgp-invoices-loading');
        const period = $('#sgp-invoice-period').val();
        
        showLoading($container, $loading);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: CUSTOMER_API.invoices,
                period: period,
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderInvoices(response.data);
                } else {
                    showError($container, response.data.message || 'Erro ao carregar faturas');
                }
            },
            error: function() {
                showError($container, 'Falha na comunicação com o servidor');
            },
            complete: function() {
                hideLoading($loading);
            }
        });
    }

    function renderInvoices(invoices) {
        const $container = $('.sgp-invoices-content');
        
        if (!invoices || invoices.length === 0) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhuma fatura encontrada</div>');
            return;
        }
        
        const html = `
            <table class="sgp-table">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Emissão</th>
                        <th>Vencimento</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoices.map(invoice => `
                        <tr>
                            <td>#${invoice.id}</td>
                            <td>${invoice.issue_date}</td>
                            <td>${invoice.due_date}</td>
                            <td>R$ ${invoice.amount.toFixed(2).replace('.', ',')}</td>
                            <td>
                                <span class="sgp-status-badge sgp-status-${invoice.status}">
                                    ${invoice.status_label}
                                </span>
                            </td>
                            <td>
                                <button class="sgp-button sgp-button-secondary sgp-view-invoice-btn" 
                                        data-invoice-id="${invoice.id}">
                                    Detalhes
                                </button>
                                ${invoice.can_pay ? `
                                    <button class="sgp-button sgp-button-primary sgp-pay-invoice-btn" 
                                            data-invoice-id="${invoice.id}">
                                        Pagar
                                    </button>
                                ` : ''}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        
        $container.html(html);
    }

    function payInvoice() {
        const invoiceId = $(this).data('invoice-id');
        const $button = $(this);
        
        if (!confirm('Deseja realmente pagar esta fatura?')) return;
        
        toggleLoading($button, true);
        
        // Simulação - na implementação real faria requisição para API de pagamento
        setTimeout(() => {
            toggleLoading($button, false);
            showAlert('Pagamento processado com sucesso!', 'success');
            loadInvoices(); // Recarrega a lista
        }, 1500);
    }

    // =============================================
    // CHAMADOS (TICKETS)
    // =============================================
    function loadTickets() {
        const $container = $('.sgp-tickets-content');
        const $loading = $('.sgp-tickets-loading');
        
        showLoading($container, $loading);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: CUSTOMER_API.tickets,
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderTickets(response.data);
                } else {
                    showError($container, response.data.message || 'Erro ao carregar chamados');
                }
            },
            error: function() {
                showError($container, 'Falha na comunicação com o servidor');
            },
            complete: function() {
                hideLoading($loading);
            }
        });
    }

    function renderTickets(tickets) {
        const $container = $('.sgp-tickets-content');
        
        if (!tickets || tickets.length === 0) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhum chamado encontrado</div>');
            return;
        }
        
        const html = `
            <table class="sgp-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Assunto</th>
                        <th>Departamento</th>
                        <th>Data</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${tickets.map(ticket => `
                        <tr>
                            <td>#${ticket.id}</td>
                            <td>${ticket.subject}</td>
                            <td>${ticket.department_label}</td>
                            <td>${ticket.created_at}</td>
                            <td>
                                <span class="sgp-status-badge sgp-status-${ticket.status}">
                                    ${ticket.status_label}
                                </span>
                            </td>
                            <td>
                                <button class="sgp-button sgp-button-secondary sgp-view-ticket-btn" 
                                        data-ticket-id="${ticket.id}">
                                    Detalhes
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        
        $container.html(html);
    }

    function showNewTicketModal() {
        $('#sgp-new-ticket-modal').show();
    }

    function submitNewTicket(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        
        toggleLoading($button, true);
        
        // FormData para lidar com upload de arquivo
        const formData = new FormData($form[0]);
        formData.append('action', 'create_ticket');
        formData.append('nonce', sgpIntegrationVars.nonce);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Chamado aberto com sucesso!', 'success');
                    $form[0].reset();
                    $('#sgp-new-ticket-modal').hide();
                    loadTickets();
                } else {
                    showAlert(response.data.message || 'Erro ao abrir chamado', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // PERFIL DO CLIENTE
    // =============================================
    function setupProfileEdit() {
        // Converte campos para modo visualização
        $('.sgp-profile-value').each(function() {
            const $field = $(this);
            const value = $field.text().trim();
            $field.html(`<input type="text" value="${value}" class="sgp-edit-input" style="display:none;">`);
        });
    }

    function enableProfileEdit() {
        $('.sgp-profile-view-mode').hide();
        $('.sgp-edit-mode').show();
        $('.sgp-edit-input').show().focus();
    }

    function cancelProfileEdit() {
        $('.sgp-edit-input').hide();
        $('.sgp-profile-view-mode').show();
        $('.sgp-edit-mode').hide();
    }

    function updateProfile(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        
        toggleLoading($button, true);
        
        const formData = {
            action: CUSTOMER_API.update_profile,
            nonce: sgpIntegrationVars.nonce
        };
        
        // Coleta dados dos campos editáveis
        $('.sgp-edit-input').each(function() {
            const name = $(this).closest('.sgp-profile-row').find('label').text().replace(':', '').trim().toLowerCase();
            formData[name] = $(this).val();
        });
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Perfil atualizado com sucesso!', 'success');
                    cancelProfileEdit();
                    // Atualiza visualização com novos dados
                    response.data.updated_fields.forEach(field => {
                        $(`.sgp-profile-row:contains("${field.label}") .sgp-profile-value`)
                            .text(field.value);
                    });
                } else {
                    showAlert(response.data.message || 'Erro ao atualizar perfil', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // ALTERAÇÃO DE PLANO
    // =============================================
    function showPlanChangeModal() {
        const $modal = $('#sgp-change-plan-modal');
        const $plansGrid = $modal.find('.sgp-plans-grid');
        
        // Carrega planos disponíveis
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_available_plans',
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderAvailablePlans(response.data, $plansGrid);
                    $modal.show();
                } else {
                    showAlert(response.data.message || 'Erro ao carregar planos', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            }
        });
    }

    function renderAvailablePlans(plans, $container) {
        if (!plans || plans.length === 0) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhum plano disponível para migração</div>');
            return;
        }
        
        const html = plans.map(plan => `
            <div class="sgp-plan-option" data-plan-id="${plan.id}">
                <label>
                    <input type="radio" name="new_plan" value="${plan.id}">
                    <div class="sgp-plan-card">
                        <h4>${plan.name}</h4>
                        <div class="sgp-plan-price">R$ ${plan.price.toFixed(2).replace('.', ',')}/mês</div>
                        <div class="sgp-plan-speed">
                            <span><i class="sgp-icon sgp-icon-download"></i> ${plan.download_speed} Mbps</span>
                            <span><i class="sgp-icon sgp-icon-upload"></i> ${plan.upload_speed} Mbps</span>
                        </div>
                    </div>
                </label>
            </div>
        `).join('');
        
        $container.html(html);
    }

    function confirmPlanChange() {
        const $button = $(this);
        const selectedPlan = $('input[name="new_plan"]:checked').val();
        const acceptedTerms = $('#sgp-accept-terms').is(':checked');
        
        if (!selectedPlan) {
            showAlert('Selecione um plano para continuar', 'error');
            return;
        }
        
        if (!acceptedTerms) {
            showAlert('Você deve aceitar os termos para alterar o plano', 'error');
            return;
        }
        
        if (!confirm('Tem certeza que deseja alterar seu plano?')) return;
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: CUSTOMER_API.change_plan,
                new_plan_id: selectedPlan,
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Solicitação de alteração enviada com sucesso!', 'success');
                    $('#sgp-change-plan-modal').hide();
                    // Atualiza exibição do plano atual
                    $('.sgp-current-plan .sgp-plan-name').text(response.data.new_plan.name);
                    $('.sgp-current-plan .sgp-plan-price').text('R$ ' + response.data.new_plan.price.toFixed(2).replace('.', ','));
                } else {
                    showAlert(response.data.message || 'Erro ao solicitar alteração', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    function showLoading($container, $loader) {
        $container.empty();
        $loader.show();
    }

    function hideLoading($loader) {
        $loader.hide();
    }

    function showError($container, message) {
        $container.html(`<div class="sgp-alert sgp-alert-error">${message}</div>`);
    }

    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        $button.find('.sgp-spinner').toggle(isLoading);
        $button.find('.sgp-button-text').text(isLoading ? 'Processando...' : $button.data('original-text'));
    }

    function showAlert(message, type) {
        const alertClass = type === 'error' ? 'sgp-alert-error' : 'sgp-alert-success';
        const $alert = $(`<div class="sgp-alert ${alertClass}">${message}</div>`);
        
        $('body').append($alert);
        setTimeout(() => $alert.fadeOut(400, () => $alert.remove()), 5000);
    }
});



/**
 * customer-login.js - Lógica para área do cliente deslogado
 */
jQuery(document).ready(function($) {
    // =============================================
    // CONSTANTES
    // =============================================
    const API_ENDPOINTS = {
        login: 'customer_login',
        password_recovery: 'customer_password_recovery',
        check_session: 'customer_check_session'
    };

    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    initLoginSection();

    function initLoginSection() {
        bindEvents();
        checkExistingSession();
    }

    // =============================================
    // EVENT BINDING
    // =============================================
    function bindEvents() {
        // Login
        $('#sgp-customer-login-form').on('submit', handleLogin);
        
        // Recuperação de senha
        $('a[href="#recover-password"]').on('click', showRecoveryModal);
        $('#sgp-recover-password-form').on('submit', handlePasswordRecovery);
        
        // Fechar modal
        $('.sgp-close-modal, .sgp-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).hide();
            }
        });
    }

    // =============================================
    // GERENCIAMENTO DE SESSÃO
    // =============================================
    function checkExistingSession() {
        const authToken = localStorage.getItem('sgp_auth_token');
        
        if (authToken) {
            $.ajax({
                url: sgpIntegrationVars.ajaxUrl,
                type: 'POST',
                data: {
                    action: API_ENDPOINTS.check_session,
                    token: authToken,
                    nonce: sgpIntegrationVars.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect_url || window.location.href;
                    } else {
                        clearSession();
                    }
                },
                error: clearSession
            });
        }
    }

    function clearSession() {
        localStorage.removeItem('sgp_auth_token');
        document.cookie = 'sgp_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    }

    // =============================================
    // LOGIN
    // =============================================
    function handleLogin(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-login-message');
        
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleLoginSuccess(response.data);
                } else {
                    handleLoginError(response.data, $message);
                }
            },
            error: function(xhr) {
                handleLoginError(xhr.responseJSON?.data || { message: 'Erro na comunicação com o servidor' }, $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function handleLoginSuccess(data) {
        // Armazena token JWT
        if (data.token) {
            localStorage.setItem('sgp_auth_token', data.token);
            
            // Cookie para fallback
            const expires = new Date();
            expires.setTime(expires.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 dias
            document.cookie = `sgp_session=${data.token}; expires=${expires.toUTCString()}; path=/`;
        }
        
        // Redireciona
        window.location.href = data.redirect_url || sgpIntegrationVars.homeUrl;
    }

    function handleLoginError(error, $container) {
        const errorMessage = error.message || 'Credenciais inválidas. Tente novamente.';
        showAlert(errorMessage, 'error', $container);
        
        // Efeito visual para campos inválidos
        if (error.fields) {
            error.fields.forEach(field => {
                $(`[name="${field}"]`).addClass('sgp-input-error')
                    .one('focus', function() {
                        $(this).removeClass('sgp-input-error');
                    });
            });
        }
    }

    // =============================================
    // RECUPERAÇÃO DE SENHA
    // =============================================
    function showRecoveryModal(e) {
        e.preventDefault();
        $('#sgp-recover-password-modal').show();
    }

    function handlePasswordRecovery(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-recover-message');
        
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleRecoverySuccess(response.data, $message, $form);
                } else {
                    handleRecoveryError(response.data, $message);
                }
            },
            error: function(xhr) {
                handleRecoveryError(xhr.responseJSON?.data || { message: 'Erro na comunicação com o servidor' }, $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function handleRecoverySuccess(data, $container, $form) {
        showAlert(data.message || 'E-mail de recuperação enviado com sucesso!', 'success', $container);
        $form[0].reset();
        
        // Fecha o modal após 3 segundos
        setTimeout(() => {
            $('#sgp-recover-password-modal').hide();
        }, 3000);
    }

    function handleRecoveryError(error, $container) {
        const errorMessage = error.message || 'Erro ao solicitar recuperação de senha.';
        showAlert(errorMessage, 'error', $container);
    }

    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        $button.find('.sgp-spinner').toggle(isLoading);
        $button.find('.sgp-button-text').text(isLoading ? 'Processando...' : $button.data('original-text'));
    }

    function showAlert(message, type, $container = null) {
        const $target = $container || $('body');
        const alertClass = type === 'error' ? 'sgp-alert-error' : 'sgp-alert-success';
        
        $target.append(`<div class="sgp-alert ${alertClass}">${message}</div>`);
        
        // Remove após 5 segundos
        setTimeout(() => {
            $(`.sgp-alert.${alertClass}`).fadeOut(400, function() {
                $(this).remove();
            });
        }, 5000);
    }
});