/**
 * customer-panel.js - Lógica específica para a área do cliente logado
 * Depende: jQuery, sgpIntegrationVars (localizado no frontend)
 */

jQuery(document).ready(function($) {
    // =============================================
    // CONSTANTES E VARIÁVEIS GLOBAIS
    // =============================================
    let eventsInitialized = false;
    let invoicesLoading = false;
    let ticketsLoading = false;
    let overviewLoading = false;
    let recentInvoicesLoading = false;
    let recentTicketsLoading = false;
    let connectionStatusLoading = false;

    const CUSTOMER_API = {
        invoices: 'get_customer_invoices',
        tickets: 'get_customer_tickets',
        update_profile: 'update_customer_profile',
        change_plan: 'request_plan_change'
    };

    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    initCustomerPanel();

    function initCustomerPanel() {
        // Event Listeners primeiro (para evitar duplicação)
        bindEvents();
        
        // Verifica se há hash na URL (para abas diretas)
        checkUrlHash();
        
        // Inicializa o módulo de verificação de sessão
        if (typeof window.sgpSessionCheck !== 'undefined') {
            window.sgpSessionCheck.init();
        }
        
        // Não carregar dados iniciais automaticamente
        // O carregamento será feito sob demanda ao clicar nas abas
        // Se a aba ativa for "Faturas", carrega as faturas imediatamente
        if ($('.sgp-nav-item.active').data('tab') === 'invoices') {
            loadInvoices();
        }

        // Seleciona automaticamente o contrato padrão se nenhum estiver selecionado
        // Aguarda um pouco para garantir que o HTML foi totalmente renderizado
        setTimeout(function() {
            const $selector = $('#sgp-contract-selector');
            if ($selector.length && !$selector.val()) {
                const defaultContract = $('.sgp-customer-dashboard').data('default-contract');
                if (defaultContract) {
                    $selector.val(defaultContract).trigger('change');
                }
            }
        }, 500);
    }

    // =============================================
    // CONTROLE DE ABAS
    // =============================================
    function loadActiveTabData() {
        const activeTab = $('.sgp-nav-item.active').data('tab');
        
        switch(activeTab) {
            case 'overview':
                loadOverviewData();
                break;
            case 'invoices':
                loadInvoices();
                break;
            case 'tickets':
                loadTickets();
                break;
            case 'profile':
                setupProfileEdit();
                break;
            case 'contracts':
                loadContracts();
                break;
            case 'access':
                loadConnectionStatus();
                break;
        }
    }

    function checkUrlHash() {
        if (window.location.hash) {
            const tabId = window.location.hash.substring(1);
            const $tab = $(`.sgp-nav-item[data-tab="${tabId}"]`);
            
            if ($tab.length) {
                $('.sgp-nav-item').removeClass('active');
                $tab.addClass('active');
                
                $('.sgp-tab-pane').removeClass('active');
                $(`#${tabId}`).addClass('active');
                
                loadActiveTabData();
            }
        }
    }

    // =============================================
    // EVENT BINDING
    // =============================================
    function bindEvents() {
        // Evita bind duplo de eventos
        if (eventsInitialized) {
            return;
        }
        
        eventsInitialized = true;
        
        // Navegação entre abas
        $('.sgp-nav-item').on('click', function(e) {
            e.preventDefault();
            switchTab($(this));
        });

        // Logout
        $(document).on('click', '#sgp-logout-btn', handleLogout);

        // Faturas
        $(document).on('change', '#sgp-invoice-period', loadInvoices);
        $(document).on('click', '.sgp-generate-pix-btn', generatePix);
        $(document).on('click', '.sgp-second-copy-btn', getSecondCopy);

        // Chamados
        $(document).on('click', '.sgp-new-ticket-btn', function(e) {
            e.preventDefault();
            showCreateTicketPopup();
        });
        $(document).on('click', '#sgp-refresh-tickets', loadTickets);
        $(document).on('submit', '#sgp-new-ticket-form', submitNewTicket);
        $(document).on('click', '.sgp-view-ticket-btn', showTicketDetails);

        // Perfil
        $(document).on('click', '.sgp-edit-profile-btn', enableProfileEdit);
        $(document).on('click', '.sgp-cancel-edit-btn', cancelProfileEdit);
        $(document).on('submit', '#sgp-profile-form', updateProfile);

        // Planos
        $(document).on('click', '.sgp-change-plan-btn', showPlanChangeModal);
        $(document).on('click', '#sgp-confirm-plan-change', confirmPlanChange);

        // Ações rápidas da visão geral
        $(document).on('click', '#sgp-quick-second-copy', quickSecondCopy);
        $(document).on('click', '#sgp-quick-generate-pix', quickGeneratePix);
        $(document).on('click', '#sgp-quick-verify-access', quickVerifyAccess);

        // Modais
        $(document).on('click', '.sgp-close-modal', closeModal);
        $(document).on('click', '.sgp-modal', function(e) {
            if (e.target === this) {
                closeModal.call(this);
            }
        });



        // Nota: O seletor de contratos foi removido - contratos são carregados automaticamente

        // Contratos já são carregados pelo loadActiveTabData() no switchTab()
        // Removido para evitar chamadas duplicadas
    }

    function switchTab($tab) {
        const tabId = $tab.data('tab');
        
        // Atualiza UI
        $('.sgp-nav-item').removeClass('active');
        $tab.addClass('active');
        
        $('.sgp-tab-pane').removeClass('active');
        $(`#${tabId}`).addClass('active');
        
        // Atualiza URL sem recarregar
        history.pushState(null, null, `#${tabId}`);
        
        // Carrega dados da aba
        loadActiveTabData();
    }

    // =============================================
    // LOGOUT
    // =============================================
    function handleLogout(e) {
        e.preventDefault();
        
        const $button = $(this);
        
        if (!confirm('Tem certeza que deseja sair da área do cliente?')) {
            return;
        }
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'customer_logout',
                nonce: sgpCustomerVars.logoutNonce // Usa o nonce específico para logout
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert(sgpCustomerVars.i18n.logoutSuccess, 'success');
                    
                    // Limpa dados locais
                    clearLocalData();
                    
                    // Previne volta pelo navegador usando replace
                    setTimeout(() => {
                        window.location.replace(response.data.redirect_url || window.location.origin);
                    }, 1000);
                } else {
                    showAlert(response.data.message || 'Erro ao fazer logout', 'error');
                    toggleLoading($button, false);
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // VERIFICAÇÃO DE SESSÃO - MOVIDA PARA session-check.js
    // =============================================
    // Todas as funções de verificação de sessão foram movidas para o módulo session-check.js
    // que responde à flag sgpCustomerVars.enableSessionCheck

    // =============================================
    // VISÃO GERAL
    // =============================================
    function loadOverviewData() {
        // Evita carregamentos simultâneos
        if (overviewLoading) {
            return;
        }
        
        overviewLoading = true;
        
        // Carrega status da conexão
        loadConnectionStatus();
        
        // Carrega últimas faturas
        loadRecentInvoices();
        
        // Carrega chamados recentes
        loadRecentTickets();
        
        // Libera flag após um tempo
        setTimeout(() => {
            overviewLoading = false;
        }, 2000);
    }

    function loadConnectionStatus() {
        // Evita carregamentos simultâneos
        if (connectionStatusLoading) {
            return;
        }
        
        const $container = $('#sgp-connection-info');
        
        // Pega o primeiro contrato disponível
        const defaultContract = $('.sgp-customer-dashboard').data('default-contract');
        const currentContract = defaultContract;
        
        if (!currentContract) {
            $container.html('<p class="sgp-error">Contrato não encontrado</p>');
            return;
        }
        
        connectionStatusLoading = true;
        $container.html('<div class="sgp-loading">Verificando conexão...</div>');
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'verify_customer_access',
                contrato: currentContract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $container.html(`
                        <div class="sgp-status-ok">
                            <strong>Status do Acesso:</strong>
                            <span class="sgp-status-badge sgp-status-active">Conexão Ativa</span>
                        </div>
                    `);
                } else {
                    $container.html(`
                        <div class="sgp-status-error">
                            <strong>Status do Acesso:</strong>
                            <span class="sgp-status-badge sgp-status-error">Erro na Verificação</span>
                            <br>
                            <small>${response.data.message || 'Erro desconhecido'}</small>
                        </div>
                    `);
                }
            },
            error: function() {
                $container.html(`
                    <div class="sgp-status-error">
                        <strong>Status do Acesso:</strong>
                        <span class="sgp-status-badge sgp-status-error">Erro de Comunicação</span>
                        <br>
                        <small>Falha na comunicação com o servidor</small>
                    </div>
                `);
            },
            complete: function() {
                connectionStatusLoading = false;
            }
        });
    }

    function loadRecentInvoices() {
        // Evita carregamentos simultâneos
        if (recentInvoicesLoading) {
            return;
        }
        
        const $container = $('#sgp-recent-invoices-list');
        const defaultContract = $('.sgp-customer-dashboard').data('default-contract');
        
        if (!defaultContract) {
            $container.html('<p class="sgp-error">Contrato não encontrado</p>');
            return;
        }
        
        recentInvoicesLoading = true;
        $container.html('<div class="sgp-loading">Carregando faturas...</div>');
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_customer_invoices',
                contrato: defaultContract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    const recentInvoices = response.data.slice(0, 3); // Últimas 3 faturas
                    let html = '<div class="sgp-recent-list">';
                    
                    recentInvoices.forEach(invoice => {
                        const numero = invoice.fatura || invoice.id || 'N/A';
                        const vencimento = invoice.vencimento || 'N/A';
                        const valor = invoice.valor || 0;
                        const valorFormatado = typeof valor === 'number' ? 
                            valor.toFixed(2).replace('.', ',') : 
                            valor.toString().replace('.', ',');
                        
                        html += `
                            <div class="sgp-recent-item">
                                <strong>#${numero}</strong> - R$ ${valorFormatado}
                                <br><small>Venc: ${vencimento}</small>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    $container.html(html);
                } else {
                    $container.html('<p class="sgp-help-text">Nenhuma fatura encontrada</p>');
                }
            },
            error: function() {
                $container.html('<p class="sgp-error">Erro ao carregar faturas</p>');
            },
            complete: function() {
                recentInvoicesLoading = false;
            }
        });
    }

    function loadRecentTickets() {
        // Evita carregamentos simultâneos
        if (recentTicketsLoading) {
            return;
        }
        
        const $container = $('#sgp-recent-tickets-list');
        const defaultContract = $('.sgp-customer-dashboard').data('default-contract');
        
        if (!defaultContract) {
            $container.html('<p class="sgp-error">Contrato não encontrado</p>');
            return;
        }
        
        recentTicketsLoading = true;
        $container.html('<div class="sgp-loading">Carregando chamados...</div>');
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_customer_tickets',
                contrato: defaultContract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    const recentTickets = response.data.slice(0, 3); // Últimos 3 chamados
                    let html = '<div class="sgp-recent-list">';
                    
                    recentTickets.forEach(ticket => {
                        const id = ticket.id || ticket.numero || 'N/A';
                        const assunto = ticket.assunto || ticket.subject || 'Sem assunto';
                        const status = ticket.status || 'unknown';
                        const statusLabel = ticket.status_label || 'Aberto';
                        
                        html += `
                            <div class="sgp-recent-item">
                                <strong>#${id}</strong> - ${assunto}
                                <br><small>Status: ${statusLabel}</small>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    $container.html(html);
                } else {
                    $container.html('<p class="sgp-help-text">Nenhum chamado encontrado</p>');
                }
            },
            error: function() {
                $container.html('<p class="sgp-error">Erro ao carregar chamados</p>');
            },
            complete: function() {
                recentTicketsLoading = false;
            }
        });
    }

    // =============================================
    // AÇÕES RÁPIDAS
    // =============================================
    function quickSecondCopy() {
        const contract = $('.sgp-customer-dashboard').data('default-contract');
        const $button = $(this);
        
        if (!contract) {
            showAlert('Contrato não encontrado', 'error');
            return;
        }
        
        if (!confirm('Deseja solicitar a 2ª via da última fatura?')) return;
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_second_copy',
                contrato: contract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('2ª via enviada com sucesso!', 'success');
                    if (response.data.url) {
                        window.open(response.data.url, '_blank');
                    }
                } else {
                    showAlert(response.data.message || 'Erro ao solicitar 2ª via', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function quickGeneratePix() {
        const contract = $('.sgp-customer-dashboard').data('default-contract');
        const $button = $(this);
        
        if (!contract) {
            showAlert('Contrato não encontrado', 'error');
            return;
        }
        
        showAlert('Selecione uma fatura específica na aba "Faturas" para gerar PIX', 'info');
        
        // Redireciona para a aba de faturas
        $('.sgp-nav-item[data-tab="invoices"]').trigger('click');
    }

    function quickVerifyAccess() {
        const contract = $('.sgp-customer-dashboard').data('default-contract');
        const $button = $(this);
        
        if (!contract) {
            showAlert('Contrato não encontrado', 'error');
            return;
        }
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'verify_customer_access',
                contrato: contract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Acesso verificado com sucesso!', 'success');
                    // Atualiza o status na visão geral
                    loadConnectionStatus();
                } else {
                    showAlert(response.data.message || 'Erro na verificação de acesso', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // MODAIS
    // =============================================
    function closeModal() {
        $(this).closest('.sgp-modal').hide();
    }

    // =============================================
    // FATURAS - VERSÃO MELHORADA
    // =============================================
    function loadInvoices() {
        // Evita carregamentos simultâneos
        if (invoicesLoading) {
            return;
        }
        
        invoicesLoading = true;
        const $container = $('.sgp-invoices-content');
        const $loading = $('.sgp-invoices-loading');
        const period = $('#sgp-invoice-period').val() || 'all';
        
        // Obtém um contrato válido usando a função auxiliar
        const currentContract = getValidContract();
        
        // Validação básica do contrato
        if (!currentContract || currentContract === "") {
            showError($container, 'Contrato não encontrado. Verifique se há contratos disponíveis.');
            invoicesLoading = false;
            return;
        }
        
        // Exibe loading com ícone de looping
        $container.hide();
        $loading.show();
        
        // Prepara dados para requisição
        const requestData = {
            action: 'get_customer_invoices',
            period: period,
            contrato: currentContract,
            nonce: sgpCustomerVars.nonce
        };
        
        // Debug básico (sem logs excessivos)
        if (window.SGP_DEBUG) {
            console.log('[SGP_FATURAS] Carregando faturas para contrato:', currentContract);
        }

        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: requestData,
            dataType: 'json',
            timeout: 30000,
            success: function(response) {
                // =============================================
                // DEBUG TEMPORÁRIO - FRONTEND
                // =============================================
                // REMOVER APÓS OS TESTES:
                // window.SGP_Faturas_Debug.debugSuccess(response, requestData);
                
                if (response.success) {
                    if (!response.data) {
                        showError($container, 'Nenhum dado de fatura retornado pela API.');
                        return;
                    }
                    renderInvoices(response.data, currentContract);
                } else {
                    const errorMessage = (response.data && response.data.message) || 'Erro ao carregar faturas';
                    showError($container, errorMessage);
                }
            },
            error: function(xhr, status, error) {
                // =============================================
                // DEBUG TEMPORÁRIO - ERRO AJAX
                // =============================================
                // REMOVER APÓS OS TESTES:
                // window.SGP_Faturas_Debug.debugError(xhr, status, error, requestData);
                
                let errorMessage = 'Falha na comunicação com o servidor';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (status === 'timeout') {
                    errorMessage = 'Timeout na conexão com o servidor';
                } else if (status === 'parsererror') {
                    errorMessage = 'Erro no formato da resposta do servidor';
                }
                
                showError($container, errorMessage);
                
                if (window.SGP_DEBUG) {
                    console.error('[SGP_FATURAS] Erro na requisição:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText
                    });
                }
            },
            complete: function() {
                $loading.hide();
                $container.show();
                invoicesLoading = false;
            }
        });
    }

    function renderInvoices(response, contractId) {
        const $container = $('.sgp-invoices-content');
        
        // Verifica se é a nova estrutura de resposta com status do contrato
        let invoices = response;
        let contractStatus = null;
        let statusMessage = null;
        let isInactive = false;
        
        // Processa estrutura de resposta
        if (response && typeof response === 'object') {
            if (response.faturas) {
                invoices = response.faturas;
                contractStatus = response.contract_status;
                statusMessage = response.status_message;
                isInactive = response.is_inactive;
            }
        }
        
        // Normaliza invoices como array
        if (!Array.isArray(invoices)) {
            if (invoices && typeof invoices === 'object') {
                invoices = Object.values(invoices);
            } else {
                invoices = [];
            }
        }
        
        // Valida se existem faturas
        if (!invoices || invoices.length === 0) {
            renderNoInvoicesMessage($container, contractId, isInactive, statusMessage);
            return;
        }
        
        // Renderiza tabela de faturas
        renderInvoicesTable($container, invoices, contractStatus, statusMessage, isInactive);
    }
    
    function renderNoInvoicesMessage($container, contractId, isInactive, statusMessage) {
        const selectedContractId = getValidContract();
        const contractInfo = (window.sgpCustomerContracts || []).find(c => c.contrato == selectedContractId);
        const noInvoicesMessage = `
            <div class="sgp-alert sgp-alert-info">
                <h4>📄 Nenhuma fatura encontrada</h4>
                <p><strong>Contrato:</strong> ${contractInfo ? contractInfo.contrato : contractId}</p>
                <p><strong>Razão Social:</strong> ${contractInfo ? contractInfo.razaosocial : 'N/A'}</p>
                <p><strong>Status:</strong> ${contractInfo ? contractInfo.status : 'N/A'}</p>
                <div class="sgp-help-reasons">
                    <p>Possíveis motivos:</p>
                    <ul>
                        <li>O contrato está cancelado ou inativo</li>
                        <li>Ainda não há faturas geradas</li>
                        <li>As faturas estão em outro período</li>
                        <li>Problema temporário de comunicação com a API</li>
                    </ul>
                </div>
                <div class="sgp-help-actions">
                    <button class="sgp-button sgp-button-primary" onclick="loadInvoices()">
                        🔄 Tentar novamente
                    </button>
                    <p><small>Tente selecionar outro contrato ou entre em contato com o suporte.</small></p>
                </div>
            </div>
        `;
        $container.html(noInvoicesMessage);
    }
    
    function renderInvoicesTable($container, invoices, contractStatus, statusMessage, isInactive) {
        const tableHtml = `
            <table class="sgp-table sgp-invoices-table">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Emissão</th>
                        <th>Vencimento</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoices.map(invoice => renderInvoiceRow(invoice)).join('')}
                </tbody>
            </table>
        `;
        
        // Adiciona aviso de contrato inativo se necessário
        let finalHtml = '';
        if (isInactive && statusMessage) {
            finalHtml += `
                <div class="sgp-alert sgp-alert-warning" style="margin-bottom: 20px;">
                    <h4>⚠️ Contrato ${contractStatus}</h4>
                    <p><strong>Status:</strong> ${statusMessage}</p>
                </div>
            `;
        } else if (contractStatus && contractStatus !== 'ATIVO') {
            finalHtml += `
                <div class="sgp-alert sgp-alert-warning" style="margin-bottom: 20px;">
                    <h4>⚠️ Contrato Cancelado</h4>
                    <p>Este contrato não está ativo. As informações são apenas para consulta histórica.</p>
                </div>
            `;
        }
        
        finalHtml += tableHtml;
        $container.html(finalHtml);
    }
    
    function renderInvoiceRow(invoice) {
        // Normaliza campos da fatura para diferentes formatos de API
        const numero = invoice.fatura || invoice.numero_documento || invoice.id || invoice.numero || 'N/A';
        const emissao = invoice.emissao || invoice.data_emissao || invoice.issue_date || 'N/A';
        const vencimento = invoice.vencimento || invoice.vencimento_atualizado || invoice.due_date || 'N/A';
        const valor = invoice.valor || invoice.valorcorrigido || invoice.amount || 0;
        
        // Normaliza status
        let status = (invoice.status || '').toUpperCase();
        let statusLabel = status;
        let statusClass = status.toLowerCase().replace(/\s+/g, '-');
        
        // Tradução e padronização de status
        switch (status) {
            case 'PAGO':
                statusLabel = 'Pago';
                break;
            case 'EM ABERTO':
            case 'GERADO':
                statusLabel = 'Em Aberto';
                statusClass = 'em-aberto';
                break;
            case 'VENCIDO':
                statusLabel = 'Vencido';
                break;
            default:
                statusLabel = status ? status.charAt(0) + status.slice(1).toLowerCase() : 'N/A';
        }
        
        // Formatação do valor
        const valorFormatado = formatCurrency(valor);
        
        // Ações disponíveis
        const actions = renderInvoiceActions(invoice, numero);
        
        return `
            <tr class="sgp-invoice-row" data-invoice-id="${numero}">
                <td class="sgp-invoice-number">#${numero}</td>
                <td class="sgp-invoice-issue">${emissao}</td>
                <td class="sgp-invoice-due">${vencimento}</td>
                <td class="sgp-invoice-amount">R$ ${valorFormatado}</td>
                <td class="sgp-invoice-status">
                    <span class="sgp-status-badge sgp-status-${statusClass}">
                        ${statusLabel}
                    </span>
                </td>
                <td class="sgp-invoice-actions">
                    ${actions}
                </td>
            </tr>
        `;
    }
    
    function renderInvoiceActions(invoice, numero) {
        const currentContract = getValidContract();
        let actions = '';
        
        // Botão PIX
        actions += `
            <button class="sgp-button sgp-button-primary sgp-generate-pix-btn" 
                    data-invoice-id="${numero}" 
                    data-contract="${currentContract}"
                    title="Gerar código PIX para pagamento">
                💳 PIX
            </button>
        `;
        
        // Botão 2ª Via
        actions += `
            <button class="sgp-button sgp-button-secondary sgp-second-copy-btn" 
                    data-invoice-id="${numero}" 
                    data-contract="${currentContract}"
                    title="Solicitar segunda via da fatura">
                📄 2ª Via
            </button>
        `;
        
        // Botão Boleto (se disponível)
        if (invoice.link) {
            actions += `
                <a href="${invoice.link}" target="_blank" 
                   class="sgp-button sgp-button-tertiary"
                   title="Abrir boleto em nova aba">
                    📋 Boleto
                </a>
            `;
        }
        
        return actions;
    }
    
    // Função auxiliar para formatação de moeda
    function formatCurrency(value) {
        if (!value || value === 0) return '0,00';
        
        const numericValue = typeof value === 'number' ? value : parseFloat(value);
        
        if (isNaN(numericValue)) return '0,00';
        
        return numericValue.toFixed(2).replace('.', ',');
    }

    function generatePix() {
        const invoiceId = $(this).data('invoice-id');
        const contract = $(this).data('contract') || $('.sgp-customer-dashboard').data('default-contract');
        const $button = $(this);
        
        if (!confirm('Deseja gerar código PIX para esta fatura?')) return;
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'generate_invoice_pix',
                fatura_id: invoiceId,
                contrato: contract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Código PIX gerado com sucesso!', 'success');
                    // Aqui você pode mostrar o código PIX em um modal
                    showPixModal(response.data);
                } else {
                    showAlert(response.data.message || 'Erro ao gerar PIX', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function getSecondCopy() {
        const invoiceId = $(this).data('invoice-id');
        const contract = $(this).data('contract') || $('.sgp-customer-dashboard').data('default-contract');
        const $button = $(this);
        
        if (!confirm('Deseja solicitar a 2ª via desta fatura?')) return;
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_second_copy',
                fatura_id: invoiceId,
                contrato: contract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('2ª via enviada com sucesso!', 'success');
                    // Se houver URL para download, pode abrir em nova aba
                    if (response.data.url) {
                        window.open(response.data.url, '_blank');
                    }
                } else {
                    showAlert(response.data.message || 'Erro ao solicitar 2ª via', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function showPixModal(pixData) {
        // Implementar modal para exibir código PIX
        const modal = $(`
            <div class="sgp-modal sgp-pix-modal" style="display: flex;">
                <div class="sgp-modal-content">
                    <span class="sgp-close-modal">&times;</span>
                    <h3>Código PIX Gerado</h3>
                    <div class="sgp-pix-content">
                        <p><strong>Valor:</strong> R$ ${pixData.valor || 'N/A'}</p>
                        <p><strong>Código PIX:</strong></p>
                        <textarea readonly class="sgp-pix-code">${pixData.codigo_pix || 'N/A'}</textarea>
                        <button class="sgp-button sgp-button-primary sgp-copy-pix-btn">
                            Copiar Código PIX
                        </button>
                    </div>
                </div>
            </div>
        `);
        
        $('body').append(modal);
        
        // Função para copiar código PIX
        modal.find('.sgp-copy-pix-btn').on('click', function() {
            const pixCode = modal.find('.sgp-pix-code')[0];
            pixCode.select();
            document.execCommand('copy');
            showAlert('Código PIX copiado!', 'success');
        });
    }

    // =============================================
    // CHAMADOS (TICKETS)
    // =============================================
    function loadTickets() {
        // Evita carregamentos simultâneos
        if (ticketsLoading) {
            return;
        }
        
        ticketsLoading = true;
        const $container = $('.sgp-tickets-content');
        const $loading = $('.sgp-tickets-loading');
        
        // Mostra loading e esconde conteúdo
        $container.hide();
        $loading.show();
        
        // Obtém um contrato válido usando a função auxiliar
        const currentContract = getValidContract();
        
        if (!currentContract || currentContract === "") {
            showError($container, 'Contrato não encontrado. Selecione um contrato válido.');
            $loading.hide();
            $container.show();
            ticketsLoading = false;
            return;
        }
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: CUSTOMER_API.tickets,
                contrato: currentContract,
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    var tickets = response.data.chamados || [];
                    renderTickets(tickets);
                } else {
                    showError($container, response.data.message || 'Erro ao carregar chamados');
                }
            },
            error: function(xhr) {
                showError($container, 'Falha na comunicação com o servidor', xhr.responseJSON);
            },
            complete: function() {
                $loading.hide();
                $container.show();
                ticketsLoading = false;
            }
        });
    }

    function renderTickets(tickets) {
        // Garante que tickets é sempre um array
        if (tickets && tickets.chamados) {
            tickets = tickets.chamados;
        }
        if (tickets && tickets.ocorrencias) {
            tickets = tickets.ocorrencias;
        }
        if (!Array.isArray(tickets)) {
            tickets = [];
        }
        console.log('Tickets para renderização:', tickets); // DEBUG
        if (!Array.isArray(tickets)) tickets = [];

        const $container = $('.sgp-tickets-content');
        if (!tickets.length) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhuma ocorrência encontrada</div>');
            return;
        }

        const html = `
            <table class="sgp-table">
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Status</th>
                        <th>Status Contrato</th>
                        <th>Data Cadastro</th>
                        <th>Tipo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${tickets.map((ticket, idx) => `
                        <tr>
                            <td>${ticket.numero ?? ''}</td>
                            <td>${ticket.status ?? ''}</td>
                            <td>${ticket.contrato_status ?? ''}</td>
                            <td>${ticket.data_cadastro ?? ''}</td>
                            <td>${ticket.tipo ?? ''}</td>
                            <td>
                                <button class="sgp-button sgp-button-primary sgp-view-ticket-btn" 
                                        data-ticket-idx="${idx}" 
                                        title="Ver detalhes do chamado">
                                    🛈 Detalhes
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        $container.html(html);
        window.sgpRawTickets = tickets;
    }

    function showNewTicketModal() {
        $('#sgp-new-ticket-modal').show();
    }

    function submitNewTicket(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        
        toggleLoading($button, true);
        
        // FormData para lidar com upload de arquivo
        const formData = new FormData($form[0]);
        formData.append('action', 'create_ticket');
        formData.append('nonce', sgpIntegrationVars.nonce);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Chamado aberto com sucesso!', 'success');
                    $form[0].reset();
                    $('#sgp-new-ticket-modal').hide();
                    loadTickets();
                } else {
                    showAlert(response.data.message || 'Erro ao abrir chamado', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function showTicketDetails() {
        const idx = $(this).data('ticket-idx');
        const ticket = window.sgpRawTickets ? window.sgpRawTickets[idx] : null;
        
        if (!ticket) {
            showAlert('Dados da ocorrência não encontrados.', 'error');
            return;
        }

        // Layout bonito: cards, ícones, destaque para status, datas e tipo
        let details = `
            <div class="sgp-popup-header">
                <span class="sgp-popup-title">Detalhes da Ocorrência</span>
                <span class="sgp-close-popup" title="Fechar">&times;</span>
            </div>
            <div class="sgp-popup-body">
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Número:</div>
                    <div class="sgp-popup-value">${ticket.numero ?? ''}</div>
                </div>
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Status:</div>
                    <div class="sgp-popup-value"><span class="sgp-status-badge sgp-status-${(ticket.status || '').toLowerCase()}">${ticket.status ?? ''}</span></div>
                </div>
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Status Contrato:</div>
                    <div class="sgp-popup-value">${ticket.contrato_status ?? ''}</div>
                </div>
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Data Cadastro:</div>
                    <div class="sgp-popup-value">${ticket.data_cadastro ?? ''}</div>
                </div>
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Tipo:</div>
                    <div class="sgp-popup-value">${ticket.tipo ?? ''}</div>
                </div>
                <div class="sgp-popup-row">
                    <div class="sgp-popup-label">Descrição:</div>
                    <div class="sgp-popup-value">${ticket.descricao ?? '-'}</div>
                </div>
                <!-- Adicione mais campos relevantes aqui -->
            </div>
        `;

        // Popup estilizado
        const $popup = $(`
            <div class="sgp-popup-overlay" style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.45);z-index:99999;display:flex;align-items:center;justify-content:center;animation:sgpFadeIn 0.2s;">
                <div class="sgp-popup-card" style="background:#fff;padding:32px 28px;max-width:420px;width:95vw;border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,0.18);max-height:85vh;overflow:auto;position:relative;">
                    ${details}
                </div>
            </div>
        `);

        // Adiciona CSS do popup apenas uma vez
        if (!document.getElementById('sgp-popup-style')) {
            const style = `<style id="sgp-popup-style">
                @keyframes sgpFadeIn { from { opacity: 0; } to { opacity: 1; } }
                .sgp-popup-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 18px; }
                .sgp-popup-title { font-size: 1.25rem; font-weight: 700; color: #1a1a1a; }
                .sgp-close-popup { cursor: pointer; font-size: 1.7rem; color: #888; transition: color 0.2s; }
                .sgp-close-popup:hover { color: #e74c3c; }
                .sgp-popup-body { display: flex; flex-direction: column; gap: 12px; }
                .sgp-popup-row { display: flex; align-items: flex-start; margin-bottom: 2px; }
                .sgp-popup-label { min-width: 120px; font-weight: 600; color: #555; }
                .sgp-popup-value { flex: 1; color: #222; word-break: break-word; }
                .sgp-status-badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.95em; font-weight: 600; background: #f0f0f0; color: #333; }
                .sgp-status-aberto { background: #eaf7e6; color: #27ae60; }
                .sgp-status-fechado { background: #fbeee6; color: #e67e22; }
                .sgp-status-andamento { background: #e6f0fb; color: #2980b9; }
                .sgp-status-cancelado { background: #fbeaea; color: #c0392b; }
                @media (max-width: 600px) {
                  .sgp-popup-card { padding: 18px 6vw; }
                  .sgp-popup-label { min-width: 80px; font-size: 0.98em; }
                }
            </style>`;
            $('head').append(style);
        }

        // Remove popup ao clicar fora ou no X
        $popup.on('click', function(e) {
            if (e.target === this) $popup.remove();
        });
        $popup.find('.sgp-close-popup').on('click', function() {
            $popup.remove();
        });

        $('body').append($popup);
    }

    // =============================================
    // PERFIL DO CLIENTE
    // =============================================
    function setupProfileEdit() {
        // Converte campos para modo visualização
        $('.sgp-profile-value').each(function() {
            const $field = $(this);
            const value = $field.text().trim();
            $field.html(`<input type="text" value="${value}" class="sgp-edit-input" style="display:none;">`);
        });
    }

    function enableProfileEdit() {
        $('.sgp-profile-view-mode').hide();
        $('.sgp-edit-mode').show();
        $('.sgp-edit-input').show().focus();
    }

    function cancelProfileEdit() {
        $('.sgp-edit-input').hide();
        $('.sgp-profile-view-mode').show();
        $('.sgp-edit-mode').hide();
    }

    function updateProfile(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        
        toggleLoading($button, true);
        
        const formData = {
            action: CUSTOMER_API.update_profile,
            nonce: sgpIntegrationVars.nonce
        };
        
        // Coleta dados dos campos editáveis
        $('.sgp-edit-input').each(function() {
            const name = $(this).closest('.sgp-profile-row').find('label').text().replace(':', '').trim().toLowerCase();
            formData[name] = $(this).val();
        });
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Perfil atualizado com sucesso!', 'success');
                    cancelProfileEdit();
                    // Atualiza visualização com novos dados
                    response.data.updated_fields.forEach(field => {
                        $(`.sgp-profile-row:contains("${field.label}") .sgp-profile-value`)
                            .text(field.value);
                    });
                } else {
                    showAlert(response.data.message || 'Erro ao atualizar perfil', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // ALTERAÇÃO DE PLANO
    // =============================================
    function showPlanChangeModal() {
        const $modal = $('#sgp-change-plan-modal');
        const $plansGrid = $modal.find('.sgp-plans-grid');
        
        // Carrega planos disponíveis
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_available_plans',
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderAvailablePlans(response.data, $plansGrid);
                    $modal.show();
                } else {
                    showAlert(response.data.message || 'Erro ao carregar planos', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            }
        });
    }

    function renderAvailablePlans(plans, $container) {
        if (!plans || plans.length === 0) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhum plano disponível para migração</div>');
            return;
        }
        
        const html = plans.map(plan => `
            <div class="sgp-plan-option" data-plan-id="${plan.id}">
                <label>
                    <input type="radio" name="new_plan" value="${plan.id}">
                    <div class="sgp-plan-card">
                        <h4>${plan.name}</h4>
                        <div class="sgp-plan-price">R$ ${plan.price.toFixed(2).replace('.', ',')}/mês</div>
                        <div class="sgp-plan-speed">
                            <span><i class="sgp-icon sgp-icon-download"></i> ${plan.download_speed} Mbps</span>
                            <span><i class="sgp-icon sgp-icon-upload"></i> ${plan.upload_speed} Mbps</span>
                        </div>
                    </div>
                </label>
            </div>
        `).join('');
        
        $container.html(html);
    }

    function confirmPlanChange() {
        const $button = $(this);
        const selectedPlan = $('input[name="new_plan"]:checked').val();
        const acceptedTerms = $('#sgp-accept-terms').is(':checked');
        
        if (!selectedPlan) {
            showAlert('Selecione um plano para continuar', 'error');
            return;
        }
        
        if (!acceptedTerms) {
            showAlert('Você deve aceitar os termos para alterar o plano', 'error');
            return;
        }
        
        if (!confirm('Tem certeza que deseja alterar seu plano?')) return;
        
        toggleLoading($button, true);
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: {
                action: CUSTOMER_API.change_plan,
                new_plan_id: selectedPlan,
                nonce: sgpIntegrationVars.nonce
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('Solicitação de alteração enviada com sucesso!', 'success');
                    $('#sgp-change-plan-modal').hide();
                    // Atualiza exibição do plano atual
                    $('.sgp-current-plan .sgp-plan-name').text(response.data.new_plan.name);
                    $('.sgp-current-plan .sgp-plan-price').text('R$ ' + response.data.new_plan.price.toFixed(2).replace('.', ','));
                } else {
                    showAlert(response.data.message || 'Erro ao solicitar alteração', 'error');
                }
            },
            error: function() {
                showAlert('Falha na comunicação com o servidor', 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    
    // Função para garantir que sempre tenhamos um contrato válido
    function getValidContract() {
        let currentContract = null;
        
        // 1. Tenta pegar do dropdown selecionado
        const selectedContract = $('#sgp-contract-selector').val();
        if (selectedContract && selectedContract !== '') {
            currentContract = selectedContract;
        }
        
        // 2. Se não tem no dropdown, tenta o contrato padrão do data-attribute
        if (!currentContract) {
            const defaultContract = $('.sgp-customer-dashboard').data('default-contract');
            if (defaultContract && defaultContract !== '') {
                currentContract = defaultContract;
                // Força seleção no dropdown
                $('#sgp-contract-selector').val(defaultContract);
            }
        }
        
        // 3. Se ainda não tem, tenta pegar da primeira opção disponível no dropdown
        if (!currentContract) {
            const firstOption = $('#sgp-contract-selector option[value!=""]:first').val();
            if (firstOption && firstOption !== '') {
                currentContract = firstOption;
                // Força seleção no dropdown
                $('#sgp-contract-selector').val(firstOption);
            }
        }
        
        return currentContract;
    }

    function showLoading($container, $loader) {
        $container.empty().append($loader);
        $loader.show();
    }

    function hideLoading($loader) {
        $loader.hide();
    }

    function showError($container, message, response = null) {
        // Erro padrão
        $container.html(`<div class="sgp-alert sgp-alert-error">${message}</div>`);
    }

    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        $button.find('.sgp-spinner').toggle(isLoading);
        $button.find('.sgp-button-text').text(isLoading ? 'Processando...' : $button.data('original-text'));
    }

    function showAlert(message, type) {
        let alertClass = 'sgp-alert-success';
        if (type === 'error') {
            alertClass = 'sgp-alert-error';
        } else if (type === 'info') {
            alertClass = 'sgp-alert-info';
        }
        
        const $alert = $(`<div class="sgp-alert ${alertClass}" style="position: fixed; top: 20px; right: 20px; z-index: 99999; max-width: 400px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">${message}</div>`);
        
        $('body').append($alert);
        setTimeout(() => $alert.fadeOut(400, () => $alert.remove()), 5000);
    }

    // =============================
    // CONTRATOS - NOVA LÓGICA
    // =============================
    function loadContracts() {
        // Evita múltiplas chamadas simultâneas
        if (window.contractsLoading) {
            return;
        }
        
        window.contractsLoading = true;
        const $container = $('#sgp-contracts-list');
        const $loadingDiv = $('.sgp-contracts-loading');
        
        // Mostra loading usando o div dedicado
        $container.hide();
        $loadingDiv.show();
        
        $.ajax({
            url: sgpCustomerVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'get_customer_contracts',
                nonce: sgpCustomerVars.nonce
            },
            dataType: 'json',
            timeout: 15000, // 15 segundos de timeout
            success: function(response) {
                $loadingDiv.hide();
                $container.show();
                
                if (response.success) {
                    renderContracts(response.data);
                } else {
                    showError($container, response.data?.message || 'Erro ao carregar contratos');
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = 'Falha na comunicação com o servidor';
                if (status === 'timeout') {
                    errorMessage = 'Tempo limite excedido. Tente novamente.';
                }
                
                showError($container, errorMessage, xhr.responseJSON);
            },
            complete: function() {
                window.contractsLoading = false;
            }
        });
    }

    function renderContracts(contracts) {
        const $container = $('#sgp-contracts-list');
        
        if (!contracts || !Array.isArray(contracts) || contracts.length === 0) {
            $container.html('<div class="sgp-alert sgp-alert-info">Nenhum contrato encontrado</div>');
            return;
        }
        
        let html = `<table class="sgp-table">
            <thead>
                <tr>
                    <th>Contrato</th>
                    <th>Razão Social</th>
                    <th>Status</th>
                    <th>Plano</th>
                    <th>Endereço</th>
                    <th>Vencimento</th>
                </tr>
            </thead>
            <tbody>`;
        
        contracts.forEach(contract => {
            let status = (contract.status || '').trim().toUpperCase();
            let badgeClass = 'sgp-badge-status';
            
            if (status === 'ATIVO') badgeClass += ' sgp-badge-green';
            else if (status === 'CANCELADO') badgeClass += ' sgp-badge-red';
            else badgeClass += ' sgp-badge-gray';
            
            // Trunca endereço se muito longo
            let endereco = contract.endereco || 'N/A';
            let enderecoDisplay = endereco.length > 40 ? endereco.substring(0, 40) + '...' : endereco;
            
            html += `<tr>
                <td><b>${contract.contrato}</b></td>
                <td>${contract.razaosocial || ''}</td>
                <td><span class="${badgeClass}">${status || 'N/A'}</span></td>
                <td>${contract.planointernet || ''}</td>
                <td title="${endereco}">${enderecoDisplay}</td>
                <td>${contract.vencimento || ''}</td>
            </tr>`;
        });
        
        html += '</tbody></table>';
        
        $container.html(html);
        
        // Adiciona informação do total no cabeçalho se ainda não existe
        const $header = $('.sgp-contracts-header h4');
        const currentText = $header.text();
        if (!currentText.includes('(')) {
            $header.text(`${currentText} (${contracts.length})`);
        }
        window.sgpCustomerContracts = contracts;
    }

    // Badge CSS
    const badgeStyle = `<style>
        .sgp-badge-status { display: inline-block; padding: 2px 10px; border-radius: 8px; font-size: 13px; font-weight: 600; }
        .sgp-badge-green { background: #d4f8e8; color: #1a7f37; border: 1px solid #1a7f37; }
        .sgp-badge-red { background: #ffeaea; color: #c00; border: 1px solid #c00; }
        .sgp-badge-gray { background: #f0f0f0; color: #888; border: 1px solid #ccc; }
    </style>`;
    if (!$('head').find('style:contains(sgp-badge-status)').length) {
        $('head').append(badgeStyle);
    }

    // Atualiza dados das abas ao trocar o contrato
    $(document).on('change', '#sgp-contract-selector', function() {
        const activeTab = $('.sgp-nav-item.active').data('tab');
        switch (activeTab) {
            case 'overview':
                loadOverviewData();
                break;
            case 'invoices':
                loadInvoices();
                break;
            case 'tickets':
                loadTickets();
                break;
            case 'contracts':
                loadContracts();
                break;
            case 'access':
                loadConnectionStatus();
                break;
            case 'profile':
                setupProfileEdit();
                break;
            default:
                // Se não reconhecido, recarrega overview
                loadOverviewData();
        }
    });

});



/**
 * customer-login.js - Lógica para área do cliente deslogado
 */
jQuery(document).ready(function($) {
    // =============================================
    // CONSTANTES
    // =============================================
    const API_ENDPOINTS = {
        login: 'customer_login',
        password_recovery: 'customer_password_recovery',
        check_session: 'customer_check_session'
    };

    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    initLoginSection();

    function initLoginSection() {
        bindEvents();
        checkExistingSession();
    }

    // =============================================
    // EVENT BINDING
    // =============================================
    function bindEvents() {
        // Login
        $('#sgp-customer-login-form').on('submit', handleLogin);
        
        // Recuperação de senha
        $('a[href="#recover-password"]').on('click', showRecoveryModal);
        $('#sgp-recover-password-form').on('submit', handlePasswordRecovery);
        
        // Fechar modal
        $('.sgp-close-modal, .sgp-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).hide();
            }
        });
    }

    // =============================================
    // GERENCIAMENTO DE SESSÃO
    // =============================================
    function checkExistingSession() {
        const authToken = localStorage.getItem('sgp_auth_token');
        
        if (authToken) {
            $.ajax({
                url: sgpIntegrationVars.ajaxUrl,
                type: 'POST',
                data: {
                    action: API_ENDPOINTS.check_session,
                    token: authToken,
                    nonce: sgpIntegrationVars.nonce
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect_url || window.location.href;
                    } else {
                        clearSession();
                    }
                },
                error: clearSession
            });
        }
    }

    function clearSession() {
        localStorage.removeItem('sgp_auth_token');
        document.cookie = 'sgp_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    }

    // =============================================
    // LOGIN
    // =============================================
    function handleLogin(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-login-message');
        
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleLoginSuccess(response.data);
                } else {
                    handleLoginError(response.data, $message);
                }
            },
            error: function(xhr) {
                handleLoginError(xhr.responseJSON?.data || { message: 'Erro na comunicação com o servidor' }, $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function handleLoginSuccess(data) {
        // Armazena token JWT
        if (data.token) {
            localStorage.setItem('sgp_auth_token', data.token);
            
            // Cookie para fallback
            const expires = new Date();
            expires.setTime(expires.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 dias
            document.cookie = `sgp_session=${data.token}; expires=${expires.toUTCString()}; path=/`;
        }
        
        // Redireciona
        window.location.href = data.redirect_url || sgpIntegrationVars.homeUrl;
        loadContracts(); // Após login bem-sucedido, chame loadContracts()
    }

    function handleLoginError(error, $container) {
        const errorMessage = error.message || 'Credenciais inválidas. Tente novamente.';
        showAlert(errorMessage, 'error', $container);
        
        // Efeito visual para campos inválidos
        if (error.fields) {
            error.fields.forEach(field => {
                $(`[name="${field}"]`).addClass('sgp-input-error')
                    .one('focus', function() {
                        $(this).removeClass('sgp-input-error');
                    });
            });
        }
    }

    // =============================================
    // RECUPERAÇÃO DE SENHA
    // =============================================
    function showRecoveryModal(e) {
        e.preventDefault();
        $('#sgp-recover-password-modal').show();
    }

    function handlePasswordRecovery(e) {
        e.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $('#sgp-recover-message');
        
        toggleLoading($button, true);
        $message.hide().removeClass('sgp-alert-success sgp-alert-error');
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    handleRecoverySuccess(response.data, $message, $form);
                } else {
                    handleRecoveryError(response.data, $message);
                }
            },
            error: function(xhr) {
                handleRecoveryError(xhr.responseJSON?.data || { message: 'Erro na comunicação com o servidor' }, $message);
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    }

    function handleRecoverySuccess(data, $container, $form) {
        showAlert(data.message || 'E-mail de recuperação enviado com sucesso!', 'success', $container);
        $form[0].reset();
        
        // Fecha o modal após 3 segundos
        setTimeout(() => {
            $('#sgp-recover-password-modal').hide();
        }, 3000);
    }

    function handleRecoveryError(error, $container) {
        const errorMessage = error.message || 'Erro ao solicitar recuperação de senha.';
        showAlert(errorMessage, 'error', $container);
    }

    // =============================================
    // FUNÇÕES AUXILIARES
    // =============================================
    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        $button.find('.sgp-spinner').toggle(isLoading);
        $button.find('.sgp-button-text').text(isLoading ? 'Processando...' : $button.data('original-text'));
    }

    function showAlert(message, type, $container = null) {
        const $target = $container || $('body');
        const alertClass = type === 'error' ? 'sgp-alert-error' : 'sgp-alert-success';
        
        $target.append(`<div class="sgp-alert ${alertClass}">${message}</div>`);
        
        // Remove após 5 segundos
        setTimeout(() => {
            $(`.sgp-alert.${alertClass}`).fadeOut(400, function() {
                $(this).remove();
            });
        }, 5000);
    }
});

// Popup de criação de chamado
function showCreateTicketPopup() {
    if (document.getElementById('sgp-create-ticket-popup')) return;

    // Monta as opções de contratos do cliente a partir do DOM
    let contractOptions = '';
    jQuery('#sgp-contract-selector option').each(function() {
        if (jQuery(this).val()) {
            contractOptions += `<option value="${jQuery(this).val()}">${jQuery(this).text()}</option>`;
        }
    });

    const html = `
    <div class="sgp-popup-overlay" id="sgp-create-ticket-popup" style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.45);z-index:99999;display:flex;align-items:center;justify-content:center;animation:sgpFadeIn 0.2s;">
      <div class="sgp-popup-card" style="background:#fff;padding:32px 28px;max-width:480px;width:95vw;border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,0.18);max-height:90vh;overflow:auto;position:relative;">
        <div class="sgp-popup-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;">
          <span class="sgp-popup-title" style="font-size:1.25rem;font-weight:700;">Abrir Novo Chamado</span>
          <span class="sgp-close-popup" title="Fechar" style="font-size:2rem;cursor:pointer;">&times;</span>
        </div>
        <form id="sgp-create-ticket-form" autocomplete="off">
          <div class="sgp-form-group">
            <label>Contrato <span style='color:#e67e22'>*</span></label>
            <select name="contrato" required class="sgp-input">
              <option value="">Selecione o contrato</option>
              ${contractOptions}
            </select>
          </div>
          <div class="sgp-form-group">
            <label>Nome e Sobrenome <span style='color:#e67e22'>*</span></label>
            <input type="text" name="contato" required placeholder="Nome completo" class="sgp-input" />
          </div>
          <div class="sgp-form-group">
            <label>WhatsApp <span style='color:#e67e22'>*</span></label>
            <input type="tel" name="contato_numero" required maxlength="16" placeholder="(99) 99999-9999" class="sgp-input" />
          </div>
          <div class="sgp-form-group">
            <label>Conteúdo <span style='color:#e67e22'>*</span></label>
            <textarea name="conteudo" required placeholder="Descreva o problema ou solicitação" class="sgp-input"></textarea>
          </div>
          <div class="sgp-form-group">
            <label>Tipo de Ocorrência <span style='color:#e67e22'>*</span></label>
            <select name="ocorrenciatipo" required class="sgp-input">
              <option value="">Selecione...</option>
              <option value="1">Técnica</option>
              <option value="2">Comercial</option>
              <option value="3">Financeira</option>
            </select>
          </div>
          <div class="sgp-form-group">
            <label>Setor <span style='color:#e67e22'>*</span></label>
            <select name="setor" required class="sgp-input">
              <option value="">Selecione...</option>
              <option value="1">Suporte</option>
              <option value="2">Financeiro</option>
              <option value="3">Comercial</option>
            </select>
          </div>
          <div style="margin-top:18px;display:flex;justify-content:flex-end;gap:12px;">
            <button type="button" class="sgp-button sgp-close-popup">Cancelar</button>
            <button type="submit" class="sgp-button sgp-button-primary">Abrir Chamado</button>
          </div>
        </form>
      </div>
    </div>`;

    jQuery(document.body).append(html);

    jQuery('.sgp-close-popup, #sgp-create-ticket-popup').on('click', function(e) {
      if (e.target === this) jQuery('#sgp-create-ticket-popup').remove();
    });
    jQuery('.sgp-popup-card').on('click', function(e) { e.stopPropagation(); });

    // Máscara telefone
    jQuery('input[name=contato_numero]').on('input', function() {
      let v = this.value.replace(/\D/g, '');
      if (v.length > 10) v = v.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
      else v = v.replace(/(\d{2})(\d{4,5})(\d{0,4})/, function(_,a,b,c){ return c ? '('+a+') '+b+'-'+c : '('+a+') '+b; });
      this.value = v;
    });

    jQuery('#sgp-create-ticket-form').on('submit', function(e) {
      e.preventDefault();
      const $form = jQuery(this);
      const $button = $form.find('button[type="submit"]');
      $button.prop('disabled', true);
      const data = $form.serializeArray().reduce((acc, cur) => { acc[cur.name] = cur.value; return acc; }, {});
      data.action = 'create_customer_ticket';
      data.nonce = (typeof sgpCustomerVars !== 'undefined' && sgpCustomerVars.nonce) ? sgpCustomerVars.nonce : '';
      // Validação básica
      if (!data.contrato || !data.contato || !data.contato_numero || !data.conteudo || !data.ocorrenciatipo || !data.setor) {
        alert('Preencha todos os campos obrigatórios!');
        $button.prop('disabled', false);
        return;
      }
      jQuery.ajax({
        url: (typeof sgpCustomerVars !== 'undefined' && sgpCustomerVars.ajaxUrl) ? sgpCustomerVars.ajaxUrl : ajaxurl,
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(resp) {
          if (resp.success) {
            alert('Chamado aberto com sucesso!');
            jQuery('#sgp-create-ticket-popup').remove();
          } else {
            alert(resp.data && resp.data.message ? resp.data.message : 'Erro ao abrir chamado.');
          }
        },
        error: function() {
          alert('Erro ao abrir chamado. Tente novamente.');
        },
        complete: function() {
          $button.prop('disabled', false);
        }
      });
    });
}

// Evento para abrir popup ao clicar em "Novo Chamado"
$(document).on('click', '.sgp-new-ticket-btn', function(e) {
    e.preventDefault();
    showCreateTicketPopup();
});