<?php
/**
 * Template do formulário de consulta de disponibilidade
 * 
 * Shortcode: [sgp_availability_form]
 */
if (!defined('ABSPATH')) {
    exit; // Sai se acessado diretamente
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');
?>

<div class="sgp-availability-form-container">
    
    <form id="sgp-availability-form" class="sgp-ajax-form" method="post">
        <div class="sgp-form-2col-row">
            <div class="sgp-form-group">
                <label for="sgp-street">Rua/Avenida*</label>
                <input type="text" id="sgp-street" name="street" class="sgp-input" placeholder="Nome da rua ou avenida" required>
            </div>
            <div class="sgp-form-group">
                <label for="sgp-number">Número*</label>
                <input type="text" id="sgp-number" name="number" class="sgp-input" placeholder="123" required>
            </div>
        </div>
        <div class="sgp-form-2col-row">
            <div class="sgp-form-group">
                <label for="sgp-cep">CEP*</label>
                <input type="text" id="sgp-cep" name="cep" class="sgp-input sgp-mask-cep" placeholder="00000-000" required maxlength="9">
                <small class="sgp-help-text">Digite o CEP para preenchimento automático</small>
            </div>
            <div class="sgp-form-group">
                <label for="sgp-neighborhood">Bairro*</label>
                <input type="text" id="sgp-neighborhood" name="neighborhood" class="sgp-input" placeholder="Nome do bairro" required>
            </div>
        </div>
        <div class="sgp-form-2col-row">
            <div class="sgp-form-group">
                <label for="sgp-city">Cidade*</label>
                <input type="text" id="sgp-city" name="city" class="sgp-input" placeholder="Nome da cidade" required>
            </div>
            <div class="sgp-form-group">
                <label for="sgp-state">Estado*</label>
                <select id="sgp-state" name="state" class="sgp-input" required>
                    <option value="">Selecione o estado</option>
                    <option value="AC">Acre</option>
                    <option value="AL">Alagoas</option>
                    <option value="AP">Amapá</option>
                    <option value="AM">Amazonas</option>
                    <option value="BA">Bahia</option>
                    <option value="CE">Ceará</option>
                    <option value="DF">Distrito Federal</option>
                    <option value="ES">Espírito Santo</option>
                    <option value="GO">Goiás</option>
                    <option value="MA">Maranhão</option>
                    <option value="MT">Mato Grosso</option>
                    <option value="MS">Mato Grosso do Sul</option>
                    <option value="MG">Minas Gerais</option>
                    <option value="PA">Pará</option>
                    <option value="PB">Paraíba</option>
                    <option value="PR">Paraná</option>
                    <option value="PE">Pernambuco</option>
                    <option value="PI">Piauí</option>
                    <option value="RJ">Rio de Janeiro</option>
                    <option value="RN">Rio Grande do Norte</option>
                    <option value="RS">Rio Grande do Sul</option>
                    <option value="RO">Rondônia</option>
                    <option value="RR">Roraima</option>
                    <option value="SC">Santa Catarina</option>
                    <option value="SP">São Paulo</option>
                    <option value="SE">Sergipe</option>
                    <option value="TO">Tocantins</option>
                </select>
            </div>
        </div>
        <div class="sgp-form-group sgp-form-checkbox">
            <label class="sgp-checkbox-label">
                <input type="checkbox" id="sgp-terms" name="terms" required>
                <span class="sgp-checkbox-text">
                    Concordo com o <a href="#" target="_blank">tratamento dos dados pessoais</a> e autorizo o contato para ofertas comerciais*
                </span>
            </label>
        </div>
        <div class="sgp-form-actions">
            <button type="submit" class="sgp-button sgp-button-primary">
                <span class="sgp-button-text">Verificar disponibilidade</span>
                <span class="sgp-spinner" style="display:none;"></span>
            </button>
        </div>
        <input type="hidden" name="action" value="check_coverage">
        <?php wp_nonce_field('sgp-integration-nonce', 'nonce'); ?>
    </form>
    <div id="sgp-coverage-results" class="sgp-results-container sgp-results-minimal" style="display:none;">
        <div class="sgp-results-body">
            <div id="sgp-coverage-status" class="sgp-status-message sgp-status-success sgp-status-minimal" style="text-align:center;">
                <span class="sgp-status-icon" style="font-size:2rem;vertical-align:middle;">✅</span>
                <span class="sgp-status-text" style="font-size:1.2rem;font-weight:600;margin-left:0.5rem;">Atendemos sua região!</span>
            </div>
        </div>
    </div>
</div>

<script type="text/template" id="sgp-plan-template">
    <div class="sgp-plan-card">
        <div class="sgp-plan-header">
            <h4 class="sgp-plan-name">{{name}}</h4>
            <div class="sgp-plan-price">{{price}}</div>
        </div>
        <div class="sgp-plan-features">
            <ul>
                <li><strong>Download:</strong> {{download_speed}}</li>
                <li><strong>Upload:</strong> {{upload_speed}}</li>
                <li><strong>Tipo:</strong> {{type}}</li>
            </ul>
        </div>
        <div class="sgp-plan-actions">
            <button class="sgp-button sgp-select-plan" data-plan-id="{{id}}">
                Selecionar este plano
            </button>
        </div>
    </div>
</script>