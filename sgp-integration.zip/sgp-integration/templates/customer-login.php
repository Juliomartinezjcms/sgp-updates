<?php
/**
 * Template do formulário de login do cliente
 * 
 * Exibido quando o shortcode [sgp_customer_panel] é usado e o usuário não está logado
 */
if (!defined('ABSPATH')) {
    exit; // Sai se acessado diretamente
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');
?>

<div class="sgp-customer-login-container">
    <div class="sgp-login-header">
        <h3><?php _e('Acesse sua Área do Cliente', 'sgp-integration'); ?></h3>
        <p><?php _e('Gerencie sua conta, visualize faturas e abra chamados', 'sgp-integration'); ?></p>
    </div>
    
    <form id="sgp-customer-login-form" class="sgp-ajax-form" method="post">
        <div class="sgp-form-group">
            <label for="sgp-login-email"><?php _e('E-mail*', 'sgp-integration'); ?></label>
            <input type="email" 
                   id="sgp-login-email" 
                   name="email" 
                   class="sgp-input" 
                   placeholder="<?php _e('seu@email.com', 'sgp-integration'); ?>" 
                   required
                   autocomplete="username">
        </div>
        
        <div class="sgp-form-group">
            <label for="sgp-login-password"><?php _e('Senha*', 'sgp-integration'); ?></label>
            <input type="password" 
                   id="sgp-login-password" 
                   name="password" 
                   class="sgp-input" 
                   placeholder="<?php _e('Sua senha', 'sgp-integration'); ?>" 
                   required
                   autocomplete="current-password">
        </div>
        
        <div class="sgp-form-actions">
            <button type="submit" class="sgp-button sgp-button-primary">
                <span class="sgp-button-text"><?php _e('Entrar', 'sgp-integration'); ?></span>
                <span class="sgp-spinner" style="display:none;"></span>
            </button>
            
            <div class="sgp-login-links">
                <a href="#recover-password" class="sgp-link"><?php _e('Esqueci minha senha', 'sgp-integration'); ?></a>
            </div>
        </div>
        
        <input type="hidden" name="action" value="customer_login">
        <?php wp_nonce_field('sgp-customer-nonce', 'nonce'); ?>
    </form>
    
    <div id="sgp-login-message" class="sgp-alert" style="display:none;"></div>
    
    <?php if (get_option('users_can_register')) : ?>
    <div class="sgp-login-footer">
        <p><?php _e('Ainda não é cliente?', 'sgp-integration'); ?> <a href="#register" class="sgp-link"><?php _e('Solicite seu cadastro', 'sgp-integration'); ?></a></p>
    </div>
    <?php endif; ?>
</div>

<!-- Modal de recuperação de senha (hidden por padrão) -->
<div id="sgp-recover-password-modal" class="sgp-modal" style="display:none;">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4><?php _e('Recuperar Senha', 'sgp-integration'); ?></h4>
        
        <form id="sgp-recover-password-form" class="sgp-ajax-form">
            <div class="sgp-form-group">
                <label for="sgp-recover-email"><?php _e('E-mail cadastrado*', 'sgp-integration'); ?></label>
                <input type="email" 
                       id="sgp-recover-email" 
                       name="email" 
                       class="sgp-input" 
                       placeholder="<?php _e('seu@email.com', 'sgp-integration'); ?>" 
                       required>
            </div>
            
            <div class="sgp-form-actions">
                <button type="submit" class="sgp-button sgp-button-primary">
                    <span class="sgp-button-text"><?php _e('Enviar link de recuperação', 'sgp-integration'); ?></span>
                    <span class="sgp-spinner" style="display:none;"></span>
                </button>
            </div>
            
            <input type="hidden" name="action" value="customer_password_recovery">
            <?php wp_nonce_field('sgp-customer-nonce', 'nonce'); ?>
        </form>
        
        <div id="sgp-recover-message" class="sgp-alert" style="display:none;"></div>
    </div>
</div>