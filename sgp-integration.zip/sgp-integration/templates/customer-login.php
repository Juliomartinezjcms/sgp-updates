<?php
/**
 * Template do formulário de login do cliente
 * 
 * Exibido quando o shortcode [sgp_customer_panel] é usado e o usuário não está logado
 */
if (!defined('ABSPATH')) {
    exit; // Sai se acessado diretamente
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');
?>

<div class="sgp-customer-login-container">
    <div class="sgp-login-header">
        <div class="sgp-logo-wrapper">
            <?php 
            $login_logo = get_option('sgp_login_logo', '');
            if ($login_logo) {
                $logo_url = wp_get_attachment_image_url($login_logo, 'medium');
                if ($logo_url) { ?>
                    <div class="sgp-custom-logo">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" />
                    </div>
                <?php } else { ?>
                    <div class="sgp-tech-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="3"/>
                            <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                        </svg>
                    </div>
                <?php }
            } else { ?>
                <div class="sgp-tech-icon">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                    </svg>
                </div>
            <?php } ?>
        </div>
        <h3><?php echo apply_filters('sgp_customer_panel_title', __('Acesse sua Área do Cliente', 'sgp-integration')); ?></h3>
        <p><?php echo apply_filters('sgp_customer_panel_subtitle', __('Gerencie sua conta, visualize faturas e abra chamados', 'sgp-integration')); ?></p>
    </div>
    
    <form id="sgp-customer-login-form" class="sgp-ajax-form" method="post">
        <div class="sgp-form-group">
            <label for="sgp-login-cpfcnpj"><?php _e('CPF/CNPJ*', 'sgp-integration'); ?></label>
            <input type="text" 
                   id="sgp-login-cpfcnpj" 
                   name="cpfcnpj" 
                   class="sgp-input sgp-cpfcnpj-mask" 
                   placeholder="<?php _e('Seu CPF ou CNPJ', 'sgp-integration'); ?>" 
                   required
                   maxlength="18"
                   autocomplete="username">
            <small class="sgp-form-help"><?php _e('Digite apenas números', 'sgp-integration'); ?></small>
        </div>
        
        <div class="sgp-form-group">
            <label for="sgp-login-password"><?php _e('Senha*', 'sgp-integration'); ?></label>
            <input type="password" 
                   id="sgp-login-password" 
                   name="password" 
                   class="sgp-input" 
                   placeholder="<?php _e('Sua senha', 'sgp-integration'); ?>" 
                   required
                   autocomplete="current-password">
        </div>
        
        <div class="sgp-form-group sgp-form-actions">
            <button type="submit" class="sgp-btn sgp-btn-primary">
                <span class="sgp-btn-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4m-5-4l5-5-5-5m5 5H3"/>
                    </svg>
                </span>
                <span class="sgp-btn-text"><?php echo apply_filters('sgp_customer_panel_button_text', __('Entrar', 'sgp-integration')); ?></span>
                <span class="sgp-btn-loading">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 12a9 9 0 11-6.219-8.56"/>
                    </svg>
                </span>
            </button>
        </div>
        
        <div class="sgp-form-links">
            <a href="#recover-password" class="sgp-forgot-password">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 7l5.5 4 5.5-4"/>
                    <rect x="2" y="6" width="20" height="12" rx="2"/>
                </svg>
                <?php _e('Esqueci minha senha', 'sgp-integration'); ?>
            </a>
            <span class="sgp-separator">•</span>
            <a href="#help" class="sgp-help-link">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                <?php _e('Precisa de ajuda?', 'sgp-integration'); ?>
            </a>
        </div>
        
        <div class="sgp-form-footer">
            <p class="sgp-login-info">
                <?php _e('Primeira vez? Entre com seu CPF/CNPJ e a senha fornecida pela empresa.', 'sgp-integration'); ?>
            </p>
        </div>
        
        <input type="hidden" name="action" value="customer_login">
        <?php wp_nonce_field('sgp-customer-nonce', 'nonce'); ?>
    </form>
    
    <div id="sgp-login-message" class="sgp-alert" style="display:none;"></div>
    
    <?php if (get_option('users_can_register')) : ?>
    <div class="sgp-login-footer">
        <p><?php _e('Ainda não é cliente?', 'sgp-integration'); ?> <a href="#register" class="sgp-link"><?php _e('Solicite seu cadastro', 'sgp-integration'); ?></a></p>
    </div>
    <?php endif; ?>
</div>

<!-- Modal de recuperação de senha (hidden por padrão) -->
<div id="sgp-recover-password-modal" class="sgp-modal" style="display:none;">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4><?php _e('Recuperar Senha', 'sgp-integration'); ?></h4>
        
        <form id="sgp-recover-password-form" class="sgp-ajax-form">
            <div class="sgp-form-group">
                <label for="sgp-recover-email"><?php _e('E-mail cadastrado*', 'sgp-integration'); ?></label>
                <input type="email" 
                       id="sgp-recover-email" 
                       name="email" 
                       class="sgp-input" 
                       placeholder="<?php _e('seu@email.com', 'sgp-integration'); ?>" 
                       required>
            </div>
            
            <div class="sgp-form-actions">
                <button type="submit" class="sgp-button sgp-button-primary">
                    <span class="sgp-button-text"><?php _e('Enviar link de recuperação', 'sgp-integration'); ?></span>
                    <span class="sgp-spinner" style="display:none;"></span>
                </button>
            </div>
            
            <input type="hidden" name="action" value="customer_password_recovery">
            <?php wp_nonce_field('sgp-customer-nonce', 'nonce'); ?>
        </form>
        
        <div id="sgp-recover-message" class="sgp-alert" style="display:none;"></div>
    </div>
</div>