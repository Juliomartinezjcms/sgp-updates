<?php
if (!defined('ABSPATH')) exit;
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');
?>
<div class="sgp-lead-form-container">
    <form id="sgp-lead-form" class="sgp-ajax-form" method="post">
        <div class="sgp-form-group">
            <label for="sgp-lead-nome">Nome*</label>
            <input type="text" id="sgp-lead-nome" name="nome" class="sgp-input" required>
        </div>
        <div class="sgp-form-group">
            <label for="sgp-lead-email">Email*</label>
            <input type="email" id="sgp-lead-email" name="email" class="sgp-input" required>
        </div>
        <div class="sgp-form-group">
            <label for="sgp-lead-telefone">Telefone*</label>
            <input type="text" id="sgp-lead-telefone" name="telefone" class="sgp-input" required>
        </div>
        <div class="sgp-form-group">
            <label for="sgp-lead-origem">Origem</label>
            <input type="text" id="sgp-lead-origem" name="origem" class="sgp-input" value="website">
        </div>
        <div class="sgp-form-group">
            <label for="sgp-lead-status">Status</label>
            <select id="sgp-lead-status" name="status" class="sgp-input">
                <option value="novo">Novo</option>
                <option value="contatado">Contatado</option>
                <option value="qualificado">Qualificado</option>
                <option value="convertido">Convertido</option>
            </select>
        </div>
        <div class="sgp-form-actions">
            <button type="submit" class="sgp-button sgp-button-primary">
                <span class="sgp-button-text">Enviar Lead</span>
                <span class="sgp-spinner" style="display:none;"></span>
            </button>
        </div>
        <input type="hidden" name="action" value="create_lead">
        <?php wp_nonce_field('sgp-integration-nonce', 'nonce'); ?>
    </form>
    <div id="sgp-lead-result" style="margin-top:10px;"></div>
</div>
<script>
jQuery(function($){
    $('#sgp-lead-form').on('submit', function(e){
        e.preventDefault();
        var form = $(this);
        var btn = form.find('button[type=submit]');
        var spinner = form.find('.sgp-spinner');
        var result = $('#sgp-lead-result');
        btn.prop('disabled', true);
        spinner.show();
        result.html('');
        $.post(ajaxurl, form.serialize(), function(resp){
            btn.prop('disabled', false);
            spinner.hide();
            if(resp.success){
                result.html('<div class="sgp-success">'+resp.data.message+'</div>');
                form[0].reset();
            }else{
                result.html('<div class="sgp-error">'+resp.data.message+'</div>');
            }
        });
    });
});
</script> 