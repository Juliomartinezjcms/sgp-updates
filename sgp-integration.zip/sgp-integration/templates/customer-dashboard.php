<?php
/**
 * Template do painel do cliente logado
 * 
 * Shortcode: [sgp_customer_panel]
 */
if (!defined('ABSPATH')) {
    exit; // Sai se acessado diretamente
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');

// Verifica se há um cliente autenticado
$customer_data = apply_filters('sgp_get_customer_data', []);
?>

<div class="sgp-customer-dashboard">
    <!-- Cabeçalho do Painel -->
    <div class="sgp-dashboard-header">
        <div class="sgp-welcome-message">
            <h3>Olá, <?php echo esc_html($customer_data['name'] ?? 'Cliente'); ?>!</h3>
            <p>Bem-vindo à sua área de cliente</p>
        </div>
        <div class="sgp-account-status">
            <span class="sgp-status-badge sgp-status-<?php echo esc_attr($customer_data['account_status'] ?? 'active'); ?>">
                <?php echo esc_html($customer_data['account_status_label'] ?? 'Ativo'); ?>
            </span>
        </div>
    </div>

    <!-- Menu de Navegação -->
    <nav class="sgp-dashboard-nav">
        <ul class="sgp-nav-tabs">
            <li class="sgp-nav-item active" data-tab="overview">
                <a href="#overview"><i class="sgp-icon sgp-icon-dashboard"></i> Visão Geral</a>
            </li>
            <li class="sgp-nav-item" data-tab="invoices">
                <a href="#invoices"><i class="sgp-icon sgp-icon-invoice"></i> Faturas</a>
            </li>
            <li class="sgp-nav-item" data-tab="tickets">
                <a href="#tickets"><i class="sgp-icon sgp-icon-ticket"></i> Chamados</a>
            </li>
            <li class="sgp-nav-item" data-tab="profile">
                <a href="#profile"><i class="sgp-icon sgp-icon-profile"></i> Meus Dados</a>
            </li>
            <li class="sgp-nav-item sgp-logout-item">
                <a href="<?php echo wp_logout_url(home_url()); ?>"><i class="sgp-icon sgp-icon-logout"></i> Sair</a>
            </li>
        </ul>
    </nav>

    <!-- Conteúdo das Abas -->
    <div class="sgp-tab-content">
        <!-- Visão Geral -->
        <div id="overview" class="sgp-tab-pane active">
            <div class="sgp-overview-grid">
                <!-- Plano Ativo -->
                <div class="sgp-overview-card sgp-current-plan">
                    <h4 class="sgp-card-title">Seu Plano Ativo</h4>
                    <div class="sgp-plan-details">
                        <div class="sgp-plan-name"><?php echo esc_html($customer_data['plan']['name'] ?? 'Nenhum plano ativo'); ?></div>
                        <div class="sgp-plan-price">R$ <?php echo number_format($customer_data['plan']['price'] ?? 0, 2, ',', '.'); ?>/mês</div>
                        <div class="sgp-plan-speed">
                            <span class="sgp-speed-download">
                                <i class="sgp-icon sgp-icon-download"></i> 
                                <?php echo esc_html($customer_data['plan']['download_speed'] ?? '0'); ?> Mbps
                            </span>
                            <span class="sgp-speed-upload">
                                <i class="sgp-icon sgp-icon-upload"></i> 
                                <?php echo esc_html($customer_data['plan']['upload_speed'] ?? '0'); ?> Mbps
                            </span>
                        </div>
                    </div>
                    <button class="sgp-button sgp-button-secondary sgp-change-plan-btn">Alterar Plano</button>
                </div>

                <!-- Próxima Fatura -->
                <div class="sgp-overview-card sgp-next-invoice">
                    <h4 class="sgp-card-title">Próxima Fatura</h4>
                    <div class="sgp-invoice-details">
                        <div class="sgp-invoice-amount">R$ <?php echo number_format($customer_data['next_invoice']['amount'] ?? 0, 2, ',', '.'); ?></div>
                        <div class="sgp-invoice-due-date">
                            <i class="sgp-icon sgp-icon-calendar"></i> 
                            Vencimento: <?php echo esc_html($customer_data['next_invoice']['due_date'] ?? '--/--/----'); ?>
                        </div>
                        <div class="sgp-invoice-status">
                            Status: <span class="sgp-status-badge sgp-status-<?php echo esc_attr($customer_data['next_invoice']['status'] ?? 'pending'); ?>">
                                <?php echo esc_html($customer_data['next_invoice']['status_label'] ?? 'Pendente'); ?>
                            </span>
                        </div>
                    </div>
                    <button class="sgp-button sgp-button-primary sgp-pay-invoice-btn">Pagar Fatura</button>
                </div>

                <!-- Consumo -->
                <div class="sgp-overview-card sgp-usage-stats">
                    <h4 class="sgp-card-title">Seu Consumo</h4>
                    <div class="sgp-usage-meter">
                        <div class="sgp-meter-bar" style="width: <?php echo esc_attr($customer_data['usage']['percentage'] ?? 0); ?>%"></div>
                        <div class="sgp-meter-text">
                            <?php echo esc_html($customer_data['usage']['used'] ?? 0); ?> GB de 
                            <?php echo esc_html($customer_data['usage']['total'] ?? 0); ?> GB
                        </div>
                    </div>
                    <div class="sgp-usage-reset">
                        Ciclo renova em: <?php echo esc_html($customer_data['usage']['reset_date'] ?? '--/--/----'); ?>
                    </div>
                    <button class="sgp-button sgp-button-secondary sgp-usage-details-btn">Ver Detalhes</button>
                </div>

                <!-- Chamados Recentes -->
                <div class="sgp-overview-card sgp-recent-tickets">
                    <h4 class="sgp-card-title">Chamados Recentes</h4>
                    <?php if (!empty($customer_data['recent_tickets'])) : ?>
                        <ul class="sgp-tickets-list">
                            <?php foreach ($customer_data['recent_tickets'] as $ticket) : ?>
                                <li class="sgp-ticket-item">
                                    <span class="sgp-ticket-id">#<?php echo esc_html($ticket['id']); ?></span>
                                    <span class="sgp-ticket-subject"><?php echo esc_html($ticket['subject']); ?></span>
                                    <span class="sgp-ticket-status sgp-status-<?php echo esc_attr($ticket['status']); ?>">
                                        <?php echo esc_html($ticket['status_label']); ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p class="sgp-no-tickets">Nenhum chamado recente</p>
                    <?php endif; ?>
                    <button class="sgp-button sgp-button-primary sgp-new-ticket-btn">Abrir Novo Chamado</button>
                </div>
            </div>
        </div>

        <!-- Faturas -->
        <div id="invoices" class="sgp-tab-pane">
            <div class="sgp-invoices-header">
                <h4>Histórico de Faturas</h4>
                <div class="sgp-invoices-filter">
                    <select id="sgp-invoice-period" class="sgp-select">
                        <option value="all">Todos os períodos</option>
                        <option value="last_6">Últimos 6 meses</option>
                        <option value="last_12">Últimos 12 meses</option>
                        <option value="current_year">Este ano</option>
                    </select>
                </div>
            </div>

            <div class="sgp-invoices-list">
                <div class="sgp-invoices-loading" style="display: none;">
                    <div class="sgp-spinner"></div>
                    <p>Carregando faturas...</p>
                </div>
                <div class="sgp-invoices-content">
                    <!-- As faturas serão carregadas via AJAX -->
                </div>
            </div>
        </div>

        <!-- Chamados -->
        <div id="tickets" class="sgp-tab-pane">
            <div class="sgp-tickets-header">
                <h4>Meus Chamados</h4>
                <button class="sgp-button sgp-button-primary sgp-new-ticket-btn">
                    <i class="sgp-icon sgp-icon-plus"></i> Novo Chamado
                </button>
            </div>

            <div class="sgp-tickets-list-container">
                <div class="sgp-tickets-loading" style="display: none;">
                    <div class="sgp-spinner"></div>
                    <p>Carregando chamados...</p>
                </div>
                <div class="sgp-tickets-content">
                    <!-- Os chamados serão carregados via AJAX -->
                </div>
            </div>
        </div>

        <!-- Perfil -->
        <div id="profile" class="sgp-tab-pane">
            <div class="sgp-profile-header">
                <h4>Meus Dados Cadastrais</h4>
                <button class="sgp-button sgp-button-secondary sgp-edit-profile-btn">
                    <i class="sgp-icon sgp-icon-edit"></i> Editar
                </button>
            </div>

            <div class="sgp-profile-content">
                <form id="sgp-profile-form" class="sgp-profile-view-mode">
                    <div class="sgp-profile-section">
                        <h5>Informações Pessoais</h5>
                        <div class="sgp-profile-row">
                            <label>Nome completo:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['full_name'] ?? ''); ?></span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>CPF:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['cpf'] ?? ''); ?></span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>Data de nascimento:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['birth_date'] ?? ''); ?></span>
                        </div>
                    </div>

                    <div class="sgp-profile-section">
                        <h5>Contato</h5>
                        <div class="sgp-profile-row">
                            <label>E-mail:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['email'] ?? ''); ?></span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>Telefone:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['phone'] ?? ''); ?></span>
                        </div>
                    </div>

                    <div class="sgp-profile-section">
                        <h5>Endereço</h5>
                        <div class="sgp-profile-row">
                            <label>CEP:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['address']['cep'] ?? ''); ?></span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>Endereço:</label>
                            <span class="sgp-profile-value">
                                <?php echo esc_html($customer_data['address']['street'] ?? ''); ?>, 
                                <?php echo esc_html($customer_data['address']['number'] ?? ''); ?>
                                <?php if (!empty($customer_data['address']['complement'])) : ?>
                                    - <?php echo esc_html($customer_data['address']['complement']); ?>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>Bairro:</label>
                            <span class="sgp-profile-value"><?php echo esc_html($customer_data['address']['neighborhood'] ?? ''); ?></span>
                        </div>
                        <div class="sgp-profile-row">
                            <label>Cidade/UF:</label>
                            <span class="sgp-profile-value">
                                <?php echo esc_html($customer_data['address']['city'] ?? ''); ?>/ 
                                <?php echo esc_html($customer_data['address']['state'] ?? ''); ?>
                            </span>
                        </div>
                    </div>

                    <div class="sgp-profile-actions sgp-edit-mode" style="display: none;">
                        <button type="submit" class="sgp-button sgp-button-primary">Salvar Alterações</button>
                        <button type="button" class="sgp-button sgp-button-secondary sgp-cancel-edit-btn">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Novo Chamado -->
<div id="sgp-new-ticket-modal" class="sgp-modal">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4>Abrir Novo Chamado</h4>
        
        <form id="sgp-new-ticket-form" class="sgp-ajax-form">
            <div class="sgp-form-group">
                <label for="sgp-ticket-subject">Assunto*</label>
                <input type="text" id="sgp-ticket-subject" name="subject" class="sgp-input" required>
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-department">Departamento*</label>
                <select id="sgp-ticket-department" name="department" class="sgp-select" required>
                    <option value="">Selecione...</option>
                    <option value="technical">Suporte Técnico</option>
                    <option value="financial">Financeiro</option>
                    <option value="billing">Cobrança</option>
                    <option value="general">Geral</option>
                </select>
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-message">Mensagem*</label>
                <textarea id="sgp-ticket-message" name="message" class="sgp-textarea" rows="5" required></textarea>
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-attachment">Anexo (Opcional)</label>
                <input type="file" id="sgp-ticket-attachment" name="attachment" class="sgp-file-input">
                <small class="sgp-help-text">Formatos aceitos: JPG, PNG, PDF (até 2MB)</small>
            </div>
            
            <div class="sgp-form-actions">
                <button type="submit" class="sgp-button sgp-button-primary">
                    <span class="sgp-button-text">Enviar Chamado</span>
                    <span class="sgp-spinner" style="display: none;"></span>
                </button>
            </div>
            
            <input type="hidden" name="action" value="create_ticket">
            <?php wp_nonce_field('sgp-customer-nonce', 'nonce'); ?>
        </form>
        
        <div id="sgp-ticket-message" class="sgp-alert" style="display: none;"></div>
    </div>
</div>

<!-- Modal para Alteração de Plano -->
<div id="sgp-change-plan-modal" class="sgp-modal">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4>Alterar Plano</h4>
        
        <div class="sgp-plans-comparison">
            <div class="sgp-current-plan">
                <h5>Seu Plano Atual</h5>
                <div class="sgp-plan-card">
                    <div class="sgp-plan-name"><?php echo esc_html($customer_data['plan']['name'] ?? 'Nenhum plano ativo'); ?></div>
                    <div class="sgp-plan-price">R$ <?php echo number_format($customer_data['plan']['price'] ?? 0, 2, ',', '.'); ?>/mês</div>
                    <div class="sgp-plan-speed">
                        <span class="sgp-speed-download">
                            <i class="sgp-icon sgp-icon-download"></i> 
                            <?php echo esc_html($customer_data['plan']['download_speed'] ?? '0'); ?> Mbps
                        </span>
                        <span class="sgp-speed-upload">
                            <i class="sgp-icon sgp-icon-upload"></i> 
                            <?php echo esc_html($customer_data['plan']['upload_speed'] ?? '0'); ?> Mbps
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="sgp-available-plans">
                <h5>Planos Disponíveis</h5>
                <div class="sgp-plans-grid">
                    <!-- Os planos serão carregados via AJAX -->
                </div>
            </div>
        </div>
        
        <div class="sgp-plan-change-terms">
            <label class="sgp-checkbox-container">
                <input type="checkbox" id="sgp-accept-terms" required>
                <span class="sgp-checkbox-checkmark"></span>
                <span class="sgp-checkbox-text">Li e aceito os termos de alteração de plano</span>
            </label>
        </div>
        
        <div class="sgp-form-actions">
            <button id="sgp-confirm-plan-change" class="sgp-button sgp-button-primary" disabled>
                <span class="sgp-button-text">Confirmar Alteração</span>
                <span class="sgp-spinner" style="display: none;"></span>
            </button>
        </div>
    </div>
</div>