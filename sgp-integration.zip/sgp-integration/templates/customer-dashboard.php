<?php
/**
 * Template do painel do cliente logado - API SGP Central Integrada
 * 
 * Shortcode: [sgp_customer_panel]
 * Versão: 2.7.0 - API Central SGP Real
 */
if (!defined('ABSPATH')) {
    exit;
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');

// Headers para prevenir cache da área do cliente
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Enqueue session-check.js
wp_enqueue_script(
    'sgp-session-check',
    SGP_INTEGRATION_URL . 'assets/js/session-check.js',
    ['jquery'],
    SGP_INTEGRATION_VERSION,
    true
);

// Enqueue customer-panel.js
wp_enqueue_script(
    'sgp-customer-panel',
    SGP_INTEGRATION_URL . 'assets/js/customer-panel.js',
    ['jquery', 'sgp-integration-frontend', 'sgp-session-check'],
    SGP_INTEGRATION_VERSION,
    true
);

// Localiza variáveis para o customer-panel.js
wp_localize_script('sgp-customer-panel', 'sgpCustomerVars', [
    'ajaxUrl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('sgp-integration-nonce'),
    'logoutNonce' => wp_create_nonce('sgp-customer-nonce'), // Nonce específico para logout
    'enableSessionCheck' => isset($enable_session_check) ? (bool)$enable_session_check : true,
    'i18n' => [
        'loadingContracts' => __('Carregando contratos...', 'sgp-integration'),
        'loadingInvoices' => __('Carregando faturas...', 'sgp-integration'),
        'loadingTickets' => __('Carregando chamados...', 'sgp-integration'),
        'verifyingAccess' => __('Verificando acesso...', 'sgp-integration'),
        'errorConnection' => __('Erro de conexão', 'sgp-integration'),
        'loginSuccess' => __('Login realizado com sucesso!', 'sgp-integration'),
        'logoutSuccess' => __('Logout realizado com sucesso!', 'sgp-integration')
    ]
]);

// Dados do usuário logado
$user_id = get_current_user_id();
$user = wp_get_current_user();

// Verificação adicional de segurança
if (!$user_id || !in_array('sgp_customer', $user->roles)) {
    wp_redirect(home_url());
    exit;
}

$sgp_cpfcnpj = get_user_meta($user_id, 'sgp_cpfcnpj', true);
$sgp_contracts = get_user_meta($user_id, 'sgp_contracts', true);
$contracts_data = $sgp_contracts ? json_decode($sgp_contracts, true) : [];

// Se não há dados SGP, redireciona para login
if (empty($sgp_cpfcnpj)) {
    wp_logout();
    wp_redirect(home_url());
    exit;
}

// Pega o primeiro contrato como padrão
$default_contract = !empty($contracts_data) ? $contracts_data[0]['contrato'] : '';
?>

<div class="sgp-customer-dashboard" data-user-cpfcnpj="<?php echo esc_attr($sgp_cpfcnpj); ?>" data-default-contract="<?php echo esc_attr($default_contract); ?>" data-session-check="enabled">
    <!-- Cabeçalho do Painel -->
    <div class="sgp-dashboard-header">
        <div class="sgp-welcome-message">
            <h3>Olá, <?php echo esc_html($user->display_name); ?>!</h3>
            <p>Bem-vindo à sua área de cliente SGP</p>
            <small>CPF/CNPJ: <?php echo esc_html($sgp_cpfcnpj); ?></small>
            <?php if (!empty($contracts_data)) : ?>
                <small style="display: block; margin-top: 5px; opacity: 0.8;">
                    <?php echo count($contracts_data); ?> contrato(s) encontrado(s)
                </small>
                <div style="margin-top: 10px;">
                    <label for="sgp-contract-selector" style="font-size: 13px; color: #fff; margin-right: 8px; font-weight: 500;">Contrato:</label>
                    <select id="sgp-contract-selector" name="contrato" style="padding: 4px 8px; border-radius: 5px; border: 1.2px solid #fff; color: #333 !important; background: #fff; min-width: 180px; font-size: 14px; font-weight: 400; height: 32px; line-height: 1.2; box-shadow: 0 1px 4px rgba(0,0,0,0.06);">
                        <option value="" disabled hidden style="color: #888;">Selecione um contrato</option>
                        <?php foreach ($contracts_data as $contract) : ?>
                            <option value="<?php echo esc_attr($contract['contrato']); ?>" data-status="<?php echo esc_attr($contract['status']); ?>"<?php echo ($contract['contrato'] == $default_contract) ? ' selected' : ''; ?>>
                                <?php echo esc_html($contract['contrato']); ?><?php if (!empty($contract['razaosocial'])) echo ' - ' . esc_html($contract['razaosocial']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>
        </div>
        <div class="sgp-account-actions">
            <button id="sgp-logout-btn" class="sgp-button sgp-button-secondary">
                🚪 Sair
            </button>
        </div>
    </div>

    <!-- Menu de Navegação -->
    <nav class="sgp-dashboard-nav">
        <ul class="sgp-nav-tabs">
            <li class="sgp-nav-item active" data-tab="overview">
                <a href="#overview">📊 Visão Geral</a>
            </li>
            <li class="sgp-nav-item" data-tab="contracts">
                <a href="#contracts">📄 Contratos</a>
            </li>
            <li class="sgp-nav-item" data-tab="invoices">
                <a href="#invoices">💰 Faturas</a>
            </li>
            <li class="sgp-nav-item" data-tab="tickets">
                <a href="#tickets">🎫 Chamados</a>
            </li>
            <li class="sgp-nav-item" data-tab="access">
                <a href="#access">📡 Meu Acesso</a>
            </li>
        </ul>
    </nav>

    <!-- Conteúdo das Abas -->
    <div class="sgp-tab-content">
        <!-- Visão Geral -->
        <div id="overview" class="sgp-tab-pane active">
            <div class="sgp-overview-grid">
                <!-- Status da Conexão -->
                <div class="sgp-overview-card sgp-connection-status">
                    <h4 class="sgp-card-title">Status da Conexão</h4>
                    <div id="sgp-connection-info">
                        <p class="sgp-help-text">Aguardando verificação...</p>
                    </div>
                </div>

                <!-- Últimas Faturas -->
                <div class="sgp-overview-card sgp-recent-invoices">
                    <h4 class="sgp-card-title">Últimas Faturas</h4>
                    <div id="sgp-recent-invoices-list">
                        <p class="sgp-help-text">Aguardando dados...</p>
                    </div>
                </div>

                <!-- Chamados Recentes -->
                <div class="sgp-overview-card sgp-recent-tickets">
                    <h4 class="sgp-card-title">Chamados Recentes</h4>
                    <div id="sgp-recent-tickets-list">
                        <p class="sgp-help-text">Aguardando dados...</p>
                    </div>
                    <button class="sgp-button sgp-button-primary sgp-new-ticket-btn">Abrir Novo Chamado</button>
                </div>

                <!-- Ações Rápidas -->
                <div class="sgp-overview-card sgp-quick-actions">
                    <h4 class="sgp-card-title">Ações Rápidas</h4>
                    <div class="sgp-quick-actions-grid">
                        <button id="sgp-quick-second-copy" class="sgp-quick-action-btn">
                            📄
                            <span>2ª Via de Fatura</span>
                        </button>
                        <button id="sgp-quick-generate-pix" class="sgp-quick-action-btn">
                            💳
                            <span>Gerar PIX</span>
                        </button>
                        <button id="sgp-quick-verify-access" class="sgp-quick-action-btn">
                            ✅
                            <span>Verificar Acesso</span>
                        </button>
                        <button class="sgp-quick-action-btn sgp-new-ticket-btn">
                            ➕
                            <span>Novo Chamado</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contratos -->
        <div id="contracts" class="sgp-tab-pane">
            <div class="sgp-contracts-header">
                <h4>Meus Contratos</h4>
            </div>
            <div class="sgp-contracts-loading sgp-loading" style="display: none;">
                <span class="sgp-spinner"></span>
                Carregando contratos...
            </div>
            <div id="sgp-contracts-list" class="sgp-contracts-container">
                <div class="sgp-initial-loading">
                    <span class="sgp-spinner"></span>
                    <p class="sgp-help-text">Carregando seus contratos automaticamente...</p>
                </div>
            </div>
        </div>

        <!-- Faturas -->
        <div id="invoices" class="sgp-tab-pane">
            <div class="sgp-invoices-header">
                <h4>Histórico de Faturas</h4>
                <div class="sgp-invoices-actions">
                    <select id="sgp-invoice-period" class="sgp-select">
                        <option value="all">Todas as faturas</option>
                        <option value="last_3_months">Últimos 3 meses</option>
                        <option value="last_6_months">Últimos 6 meses</option>
                        <option value="current_year">Ano atual</option>
                    </select>
                    <!-- Botão Atualizar removido -->
                </div>
            </div>
            <div class="sgp-invoices-loading sgp-loading" style="display: none;">
                <span class="sgp-spinner"></span>
                Carregando faturas...
            </div>
            <div class="sgp-invoices-content">
                <p class="sgp-help-text">Selecione um período para carregar as faturas.</p>
            </div>
        </div>

        <!-- Chamados -->
        <div id="tickets" class="sgp-tab-pane">
            <div class="sgp-tickets-header">
                <h4>Meus Chamados</h4>
                <div class="sgp-tickets-actions">
                    <button class="sgp-button sgp-button-primary sgp-new-ticket-btn">
                        ➕ Novo Chamado
                    </button>
                    <!-- Botão Atualizar removido -->
                </div>
            </div>
            <div class="sgp-tickets-loading sgp-loading" style="display: none;">
                <span class="sgp-spinner"></span>
                Carregando chamados...
            </div>
            <div class="sgp-tickets-content">
                <p class="sgp-help-text">Clique em "Atualizar" para carregar os chamados.</p>
            </div>
        </div>

        <!-- Meu Acesso -->
        <div id="access" class="sgp-tab-pane">
            <div class="sgp-access-header">
                <h4>Verificar Meu Acesso</h4>
                <button id="sgp-check-access" class="sgp-button sgp-button-primary">
                    ✅ Verificar Agora
                </button>
            </div>
            <div id="sgp-access-info" class="sgp-access-container">
                <p class="sgp-help-text">Clique em "Verificar Agora" para ver o status da sua conexão e informações técnicas do seu acesso.</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal para Novo Chamado -->
<div id="sgp-new-ticket-modal" class="sgp-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 99999; background-color: rgba(0,0,0,0.7); display: none;">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4>Abrir Novo Chamado</h4>
        
        <form id="sgp-new-ticket-form" class="sgp-ajax-form">
            <div class="sgp-form-group">
                <label for="sgp-ticket-contrato">Contrato*</label>
                <select id="sgp-ticket-contrato" name="contrato" class="sgp-input" required>
                    <?php if (!empty($contracts_data)) : ?>
                        <?php foreach ($contracts_data as $contract) : ?>
                            <option value="<?php echo esc_attr($contract['contrato']); ?>">
                                Contrato: <?php echo esc_html($contract['contrato']); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-conteudo">Descrição do Problema*</label>
                <textarea id="sgp-ticket-conteudo" name="conteudo" class="sgp-textarea" rows="5" required placeholder="Descreva detalhadamente o problema ou solicitação..."></textarea>
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-contato">Nome do Contato*</label>
                <input type="text" id="sgp-ticket-contato" name="contato" class="sgp-input" required value="<?php echo esc_attr($user->display_name); ?>">
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-contato-numero">Telefone para Contato*</label>
                <input type="tel" id="sgp-ticket-contato-numero" name="contato_numero" class="sgp-input sgp-phone-mask" required placeholder="(11) 99999-9999">
            </div>
            
            <div class="sgp-form-group">
                <label for="sgp-ticket-motivoos">Tipo do Chamado</label>
                <select id="sgp-ticket-motivoos" name="motivoos" class="sgp-input">
                    <option value="40">Suporte Técnico</option>
                    <option value="50">Financeiro</option>
                    <option value="60">Comercial</option>
                    <option value="70">Outros</option>
                </select>
            </div>
            
            <div class="sgp-form-actions">
                <button type="submit" class="sgp-button sgp-button-primary">
                    <span class="sgp-button-text">Enviar Chamado</span>
                    <span class="sgp-spinner" style="display: none;"></span>
                </button>
            </div>
            
            <input type="hidden" name="sem_os" value="1">
            <input type="hidden" name="ocorrenciatipo" value="5">
            <?php wp_nonce_field('sgp-integration-nonce', 'nonce'); ?>
        </form>
    </div>
</div>

<!-- Modal para PIX -->
<div id="sgp-pix-modal" class="sgp-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 99999; background-color: rgba(0,0,0,0.7); display: none;">
    <div class="sgp-modal-content">
        <span class="sgp-close-modal">&times;</span>
        <h4>Gerar Código PIX</h4>
        <div id="sgp-pix-content">
            <p>Selecione uma fatura para gerar o código PIX:</p>
            <div id="sgp-pix-invoices" class="sgp-pix-invoices-list">
                <!-- Lista de faturas será carregada aqui -->
            </div>
        </div>
    </div>
</div>

<!-- CSS Customizado -->
<style>
.sgp-customer-dashboard {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
}

.sgp-dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: linear-gradient(135deg, #ff7b00 0%, #cc5500 100%);
    color: white;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.sgp-welcome-message h3 {
    margin: 0;
    font-size: 24px;
    font-weight: 600;
    color: white;
}

.sgp-welcome-message p {
    margin: 5px 0;
    opacity: 0.9;
    color: white;
}

.sgp-welcome-message small {
    opacity: 0.8;
    font-size: 12px;
    color: white;
}

.sgp-dashboard-header * {
    color: white !important;
}

.sgp-dashboard-header .sgp-button-secondary {
    background: rgba(255, 255, 255, 0.2);
    color: white !important;
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.sgp-dashboard-header .sgp-button-secondary:hover {
    background: rgba(255, 255, 255, 0.3);
    color: white !important;
}

.sgp-nav-tabs {
    display: flex;
    list-style: none;
    margin: 0 0 20px 0;
    padding: 0;
    border-bottom: 1px solid #eee;
}

.sgp-nav-item {
    margin-right: 15px;
}

.sgp-nav-item a {
    display: block;
    padding: 10px 15px;
    color: #7f8c8d;
    text-decoration: none;
    border-bottom: 2px solid transparent;
    transition: all 0.3s ease;
    cursor: pointer;
}

.sgp-nav-item a:hover {
    color: #3182ce;
}

.sgp-nav-item.active a {
    color: #3182ce;
    border-bottom-color: #3182ce;
}

.sgp-tab-pane {
    display: none;
}

.sgp-tab-pane.active {
    display: block;
}

.sgp-overview-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.sgp-overview-card {
    padding: 20px;
    border-radius: 8px;
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    transition: all 0.3s ease;
}

.sgp-overview-card:hover {
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    transform: translateY(-2px);
}

.sgp-card-title {
    margin-top: 0;
    margin-bottom: 15px;
    color: #2c3e50;
    font-size: 1.1rem;
}

.sgp-help-text {
    color: #7f8c8d;
    font-style: italic;
    margin: 10px 0;
}

.sgp-quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
}

.sgp-quick-action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px 10px;
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    color: #374151;
}

.sgp-quick-action-btn:hover {
    background: #f3f4f6;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.sgp-quick-action-btn span {
    margin-top: 5px;
    font-size: 12px;
    text-align: center;
}

.sgp-contracts-header,
.sgp-invoices-header,
.sgp-tickets-header,
.sgp-access-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.sgp-contracts-header h4,
.sgp-invoices-header h4,
.sgp-tickets-header h4,
.sgp-access-header h4 {
    margin: 0;
    color: #2c3e50;
}

.sgp-contracts-actions,
.sgp-invoices-actions,
.sgp-tickets-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.sgp-button {
    display: inline-flex;
    align-items: center;
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.3s ease;
}

.sgp-button-primary {
    background: #3182ce;
    color: white;
}

.sgp-button-primary:hover {
    background: #2c5aa0;
}

.sgp-button-secondary {
    background: #f8f9fa;
    color: #374151;
    border: 1px solid #d1d5db;
}

.sgp-button-secondary:hover {
    background: #e5e7eb;
}

.sgp-select {
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    background: white;
    font-size: 14px;
}

.sgp-loading,
.sgp-initial-loading {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    color: #7f8c8d;
}

.sgp-spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid #f3f3f3;
    border-top: 2px solid #3182ce;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-right: 8px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.sgp-modal {
    display: none;
    position: fixed;
    z-index: 99999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.7);
}

.sgp-modal-content {
    background-color: white;
    margin: 5% auto;
    padding: 20px;
    border-radius: 8px;
    width: 90%;
    max-width: 500px;
    position: relative;
}

.sgp-close-modal {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    color: #aaa;
}

.sgp-close-modal:hover {
    color: #000;
}

.sgp-form-group {
    margin-bottom: 15px;
}

.sgp-form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #374151;
}

.sgp-input,
.sgp-textarea {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 14px;
    box-sizing: border-box;
}

.sgp-input:focus,
.sgp-textarea:focus {
    outline: none;
    border-color: #3182ce;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
}

.sgp-form-actions {
    text-align: right;
    margin-top: 20px;
}

@media (max-width: 768px) {
    .sgp-customer-dashboard {
        padding: 10px;
    }
    
    .sgp-dashboard-header {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }
    
    .sgp-nav-tabs {
        flex-wrap: wrap;
        gap: 5px;
    }
    
    .sgp-nav-item {
        margin-right: 0;
    }
    
    .sgp-overview-grid {
        grid-template-columns: 1fr;
    }
    
    .sgp-contracts-header,
    .sgp-invoices-header,
    .sgp-tickets-header,
    .sgp-access-header {
        flex-direction: column;
        gap: 10px;
        align-items: stretch;
    }
    
    .sgp-contracts-actions,
    .sgp-invoices-actions,
    .sgp-tickets-actions {
        justify-content: center;
    }
    
    .sgp-quick-actions-grid {
        grid-template-columns: 1fr;
    }
}
</style>
<style id="sgp-table-align-style">
.sgp-table, .sgp-invoices-table, .sgp-tickets-table, .sgp-contracts-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}
.sgp-table th, .sgp-table td,
.sgp-invoices-table th, .sgp-invoices-table td,
.sgp-tickets-table th, .sgp-tickets-table td,
.sgp-contracts-table th, .sgp-contracts-table td {
    text-align: center !important;
    vertical-align: middle !important;
}
</style>
<style id="sgp-orange-button-style">
.sgp-button, .sgp-button-primary, .sgp-button-secondary, .sgp-button-tertiary, .sgp-quick-action-btn, button[type=submit], .sgp-btn, .sgp-btn-primary, a.sgp-button, a.sgp-button-primary, a.sgp-button-secondary, a.sgp-button-tertiary {
    background: #444 !important;
    color: #fff !important;
    border: none;
    border-radius: 90px !important;
    font-weight: 700;
    font-size: 1rem;
    padding: 8px 28px;
    box-shadow: none !important;
    transition: background 0.18s, color 0.18s;
    outline: none;
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    gap: 8px;
    letter-spacing: 0.02em;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    text-decoration: none !important;
    vertical-align: middle;
}
.sgp-button:hover, .sgp-button-primary:hover, .sgp-button-secondary:hover, .sgp-button-tertiary:hover, .sgp-quick-action-btn:hover, button[type=submit]:hover, .sgp-btn:hover, .sgp-btn-primary:hover {
    background: #222 !important;
    color: #fff !important;
}
.sgp-button::before, .sgp-button-primary::before, .sgp-button-secondary::before, .sgp-button-tertiary::before, .sgp-quick-action-btn::before, button[type=submit]::before, .sgp-btn::before, .sgp-btn-primary::before,
.sgp-button::after, .sgp-button-primary::after, .sgp-button-secondary::after, .sgp-button-tertiary::after, .sgp-quick-action-btn::after, button[type=submit]::after, .sgp-btn::after, .sgp-btn-primary::after {
    display: none !important;
    content: none !important;
}
.sgp-button:active, .sgp-button-primary:active, .sgp-button-secondary:active, .sgp-button-tertiary:active, .sgp-quick-action-btn:active, button[type=submit]:active, .sgp-btn:active, .sgp-btn-primary:active {
    background: linear-gradient(90deg, #ff9800 0%, #f57c00 100%);
    box-shadow: 0 1px 4px 0 rgba(255,152,0,0.10);
    transform: scale(0.98);
}
.sgp-button[disabled], .sgp-button-primary[disabled], .sgp-button-secondary[disabled], .sgp-button-tertiary[disabled], .sgp-quick-action-btn[disabled], button[type=submit][disabled], .sgp-btn[disabled], .sgp-btn-primary[disabled] {
    opacity: 0.6;
    cursor: not-allowed;
    filter: grayscale(0.2);
}
</style>