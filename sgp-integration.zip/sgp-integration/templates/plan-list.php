<?php
/**
 * Template para listagem de planos disponíveis
 * 
 * Shortcode: [sgp_plans]
 */
if (!defined('ABSPATH')) {
    exit; // Sai se acessado diretamente
}

// Carrega os estilos e scripts necessários
wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');

// Obtém os planos disponíveis (pode ser via shortcode attributes ou API)
$plans = apply_filters('sgp_available_plans', []);
$coverage_id = isset($_GET['coverage_id']) ? absint($_GET['coverage_id']) : 0;
?>

<div class="sgp-plans-container">
    <div class="sgp-plans-header">
        <h2 class="sgp-plans-title">Planos Disponíveis</h2>
        
        <?php if ($coverage_id) : ?>
        <div class="sgp-coverage-info">
            <i class="sgp-icon sgp-icon-check"></i>
            <span>Verificamos que há cobertura em seu endereço</span>
        </div>
        <?php endif; ?>
    </div>

    <!-- Lista de Planos -->
    <div class="sgp-plans-grid">
        <?php if (!empty($plans)) : ?>
            <?php foreach ($plans as $plan) : ?>
                <div class="sgp-plan-card" data-plan-id="<?php echo esc_attr($plan['id']); ?>">
                    <h3 class="sgp-plan-name"><?php echo esc_html($plan['name']); ?></h3>
                    <div class="sgp-plan-price">
                        <span class="sgp-price-value">R$ <?php echo number_format($plan['price'], 2, ',', '.'); ?></span>
                        <span class="sgp-price-period">/mês</span>
                    </div>
                    <div class="sgp-plan-speed">
                        <div class="sgp-speed-item">
                            <i class="sgp-icon sgp-icon-download"></i>
                            <span class="sgp-speed-value"><?php echo esc_html($plan['download_speed']); ?></span>
                            <span class="sgp-speed-unit">Mbps</span>
                        </div>
                        <div class="sgp-speed-item">
                            <i class="sgp-icon sgp-icon-upload"></i>
                            <span class="sgp-speed-value"><?php echo esc_html($plan['upload_speed']); ?></span>
                            <span class="sgp-speed-unit">Mbps</span>
                        </div>
                    </div>
                    <div class="sgp-plan-actions">
                        <button class="sgp-button sgp-button-primary sgp-select-plan">
                            Contratar
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <div class="sgp-no-plans">
                <i class="sgp-icon sgp-icon-warning"></i>
                <p>Nenhum plano disponível para sua região no momento.</p>
                <?php if (!$coverage_id) : ?>
                    <a href="<?php echo esc_url(home_url('/consulta-de-cobertura')); ?>" class="sgp-button sgp-button-primary">
                        Verificar cobertura
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Template para plano selecionado (usado no modal) -->
<script type="text/template" id="sgp-comparison-plan-template">
    <td class="sgp-comparison-plan" data-plan-id="{{id}}">
        <div class="sgp-comparison-plan-header">
            <h4>{{name}}</h4>
            <div class="sgp-comparison-plan-price">R$ {{price}}/mês</div>
        </div>
        <button class="sgp-select-plan-in-comparison sgp-button sgp-button-primary">
            Selecionar
        </button>
    </td>
</script>