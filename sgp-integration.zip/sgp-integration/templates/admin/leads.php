<?php
/**
 * Template de gerenciamento de leads
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Gerenciar Leads SGP', 'sgp-integration'); ?></h1>
    
    <div class="sgp-leads-stats">
        <div class="sgp-stat-box">
            <h3><?php _e('Total de Leads', 'sgp-integration'); ?></h3>
            <span class="sgp-stat-number"><?php echo $total_leads; ?></span>
        </div>
        
        <div class="sgp-stat-box">
            <h3><?php _e('Leads Hoje', 'sgp-integration'); ?></h3>
            <span class="sgp-stat-number"><?php echo count($recent_leads); ?></span>
        </div>
    </div>
    
    <div class="sgp-leads-actions">
        <button type="button" id="export-leads-csv" class="button button-primary">
            <?php _e('Exportar CSV', 'sgp-integration'); ?>
        </button>
        
        <button type="button" id="export-leads-json" class="button button-secondary">
            <?php _e('Exportar JSON', 'sgp-integration'); ?>
        </button>
    </div>
    
    <div class="sgp-recent-leads">
        <h2><?php _e('Leads Recentes', 'sgp-integration'); ?></h2>
        
        <?php if (empty($recent_leads)) : ?>
            <p><?php _e('Nenhum lead encontrado.', 'sgp-integration'); ?></p>
        <?php else : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Nome', 'sgp-integration'); ?></th>
                        <th><?php _e('E-mail', 'sgp-integration'); ?></th>
                        <th><?php _e('Telefone', 'sgp-integration'); ?></th>
                        <th><?php _e('CEP', 'sgp-integration'); ?></th>
                        <th><?php _e('Status', 'sgp-integration'); ?></th>
                        <th><?php _e('Data', 'sgp-integration'); ?></th>
                        <th><?php _e('Ações', 'sgp-integration'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_leads as $lead) : 
                        $meta = get_post_meta($lead->ID);
                    ?>
                        <tr>
                            <td><?php echo esc_html($lead->post_title); ?></td>
                            <td><?php echo esc_html($meta['sgp_email'][0] ?? ''); ?></td>
                            <td><?php echo esc_html($meta['sgp_phone'][0] ?? ''); ?></td>
                            <td><?php echo esc_html($meta['sgp_cep'][0] ?? ''); ?></td>
                            <td>
                                <span class="sgp-status-badge sgp-status-<?php echo esc_attr($meta['sgp_status'][0] ?? 'new'); ?>">
                                    <?php echo esc_html($this->get_status_label($meta['sgp_status'][0] ?? 'new')); ?>
                                </span>
                            </td>
                            <td><?php echo get_the_date('d/m/Y H:i', $lead->ID); ?></td>
                            <td>
                                <a href="<?php echo get_edit_post_link($lead->ID); ?>" class="button button-small">
                                    <?php _e('Editar', 'sgp-integration'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#export-leads-csv').on('click', function() {
        exportLeads('csv');
    });
    
    $('#export-leads-json').on('click', function() {
        exportLeads('json');
    });
    
    function exportLeads(format) {
        const $button = $(event.target);
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.exportingLeads);
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_export_leads',
                format: format,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Cria link de download
                    const link = document.createElement('a');
                    link.href = response.data.download_url;
                    link.download = response.data.filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    alert(response.data.message);
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('<?php _e('Erro na exportação', 'sgp-integration'); ?>');
            },
            complete: function() {
                $button.prop('disabled', false).text(format === 'csv' ? '<?php _e('Exportar CSV', 'sgp-integration'); ?>' : '<?php _e('Exportar JSON', 'sgp-integration'); ?>');
            }
        });
    }
});
</script>

<style>
.sgp-leads-stats {
    display: flex;
    gap: 20px;
    margin: 20px 0;
}

.sgp-stat-box {
    background: #fff;
    border: 1px solid #ddd;
    padding: 20px;
    border-radius: 5px;
    text-align: center;
    min-width: 150px;
}

.sgp-stat-number {
    font-size: 2em;
    font-weight: bold;
    color: #0073aa;
}

.sgp-leads-actions {
    margin: 20px 0;
}

.sgp-status-badge {
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.sgp-status-new {
    background: #e7f3ff;
    color: #0073aa;
}

.sgp-status-contacted {
    background: #fff3cd;
    color: #856404;
}

.sgp-status-converted {
    background: #d4edda;
    color: #155724;
}

.sgp-status-lost {
    background: #f8d7da;
    color: #721c24;
}
</style> 