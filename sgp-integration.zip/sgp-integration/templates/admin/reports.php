<?php
/**
 * Template de relatórios
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Relatórios SGP Integration', 'sgp-integration'); ?></h1>
    
    <div class="sgp-reports-grid">
        <div class="sgp-report-card">
            <h3><?php _e('Leads', 'sgp-integration'); ?></h3>
            <div class="sgp-report-stats">
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Total', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo $stats['total_leads']; ?></span>
                </div>
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Hoje', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo $stats['leads_today']; ?></span>
                </div>
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Este Mês', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo $stats['leads_this_month']; ?></span>
                </div>
            </div>
        </div>
        
        <div class="sgp-report-card">
            <h3><?php _e('Consultas de Cobertura', 'sgp-integration'); ?></h3>
            <div class="sgp-report-stats">
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Cache Ativo', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo $stats['coverage_checks']; ?></span>
                </div>
            </div>
        </div>
        
        <div class="sgp-report-card">
            <h3><?php _e('Sistema', 'sgp-integration'); ?></h3>
            <div class="sgp-report-stats">
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Versão', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo SGP_INTEGRATION_VERSION; ?></span>
                </div>
                <div class="sgp-stat-item">
                    <span class="sgp-stat-label"><?php _e('Cache Ativo', 'sgp-integration'); ?></span>
                    <span class="sgp-stat-value"><?php echo get_option('sgp_cache_time', '3600'); ?>s</span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="sgp-reports-actions">
        <button type="button" id="generate-report" class="button button-primary">
            <?php _e('Gerar Relatório Completo', 'sgp-integration'); ?>
        </button>
        
        <button type="button" id="clear-all-cache" class="button button-secondary">
            <?php _e('Limpar Todo Cache', 'sgp-integration'); ?>
        </button>
    </div>
    
    <div class="sgp-system-info">
        <h3><?php _e('Informações do Sistema', 'sgp-integration'); ?></h3>
        <table class="widefat">
            <tr>
                <td><strong><?php _e('WordPress Version:', 'sgp-integration'); ?></strong></td>
                <td><?php echo get_bloginfo('version'); ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('PHP Version:', 'sgp-integration'); ?></strong></td>
                <td><?php echo PHP_VERSION; ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('Plugin Version:', 'sgp-integration'); ?></strong></td>
                <td><?php echo SGP_INTEGRATION_VERSION; ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('API URL:', 'sgp-integration'); ?></strong></td>
                <td><?php echo get_option('sgp_api_url') ?: __('Não configurado', 'sgp-integration'); ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('Leads Locais:', 'sgp-integration'); ?></strong></td>
                <td><?php echo get_option('sgp_store_leads_locally') ? __('Ativado', 'sgp-integration') : __('Desativado', 'sgp-integration'); ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('Logs:', 'sgp-integration'); ?></strong></td>
                <td><?php echo get_option('sgp_enable_logging') ? __('Ativado', 'sgp-integration') : __('Desativado', 'sgp-integration'); ?></td>
            </tr>
        </table>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#generate-report').on('click', function() {
        const $button = $(this);
        $button.prop('disabled', true).text('<?php _e('Gerando...', 'sgp-integration'); ?>');
        
        // Simula geração de relatório
        setTimeout(function() {
            alert('<?php _e('Relatório gerado com sucesso!', 'sgp-integration'); ?>');
            $button.prop('disabled', false).text('<?php _e('Gerar Relatório Completo', 'sgp-integration'); ?>');
        }, 2000);
    });
    
    $('#clear-all-cache').on('click', function() {
        if (confirm('<?php _e('Tem certeza que deseja limpar todo o cache?', 'sgp-integration'); ?>')) {
            const $button = $(this);
            $button.prop('disabled', true).text(sgpAdminVars.i18n.clearingCache);
            
            $.ajax({
                url: sgpAdminVars.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'sgp_clear_cache',
                    nonce: sgpAdminVars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('<?php _e('Erro ao limpar cache', 'sgp-integration'); ?>');
                },
                complete: function() {
                    $button.prop('disabled', false).text('<?php _e('Limpar Todo Cache', 'sgp-integration'); ?>');
                }
            });
        }
    });
});
</script>

<style>
.sgp-reports-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.sgp-report-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.sgp-report-card h3 {
    margin-top: 0;
    color: #23282d;
    border-bottom: 2px solid #0073aa;
    padding-bottom: 10px;
}

.sgp-report-stats {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.sgp-stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background: #f9f9f9;
    border-radius: 5px;
}

.sgp-stat-label {
    font-weight: 500;
    color: #666;
}

.sgp-stat-value {
    font-size: 1.2em;
    font-weight: bold;
    color: #0073aa;
}

.sgp-reports-actions {
    margin: 30px 0;
    display: flex;
    gap: 10px;
}

.sgp-system-info {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-top: 30px;
}

.sgp-system-info h3 {
    margin-top: 0;
    color: #23282d;
    border-bottom: 2px solid #0073aa;
    padding-bottom: 10px;
}

.sgp-system-info table {
    margin-top: 15px;
}

.sgp-system-info td {
    padding: 8px 12px;
}

.sgp-system-info td:first-child {
    width: 200px;
    font-weight: 500;
}
</style> 