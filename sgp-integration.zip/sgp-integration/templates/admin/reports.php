<?php
/**
 * Template de relatórios completos
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Relatórios', 'sgp-integration'); ?></h1>
    
    <!-- Filtros de Período -->
    <div class="sgp-reports-filters">
        <div class="sgp-filter-card">
            <h3><i class="dashicons dashicons-calendar-alt"></i> Filtrar por Período</h3>
            <div class="sgp-date-filters">
                <div class="sgp-date-group">
                    <label for="start_date">Data Inicial:</label>
                    <input type="date" id="start_date" name="start_date" class="sgp-date-input">
                </div>
                <div class="sgp-date-group">
                    <label for="end_date">Data Final:</label>
                    <input type="date" id="end_date" name="end_date" class="sgp-date-input">
                </div>
                <div class="sgp-date-group">
                    <button type="button" id="filter-reports" class="button button-primary">
                        <i class="dashicons dashicons-search"></i> Filtrar
                    </button>
                    <button type="button" id="reset-filters" class="button button-secondary">
                        <i class="dashicons dashicons-update"></i> Limpar
                    </button>
                </div>
            </div>
            
            <!-- Filtros Rápidos -->
            <div class="sgp-quick-filters">
                <button type="button" class="button sgp-quick-filter" data-period="today">Hoje</button>
                <button type="button" class="button sgp-quick-filter" data-period="week">Esta Semana</button>
                <button type="button" class="button sgp-quick-filter" data-period="month">Este Mês</button>
                <button type="button" class="button sgp-quick-filter" data-period="3months">3 Meses</button>
                <button type="button" class="button sgp-quick-filter" data-period="year">Este Ano</button>
            </div>
        </div>
    </div>

    <!-- Cards de Estatísticas -->
    <div class="sgp-stats-grid">
        <div class="sgp-stat-card sgp-stat-leads">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-groups"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Total de Leads</h3>
                <span class="sgp-stat-number"><?php echo number_format($stats['total_leads']); ?></span>
                <span class="sgp-stat-today">Hoje: <?php echo $stats['leads_today']; ?></span>
            </div>
        </div>
        
        <div class="sgp-stat-card sgp-stat-consultas">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-search"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Total de Consultas</h3>
                <span class="sgp-stat-number"><?php echo number_format($stats['total_consultas']); ?></span>
                <span class="sgp-stat-today">Hoje: <?php echo $stats['consultas_today']; ?></span>
            </div>
        </div>
        
        <div class="sgp-stat-card sgp-stat-aprovadas">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-yes-alt"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Consultas Aprovadas</h3>
                <span class="sgp-stat-number"><?php echo number_format($stats['consultas_aprovadas']); ?></span>
                <span class="sgp-stat-percentage">
                    <?php 
                    $pct_aprovadas = $stats['total_consultas'] > 0 ? round(($stats['consultas_aprovadas'] / $stats['total_consultas']) * 100, 1) : 0;
                    echo $pct_aprovadas . '%';
                    ?>
                </span>
            </div>
        </div>
        
        <div class="sgp-stat-card sgp-stat-conversao">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-chart-line"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Taxa de Conversão</h3>
                <span class="sgp-stat-number"><?php echo $stats['taxa_conversao']; ?>%</span>
                <span class="sgp-stat-label">Leads / Consultas Aprovadas</span>
            </div>
        </div>
        
        <div class="sgp-stat-card sgp-stat-negadas">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-dismiss"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Consultas Negadas</h3>
                <span class="sgp-stat-number"><?php echo number_format($stats['consultas_negadas']); ?></span>
                <span class="sgp-stat-percentage">
                    <?php 
                    $pct_negadas = $stats['total_consultas'] > 0 ? round(($stats['consultas_negadas'] / $stats['total_consultas']) * 100, 1) : 0;
                    echo $pct_negadas . '%';
                    ?>
                </span>
            </div>
        </div>
        
        <div class="sgp-stat-card sgp-stat-mes">
            <div class="sgp-stat-icon">
                <i class="dashicons dashicons-calendar-alt"></i>
            </div>
            <div class="sgp-stat-content">
                <h3>Leads Este Mês</h3>
                <span class="sgp-stat-number"><?php echo number_format($stats['leads_this_month']); ?></span>
                <span class="sgp-stat-label">
                    <?php echo date_i18n('F Y'); ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="sgp-charts-section">
        <div class="sgp-charts-grid">
            <!-- Gráfico de Leads e Consultas por Mês -->
            <div class="sgp-chart-card">
                <div class="sgp-chart-header">
                    <h3><i class="dashicons dashicons-chart-line"></i> Leads e Consultas por Mês</h3>
                    <span class="sgp-chart-subtitle">Últimos 12 meses</span>
                </div>
                <div class="sgp-chart-container">
                    <canvas id="leadsConsultasChart"></canvas>
                </div>
            </div>
            
            <!-- Gráfico de Resultado das Consultas -->
            <div class="sgp-chart-card">
                <div class="sgp-chart-header">
                    <h3><i class="dashicons dashicons-chart-pie"></i> Resultado das Consultas</h3>
                    <span class="sgp-chart-subtitle">Distribuição geral</span>
                </div>
                <div class="sgp-chart-container">
                    <canvas id="resultadoConsultasChart"></canvas>
                </div>
            </div>
            
            <!-- Gráfico de Leads por Cidade -->
            <div class="sgp-chart-card">
                <div class="sgp-chart-header">
                    <h3><i class="dashicons dashicons-location-alt"></i> Leads por Cidade</h3>
                    <span class="sgp-chart-subtitle">Top 10 cidades</span>
                </div>
                <div class="sgp-chart-container">
                    <canvas id="leadsCidadeChart"></canvas>
                </div>
            </div>
            
            <!-- Gráfico de Leads Últimos 30 Dias -->
            <div class="sgp-chart-card">
                <div class="sgp-chart-header">
                    <h3><i class="dashicons dashicons-calendar"></i> Leads Últimos 30 Dias</h3>
                    <span class="sgp-chart-subtitle">Tendência diária</span>
                </div>
                <div class="sgp-chart-container">
                    <canvas id="leads30DiasChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabelas de Dados -->
    <div class="sgp-tables-section">
        <!-- Tabela de Leads -->
        <div class="sgp-table-card">
            <div class="sgp-table-header">
                <h3><i class="dashicons dashicons-groups"></i> Leads Recentes</h3>
                <div class="sgp-table-actions">
                    <button type="button" id="export-leads-csv" class="button">
                        <i class="dashicons dashicons-download"></i> Exportar CSV
                    </button>
                </div>
            </div>
            <div class="sgp-table-container">
                <table class="sgp-data-table" id="leads-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Telefone</th>
                            <th>Cidade</th>
                            <th>CEP</th>
                            <th>Viabilidade</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($filtered_data['leads'])) : ?>
                            <?php foreach ($filtered_data['leads'] as $lead) : ?>
                                <tr>
                                    <td><?php echo $lead->id; ?></td>
                                    <td><?php echo esc_html($lead->nome); ?></td>
                                    <td><?php echo esc_html($lead->email); ?></td>
                                    <td><?php echo esc_html($lead->telefone); ?></td>
                                    <td><?php echo esc_html($lead->cidade); ?></td>
                                    <td><?php echo esc_html($lead->cep); ?></td>
                                    <td>
                                        <span class="sgp-status-badge <?php echo $lead->viabilidade_aprovada ? 'sgp-status-approved' : 'sgp-status-denied'; ?>">
                                            <?php echo $lead->viabilidade_aprovada ? 'Aprovada' : 'Negada'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date_i18n('d/m/Y H:i', strtotime($lead->data_lead)); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="8" class="sgp-no-data">Nenhum lead encontrado</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Tabela de Consultas -->
        <div class="sgp-table-card">
            <div class="sgp-table-header">
                <h3><i class="dashicons dashicons-search"></i> Consultas de Viabilidade</h3>
                <div class="sgp-table-actions">
                    <button type="button" id="export-consultas-csv" class="button">
                        <i class="dashicons dashicons-download"></i> Exportar CSV
                    </button>
                </div>
            </div>
            <div class="sgp-table-container">
                <table class="sgp-data-table" id="consultas-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CEP</th>
                            <th>Endereço</th>
                            <th>Cidade</th>
                            <th>Estado</th>
                            <th>Resultado</th>
                            <th>Detalhes</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($filtered_data['consultas'])) : ?>
                            <?php foreach ($filtered_data['consultas'] as $consulta) : ?>
                                <tr>
                                    <td><?php echo $consulta->id; ?></td>
                                    <td><?php echo esc_html($consulta->cep); ?></td>
                                    <td><?php echo esc_html($consulta->endereco . ', ' . $consulta->numero); ?></td>
                                    <td><?php echo esc_html($consulta->cidade); ?></td>
                                    <td><?php echo esc_html($consulta->estado); ?></td>
                                    <td>
                                        <span class="sgp-status-badge <?php echo $consulta->disponivel ? 'sgp-status-approved' : 'sgp-status-denied'; ?>">
                                            <?php echo $consulta->disponivel ? 'Disponível' : 'Indisponível'; ?>
                                        </span>
                                    </td>
                                    <td class="sgp-details-cell">
                                        <?php if ($consulta->detalhes) : ?>
                                            <span class="sgp-details-preview" title="<?php echo esc_attr($consulta->detalhes); ?>">
                                                <?php echo esc_html(substr($consulta->detalhes, 0, 30) . '...'); ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="sgp-no-details">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date_i18n('d/m/Y H:i', strtotime($consulta->data_consulta)); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="8" class="sgp-no-data">Nenhuma consulta encontrada</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Incluir Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
jQuery(document).ready(function($) {
    // Dados para gráficos
    const chartsData = <?php echo json_encode($charts_data); ?>;
    
    // Configuração dos gráficos
    Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    Chart.defaults.font.size = 12;
    
    // ==================== GRÁFICO DE LEADS E CONSULTAS POR MÊS ====================
    const leadsConsultasCtx = document.getElementById('leadsConsultasChart').getContext('2d');
    
    // Preparar dados para o gráfico
    const meses = [];
    const leadsData = [];
    const consultasData = [];
    
    // Criar array de últimos 12 meses
    for (let i = 11; i >= 0; i--) {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const mesAno = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
        meses.push(date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }));
        
        // Encontrar dados correspondentes
        const leadMes = chartsData.leads_por_mes.find(item => item.mes === mesAno);
        const consultaMes = chartsData.consultas_por_mes.find(item => item.mes === mesAno);
        
        leadsData.push(leadMes ? parseInt(leadMes.total) : 0);
        consultasData.push(consultaMes ? parseInt(consultaMes.total) : 0);
    }
    
    new Chart(leadsConsultasCtx, {
        type: 'line',
        data: {
            labels: meses,
            datasets: [
                {
                    label: 'Leads',
                    data: leadsData,
                    borderColor: '#0073aa',
                    backgroundColor: 'rgba(0, 115, 170, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3
                },
                {
                    label: 'Consultas',
                    data: consultasData,
                    borderColor: '#00a32a',
                    backgroundColor: 'rgba(0, 163, 42, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
    
    // ==================== GRÁFICO DE RESULTADO DAS CONSULTAS ====================
    const resultadoCtx = document.getElementById('resultadoConsultasChart').getContext('2d');
    
    const resultadoLabels = chartsData.consultas_por_resultado.map(item => item.resultado);
    const resultadoData = chartsData.consultas_por_resultado.map(item => parseInt(item.total));
    
    new Chart(resultadoCtx, {
        type: 'doughnut',
        data: {
            labels: resultadoLabels,
            datasets: [{
                data: resultadoData,
                backgroundColor: ['#00a32a', '#d63638'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    
    // ==================== GRÁFICO DE LEADS POR CIDADE ====================
    const cidadeCtx = document.getElementById('leadsCidadeChart').getContext('2d');
    
    const cidadeLabels = chartsData.leads_por_cidade.map(item => item.cidade);
    const cidadeData = chartsData.leads_por_cidade.map(item => parseInt(item.total));
    
    new Chart(cidadeCtx, {
        type: 'bar',
        data: {
            labels: cidadeLabels,
            datasets: [{
                label: 'Leads',
                data: cidadeData,
                backgroundColor: '#0073aa',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                },
                x: {
                    ticks: {
                        maxRotation: 45
                    }
                }
            }
        }
    });
    
    // ==================== GRÁFICO DE LEADS ÚLTIMOS 30 DIAS ====================
    const dias30Ctx = document.getElementById('leads30DiasChart').getContext('2d');
    
    // Preparar dados dos últimos 30 dias
    const dias = [];
    const leadsUltimos30 = [];
    
    for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dataStr = date.getFullYear() + '-' + 
                       String(date.getMonth() + 1).padStart(2, '0') + '-' + 
                       String(date.getDate()).padStart(2, '0');
        
        dias.push(date.getDate() + '/' + (date.getMonth() + 1));
        
        const leadDia = chartsData.leads_ultimos_30_dias.find(item => item.data === dataStr);
        leadsUltimos30.push(leadDia ? parseInt(leadDia.total) : 0);
    }
    
    new Chart(dias30Ctx, {
        type: 'line',
        data: {
            labels: dias,
            datasets: [{
                label: 'Leads',
                data: leadsUltimos30,
                borderColor: '#0073aa',
                backgroundColor: 'rgba(0, 115, 170, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.3,
                pointRadius: 3,
                pointHoverRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                },
                x: {
                    ticks: {
                        maxTicksLimit: 10
                    }
                }
            }
        }
    });
    
    // ==================== FILTROS DE DATA ====================
    
    // Filtros rápidos
    $('.sgp-quick-filter').on('click', function() {
        $('.sgp-quick-filter').removeClass('button-primary').addClass('button-secondary');
        $(this).removeClass('button-secondary').addClass('button-primary');
        
        const period = $(this).data('period');
        const today = new Date();
        let startDate, endDate = today.toISOString().split('T')[0];
        
        switch(period) {
            case 'today':
                startDate = endDate;
                break;
            case 'week':
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay());
                startDate = weekStart.toISOString().split('T')[0];
                break;
            case 'month':
                startDate = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-01';
                break;
            case '3months':
                const threeMonthsAgo = new Date(today);
                threeMonthsAgo.setMonth(today.getMonth() - 3);
                startDate = threeMonthsAgo.toISOString().split('T')[0];
                break;
            case 'year':
                startDate = today.getFullYear() + '-01-01';
                break;
        }
        
        $('#start_date').val(startDate);
        $('#end_date').val(endDate);
        
        filterReports();
    });
    
    // Filtro customizado
    $('#filter-reports').on('click', function() {
        $('.sgp-quick-filter').removeClass('button-primary').addClass('button-secondary');
        filterReports();
    });
    
    // Reset filtros
    $('#reset-filters').on('click', function() {
        $('#start_date').val('');
        $('#end_date').val('');
        $('.sgp-quick-filter').removeClass('button-primary').addClass('button-secondary');
        location.reload();
    });
    
    function filterReports() {
        const startDate = $('#start_date').val();
        const endDate = $('#end_date').val();
        
        if (!startDate || !endDate) {
            alert('Selecione as datas de início e fim');
            return;
        }
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_filter_reports',
                start_date: startDate,
                end_date: endDate,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateTables(response.data);
                } else {
                    alert('Erro ao filtrar dados');
                }
            }
        });
    }
    
    function updateTables(data) {
        // Atualizar tabela de leads
        const leadsTableBody = $('#leads-table tbody');
        leadsTableBody.empty();
        
        if (data.leads.length > 0) {
            data.leads.forEach(function(lead) {
                const viabilidadeClass = lead.viabilidade_aprovada == 1 ? 'sgp-status-approved' : 'sgp-status-denied';
                const viabilidadeText = lead.viabilidade_aprovada == 1 ? 'Aprovada' : 'Negada';
                const dataFormatada = new Date(lead.data_lead).toLocaleDateString('pt-BR') + ' ' + 
                                    new Date(lead.data_lead).toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'});
                
                leadsTableBody.append(`
                    <tr>
                        <td>${lead.id}</td>
                        <td>${lead.nome}</td>
                        <td>${lead.email}</td>
                        <td>${lead.telefone}</td>
                        <td>${lead.cidade}</td>
                        <td>${lead.cep}</td>
                        <td><span class="sgp-status-badge ${viabilidadeClass}">${viabilidadeText}</span></td>
                        <td>${dataFormatada}</td>
                    </tr>
                `);
            });
        } else {
            leadsTableBody.append('<tr><td colspan="8" class="sgp-no-data">Nenhum lead encontrado no período</td></tr>');
        }
        
        // Atualizar tabela de consultas
        const consultasTableBody = $('#consultas-table tbody');
        consultasTableBody.empty();
        
        if (data.consultas.length > 0) {
            data.consultas.forEach(function(consulta) {
                const disponivelClass = consulta.disponivel == 1 ? 'sgp-status-approved' : 'sgp-status-denied';
                const disponivelText = consulta.disponivel == 1 ? 'Disponível' : 'Indisponível';
                const dataFormatada = new Date(consulta.data_consulta).toLocaleDateString('pt-BR') + ' ' + 
                                    new Date(consulta.data_consulta).toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'});
                const detalhes = consulta.detalhes ? consulta.detalhes.substring(0, 30) + '...' : '-';
                
                consultasTableBody.append(`
                    <tr>
                        <td>${consulta.id}</td>
                        <td>${consulta.cep}</td>
                        <td>${consulta.endereco}, ${consulta.numero}</td>
                        <td>${consulta.cidade}</td>
                        <td>${consulta.estado}</td>
                        <td><span class="sgp-status-badge ${disponivelClass}">${disponivelText}</span></td>
                        <td class="sgp-details-cell"><span class="sgp-details-preview" title="${consulta.detalhes || ''}">${detalhes}</span></td>
                        <td>${dataFormatada}</td>
                    </tr>
                `);
            });
        } else {
            consultasTableBody.append('<tr><td colspan="8" class="sgp-no-data">Nenhuma consulta encontrada no período</td></tr>');
        }
    }
    
    // ==================== EXPORTAÇÕES ====================
    
    $('#export-leads-csv').on('click', function() {
        exportData('leads');
    });
    
    $('#export-consultas-csv').on('click', function() {
        exportData('consultas');
    });
    
    function exportData(type) {
        const startDate = $('#start_date').val();
        const endDate = $('#end_date').val();
        
        let url = sgpAdminVars.ajaxUrl + '?action=sgp_export_' + type + '_csv&nonce=' + sgpAdminVars.nonce;
        
        if (startDate && endDate) {
            url += '&start_date=' + startDate + '&end_date=' + endDate;
        }
        
        window.open(url, '_blank');
    }
});
</script>

<style>
/* ==================== ESTILOS GERAIS ==================== */
.sgp-reports-filters {
    margin-bottom: 30px;
}

.sgp-filter-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.sgp-filter-card h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #23282d;
    font-size: 16px;
}

.sgp-filter-card h3 i {
    margin-right: 8px;
    color: #0073aa;
}

.sgp-date-filters {
    display: flex;
    align-items: end;
    gap: 15px;
    margin-bottom: 15px;
    flex-wrap: wrap;
}

.sgp-date-group {
    display: flex;
    flex-direction: column;
    min-width: 140px;
}

.sgp-date-group label {
    font-weight: 500;
    margin-bottom: 5px;
    color: #666;
    font-size: 13px;
}

.sgp-date-input {
    padding: 6px 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 13px;
}

.sgp-quick-filters {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.sgp-quick-filter {
    font-size: 12px !important;
    padding: 4px 12px !important;
    height: 28px !important;
}

/* ==================== CARDS DE ESTATÍSTICAS ==================== */
.sgp-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.sgp-stat-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}

.sgp-stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.sgp-stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    font-size: 24px;
}

.sgp-stat-leads .sgp-stat-icon {
    background: rgba(0, 115, 170, 0.1);
    color: #0073aa;
}

.sgp-stat-consultas .sgp-stat-icon {
    background: rgba(0, 163, 42, 0.1);
    color: #00a32a;
}

.sgp-stat-aprovadas .sgp-stat-icon {
    background: rgba(0, 163, 42, 0.1);
    color: #00a32a;
}

.sgp-stat-conversao .sgp-stat-icon {
    background: rgba(255, 193, 7, 0.1);
    color: #ffc107;
}

.sgp-stat-negadas .sgp-stat-icon {
    background: rgba(214, 54, 56, 0.1);
    color: #d63638;
}

.sgp-stat-mes .sgp-stat-icon {
    background: rgba(156, 39, 176, 0.1);
    color: #9c27b0;
}

.sgp-stat-content h3 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #666;
    font-weight: 500;
}

.sgp-stat-number {
    display: block;
    font-size: 28px;
    font-weight: bold;
    color: #23282d;
    line-height: 1;
}

.sgp-stat-today,
.sgp-stat-percentage,
.sgp-stat-label {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 4px;
}

/* ==================== GRÁFICOS ==================== */
.sgp-charts-section {
    margin-bottom: 30px;
}

.sgp-charts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
}

.sgp-chart-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.sgp-chart-header {
    margin-bottom: 15px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.sgp-chart-header h3 {
    margin: 0;
    font-size: 16px;
    color: #23282d;
}

.sgp-chart-header h3 i {
    margin-right: 8px;
    color: #0073aa;
}

.sgp-chart-subtitle {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 4px;
}

.sgp-chart-container {
    height: 300px;
    position: relative;
}

/* ==================== TABELAS ==================== */
.sgp-tables-section {
    display: flex;
    flex-direction: column;
    gap: 30px;
}

.sgp-table-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.sgp-table-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.sgp-table-header h3 {
    margin: 0;
    font-size: 16px;
    color: #23282d;
}

.sgp-table-header h3 i {
    margin-right: 8px;
    color: #0073aa;
}

.sgp-table-actions {
    display: flex;
    gap: 10px;
}

.sgp-table-container {
    overflow-x: auto;
    max-height: 500px;
    overflow-y: auto;
}

.sgp-data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.sgp-data-table th {
    background: #f9f9f9;
    padding: 12px 8px;
    text-align: left;
    font-weight: 600;
    color: #23282d;
    border-bottom: 2px solid #ddd;
    position: sticky;
    top: 0;
    z-index: 1;
}

.sgp-data-table td {
    padding: 10px 8px;
    border-bottom: 1px solid #eee;
    vertical-align: top;
}

.sgp-data-table tr:hover {
    background: #f9f9f9;
}

.sgp-no-data {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 30px !important;
}

.sgp-status-badge {
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.sgp-status-approved {
    background: rgba(0, 163, 42, 0.1);
    color: #00a32a;
    border: 1px solid rgba(0, 163, 42, 0.3);
}

.sgp-status-denied {
    background: rgba(214, 54, 56, 0.1);
    color: #d63638;
    border: 1px solid rgba(214, 54, 56, 0.3);
}

.sgp-details-cell {
    max-width: 150px;
}

.sgp-details-preview {
    display: block;
    cursor: help;
    color: #666;
    font-size: 12px;
}

.sgp-no-details {
    color: #ccc;
    font-style: italic;
}

/* ==================== RESPONSIVIDADE ==================== */
@media (max-width: 768px) {
    .sgp-stats-grid {
        grid-template-columns: 1fr;
    }
    
    .sgp-charts-grid {
        grid-template-columns: 1fr;
    }
    
    .sgp-date-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .sgp-date-group {
        min-width: auto;
    }
    
    .sgp-table-header {
        flex-direction: column;
        align-items: stretch;
        gap: 15px;
    }
    
    .sgp-table-actions {
        justify-content: center;
    }
}
</style>
</code_block_to_apply_changes_from>