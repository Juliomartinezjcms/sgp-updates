<?php
/**
 * Template de configurações administrativas
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Configurações SGP Integration', 'sgp-integration'); ?></h1>
    
    <?php settings_errors('sgp_integration'); ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('sgp_integration_options'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="sgp_api_url"><?php _e('URL da API SGP', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="url" 
                           id="sgp_api_url" 
                           name="sgp_api_url" 
                           value="<?php echo esc_attr($api_url); ?>" 
                           class="regular-text"
                           placeholder="https://demo.sgp.net.br">
                    <p class="description">
                        <?php _e('URL base da API do Sistema de Gerenciamento de Provedores', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="sgp_api_token"><?php _e('Token da API', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="text" 
                           id="sgp_api_token" 
                           name="sgp_api_token" 
                           value="<?php echo esc_attr($api_token); ?>" 
                           class="regular-text"
                           placeholder="Cole aqui o token fornecido pela SGP">
                    <p class="description">
                        <?php _e('Token fixo fornecido pela SGP para autenticação nas requisições.', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_api_user"><?php _e('Usuário SGP (Basic Auth)', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="text" id="sgp_api_user" name="sgp_api_user" value="<?php echo esc_attr($api_user); ?>" class="regular-text" placeholder="Usuário da API SGP">
                    <p class="description"><?php _e('Usuário para autenticação Basic Auth na API SGP.', 'sgp-integration'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="sgp_api_pass"><?php _e('Senha SGP (Basic Auth)', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="password" id="sgp_api_pass" name="sgp_api_pass" value="<?php echo esc_attr($api_pass); ?>" class="regular-text" placeholder="Senha da API SGP">
                    <p class="description"><?php _e('Senha para autenticação Basic Auth na API SGP.', 'sgp-integration'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Testar Conexão', 'sgp-integration'); ?></th>
                <td>
                    <button type="button" id="test-api-connection" class="button button-secondary">
                        <?php _e('Testar Conexão', 'sgp-integration'); ?>
                    </button>
                    <span id="connection-status" style="margin-left: 10px;"></span>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Configurações Gerais', 'sgp-integration'); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" 
                                   name="sgp_store_leads_locally" 
                                   value="1" 
                                   <?php checked($store_leads, '1'); ?>>
                            <?php _e('Armazenar leads localmente', 'sgp-integration'); ?>
                        </label>
                        <br>
                        <label>
                            <input type="checkbox" 
                                   name="sgp_enable_logging" 
                                   value="1" 
                                   <?php checked($enable_logging, '1'); ?>>
                            <?php _e('Ativar logs do sistema', 'sgp-integration'); ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_cache_time"><?php _e('Tempo de Cache (segundos)', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="number" 
                           id="sgp_cache_time" 
                           name="sgp_cache_time" 
                           value="<?php echo esc_attr($cache_time); ?>" 
                           min="300" 
                           max="86400" 
                           class="small-text">
                    <p class="description">
                        <?php _e('Tempo em segundos para cache das consultas à API (mín: 300, máx: 86400)', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_notification_email"><?php _e('E-mail de Notificação', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="email" 
                           id="sgp_notification_email" 
                           name="sgp_notification_email" 
                           value="<?php echo esc_attr($notification_email); ?>" 
                           class="regular-text">
                    <p class="description">
                        <?php _e('E-mail para receber notificações de novos leads', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_google_maps_key"><?php _e('Chave da API Google Maps', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="text" id="sgp_google_maps_key" name="sgp_google_maps_key" value="<?php echo esc_attr($google_maps_key); ?>" class="regular-text" placeholder="Chave da API Google Maps">
                    <p class="description"><?php _e('Chave da API Google Maps para geocodificação de endereços.', 'sgp-integration'); ?></p>
                </td>
            </tr>
        </table>
        
        <h2><?php _e('Configurações de Segurança Avançada', 'sgp-integration'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Segurança', 'sgp-integration'); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" 
                                   name="sgp_force_https" 
                                   value="1" 
                                   <?php checked($force_https, '1'); ?>>
                            <?php _e('Forçar HTTPS (recomendado para produção)', 'sgp-integration'); ?>
                        </label>
                        <br>
                        <label>
                            <input type="checkbox" 
                                   name="sgp_security_headers" 
                                   value="1" 
                                   <?php checked($security_headers, '1'); ?>>
                            <?php _e('Adicionar headers de segurança', 'sgp-integration'); ?>
                        </label>
                        <br>
                        <label>
                            <input type="checkbox" 
                                   name="sgp_enable_2fa" 
                                   value="1" 
                                   <?php checked($enable_2fa, '1'); ?>>
                            <?php _e('Ativar autenticação de dois fatores (futuro)', 'sgp-integration'); ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_ip_whitelist"><?php _e('Whitelist de IPs', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <textarea id="sgp_ip_whitelist" 
                              name="sgp_ip_whitelist" 
                              rows="3" 
                              class="large-text"
                              placeholder="192.168.1.1, 10.0.0.1"><?php echo esc_textarea($ip_whitelist); ?></textarea>
                    <p class="description">
                        <?php _e('IPs permitidos (um por linha ou separados por vírgula). Deixe vazio para permitir todos.', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="sgp_session_timeout"><?php _e('Timeout de Sessão (segundos)', 'sgp-integration'); ?></label>
                </th>
                <td>
                    <input type="number" 
                           id="sgp_session_timeout" 
                           name="sgp_session_timeout" 
                           value="<?php echo esc_attr($session_timeout); ?>" 
                           min="300" 
                           max="86400" 
                           class="small-text">
                    <p class="description">
                        <?php _e('Tempo máximo de sessão ativa (mín: 300, máx: 86400)', 'sgp-integration'); ?>
                    </p>
                </td>
            </tr>
        </table>
        
        <h2><?php _e('Atualização do Plugin', 'sgp-integration'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Status da Versão', 'sgp-integration'); ?></th>
                <td>
                    <div id="version-status">
                        <p><strong><?php _e('Versão Atual:', 'sgp-integration'); ?></strong> <?php echo SGP_INTEGRATION_VERSION; ?></p>
                        <button type="button" id="check-updates" class="button button-secondary">
                            <?php _e('Verificar Atualizações', 'sgp-integration'); ?>
                        </button>
                        <span id="update-status" style="margin-left: 10px;"></span>
                    </div>
                </td>
            </tr>
            
            <tr id="update-available-row" style="display: none;">
                <th scope="row"><?php _e('Atualização Disponível', 'sgp-integration'); ?></th>
                <td>
                    <div id="update-info">
                        <p><strong><?php _e('Nova Versão:', 'sgp-integration'); ?></strong> <span id="new-version"></span></p>
                        <p><strong><?php _e('Data de Lançamento:', 'sgp-integration'); ?></strong> <span id="release-date"></span></p>
                        <p><strong><?php _e('Changelog:', 'sgp-integration'); ?></strong></p>
                        <div id="changelog" style="background: #f9f9f9; padding: 10px; border-left: 4px solid #0073aa; margin: 10px 0;"></div>
                        <button type="button" id="update-plugin" class="button button-primary">
                            <?php _e('Atualizar Plugin', 'sgp-integration'); ?>
                        </button>
                        <span id="update-progress" style="margin-left: 10px;"></span>
                    </div>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" 
                   name="submit" 
                   id="submit" 
                   class="button button-primary" 
                   value="<?php _e('Salvar Configurações', 'sgp-integration'); ?>">
            
            <button type="button" id="clear-cache" class="button button-secondary" style="margin-left: 10px;">
                <?php _e('Limpar Cache', 'sgp-integration'); ?>
            </button>
        </p>
    </form>
    
    <div class="sgp-admin-info">
        <h3><?php _e('Informações do Plugin', 'sgp-integration'); ?></h3>
        <p><strong><?php _e('Versão:', 'sgp-integration'); ?></strong> <?php echo SGP_INTEGRATION_VERSION; ?></p>
        <p><strong><?php _e('Shortcodes Disponíveis:', 'sgp-integration'); ?></strong></p>
        <ul>
            <li><code>[sgp_customer_panel]</code> - <?php _e('Painel do cliente com login', 'sgp-integration'); ?></li>
            <li><code>[sgp_availability_form]</code> - <?php _e('Formulário de consulta de disponibilidade', 'sgp-integration'); ?></li>
            <li><code>[sgp_plan_list]</code> - <?php _e('Lista de planos disponíveis', 'sgp-integration'); ?></li>
        </ul>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#test-api-connection').on('click', function() {
        var apiUrl = $('#sgp_api_url').val();
        var apiToken = $('#sgp_api_token').val();
        $('#connection-status').text('');
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'sgp_test_api_connection',
                api_url: apiUrl,
                api_token: apiToken,
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#connection-status').html('<span style="color:green;">✓ ' + response.data.message + '</span>');
                } else {
                    $('#connection-status').html('<span style="color:red;">X ' + response.data.message + '</span>');
                }
            },
            error: function() {
                $('#connection-status').html('<span style="color:red;">X Erro inesperado.</span>');
            }
        });
    });
    
    $('#clear-cache').on('click', function() {
        const $button = $(this);
        
        $button.prop('disabled', true).text(sgpAdminVars.i18n.clearingCache);
        
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_clear_cache',
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('<?php _e('Erro ao limpar cache', 'sgp-integration'); ?>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Limpar Cache', 'sgp-integration'); ?>');
            }
        });
    });
    
    // Verificar atualizações
    $('#check-updates').on('click', function() {
        const $button = $(this);
        const $status = $('#update-status');
        $button.prop('disabled', true).text('<?php _e('Verificando...', 'sgp-integration'); ?>');
        $status.html('');
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_check_updates',
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    if (response.data.update_available) {
                        $status.html('<span style="color:orange;">⚠ <?php _e('Atualização disponível!', 'sgp-integration'); ?></span>');
                        $('#new-version').text(response.data.new_version);
                        $('#release-date').text(response.data.release_date);
                        $('#changelog').html(response.data.changelog);
                        $('#update-available-row').show();
                    } else {
                        $status.html('<span style="color:green;">✓ <?php _e('Plugin atualizado!', 'sgp-integration'); ?></span>');
                        $('#update-available-row').hide();
                    }
                } else {
                    $status.html('<span style="color:red;">X ' + response.data.message + '</span>');
                    $('#update-available-row').hide();
                }
            },
            error: function(xhr, status, error) {
                $status.html('<span style="color:red;">X <?php _e('Erro ao verificar atualizações', 'sgp-integration'); ?></span>');
                $('#update-available-row').hide();
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Verificar Atualizações', 'sgp-integration'); ?>');
            }
        });
    });
    
    // Atualizar plugin
    $('#update-plugin').on('click', function() {
        const $button = $(this);
        const $progress = $('#update-progress');
        if (!confirm('<?php _e('Tem certeza que deseja atualizar o plugin? Esta ação não pode ser desfeita.', 'sgp-integration'); ?>')) {
            return;
        }
        $button.prop('disabled', true).text('<?php _e('Atualizando...', 'sgp-integration'); ?>');
        $progress.html('');
        $.ajax({
            url: sgpAdminVars.ajaxUrl,
            type: 'POST',
            data: {
                action: 'sgp_update_plugin',
                nonce: sgpAdminVars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $progress.html('<span style="color:green;">✓ ' + response.data.message + '</span>');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $progress.html('<span style="color:red;">X ' + response.data.message + '</span>');
                }
            },
            error: function(xhr, status, error) {
                $progress.html('<span style="color:red;">X <?php _e('Erro ao atualizar plugin', 'sgp-integration'); ?></span>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Atualizar Plugin', 'sgp-integration'); ?>');
            }
        });
    });
});
</script> 