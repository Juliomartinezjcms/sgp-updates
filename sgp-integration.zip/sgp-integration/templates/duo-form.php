<?php
if (!defined('ABSPATH')) exit;

wp_enqueue_style('sgp-integration-frontend');
wp_enqueue_script('sgp-integration-frontend');

// Opções do widget Elementor, se existirem
$opts = get_query_var('sgp_duo_form_opts', []);
$titulo_viabilidade = !empty($opts['titulo_viabilidade']) ? $opts['titulo_viabilidade'] : '1. Verifique a disponibilidade';
$titulo_lead = !empty($opts['titulo_lead']) ? $opts['titulo_lead'] : '2. Cadastre seu interesse';
$texto_botao_verificar = !empty($opts['texto_botao_verificar']) ? $opts['texto_botao_verificar'] : 'Verificar disponibilidade';
$texto_botao_avancar = !empty($opts['texto_botao_avancar']) ? $opts['texto_botao_avancar'] : 'Avançar';
$texto_botao_lead = !empty($opts['texto_botao_lead']) ? $opts['texto_botao_lead'] : 'Receber Atendimento';
$texto_termo = !empty($opts['texto_termo']) ? $opts['texto_termo'] : 'Concordo com o <a href="#">tratamento dos dados pessoais</a> e autorizo o contato para ofertas comerciais*';

// Cores dos efeitos especiais (se definidas no widget)
$button_next_bg_color = !empty($opts['button_next_bg_color']) ? $opts['button_next_bg_color'] : '';
$button_next_bg_color_secondary = !empty($opts['button_next_bg_color_secondary']) ? $opts['button_next_bg_color_secondary'] : '';
$button_next_pulse_color = !empty($opts['button_next_pulse_color']) ? $opts['button_next_pulse_color'] : '';

// Configurações do efeito neon
$neon_enable = !empty($opts['button_neon_enable']) ? $opts['button_neon_enable'] : '';
$neon_color = !empty($opts['button_neon_color']) ? $opts['button_neon_color'] : '';
$neon_intensity = !empty($opts['button_neon_intensity']['size']) ? $opts['button_neon_intensity']['size'] : 15;
$neon_animation = !empty($opts['button_neon_animation']) ? $opts['button_neon_animation'] : '';
?>
<div class="sgp-duo-form-container">
    <!-- Container das Etapas -->
    <div class="sgp-steps-container">
        <!-- Etapa 1: Viabilidade -->
        <div class="sgp-step-wrapper sgp-step-active" id="sgp-step-1">
            <form id="sgp-duo-viabilidade-form" class="sgp-ajax-form sgp-duo-step" method="post" autocomplete="off">
                <h3><?php echo esc_html($titulo_viabilidade); ?></h3>
                
                <div class="sgp-form-2col-row">
                    <div class="sgp-form-group">
                        <label for="duo-street">Rua/Avenida*</label>
                        <input type="text" id="duo-street" name="street" class="sgp-input" placeholder="Nome da rua ou avenida" required>
                    </div>
                    <div class="sgp-form-group">
                        <label for="duo-number">Número*</label>
                        <input type="text" id="duo-number" name="number" class="sgp-input" placeholder="123" required>
                    </div>
                </div>
                
                <div class="sgp-form-2col-row">
                    <div class="sgp-form-group">
                        <label for="duo-cep">CEP*</label>
                        <input type="text" id="duo-cep" name="cep" class="sgp-input sgp-mask-cep" placeholder="00000-000" required maxlength="9">
                        <small class="sgp-help-text">Digite o CEP para preenchimento automático</small>
                    </div>
                    <div class="sgp-form-group">
                        <label for="duo-neighborhood">Bairro*</label>
                        <input type="text" id="duo-neighborhood" name="neighborhood" class="sgp-input" placeholder="Nome do bairro" required>
                    </div>
                </div>
                
                <div class="sgp-form-2col-row">
                    <div class="sgp-form-group">
                        <label for="duo-city">Cidade*</label>
                        <input type="text" id="duo-city" name="city" class="sgp-input" placeholder="Nome da cidade" required>
                    </div>
                    <div class="sgp-form-group">
                        <label for="duo-state">Estado*</label>
                        <select id="duo-state" name="state" class="sgp-input" required>
                            <option value="">Selecione o estado</option>
                            <option value="AC">Acre</option><option value="AL">Alagoas</option><option value="AP">Amapá</option><option value="AM">Amazonas</option><option value="BA">Bahia</option><option value="CE">Ceará</option><option value="DF">Distrito Federal</option><option value="ES">Espírito Santo</option><option value="GO">Goiás</option><option value="MA">Maranhão</option><option value="MT">Mato Grosso</option><option value="MS">Mato Grosso do Sul</option><option value="MG">Minas Gerais</option><option value="PA">Pará</option><option value="PB">Paraíba</option><option value="PR">Paraná</option><option value="PE">Pernambuco</option><option value="PI">Piauí</option><option value="RJ">Rio de Janeiro</option><option value="RN">Rio Grande do Norte</option><option value="RS">Rio Grande do Sul</option><option value="RO">Rondônia</option><option value="RR">Roraima</option><option value="SC">Santa Catarina</option><option value="SP">São Paulo</option><option value="SE">Sergipe</option><option value="TO">Tocantins</option>
                        </select>
                    </div>
                </div>
                
                <div class="sgp-form-group sgp-form-checkbox">
                    <label class="sgp-checkbox-label">
                        <input type="checkbox" id="duo-terms" name="terms" required>
                        <span class="sgp-checkbox-text"><?php echo $texto_termo; ?></span>
                    </label>
                </div>
                
                <div class="sgp-form-actions">
                    <button type="submit" id="sgp-duo-verificar-btn" class="sgp-button sgp-button-primary">
                        <span class="sgp-button-text"><?php echo esc_html($texto_botao_verificar); ?></span>
                        <span class="sgp-spinner" style="display:none;"></span>
                    </button>
                </div>
                
                <input type="hidden" name="action" value="check_coverage">
                <?php wp_nonce_field('sgp-integration-nonce', 'nonce'); ?>
            </form>

            <div id="sgp-duo-coverage-results" class="sgp-results-container sgp-results-minimal" style="display:none;">
                <div class="sgp-results-body">
                    <div id="sgp-duo-coverage-status" class="sgp-status-message sgp-status-success sgp-status-minimal" style="text-align:center;">
                        <span class="sgp-status-icon" style="font-size:2rem;vertical-align:middle;">✅</span>
                        <span class="sgp-status-text" style="font-size:1.2rem;font-weight:600;margin-left:0.5rem;">Atendemos sua região!</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Etapa 2: Lead -->
        <div class="sgp-step-wrapper" id="sgp-step-2">
            <form id="sgp-duo-lead-form" class="sgp-ajax-form sgp-duo-step" method="post">
                <h3><?php echo esc_html($titulo_lead); ?></h3>
                
                <div class="sgp-form-group">
                    <label for="duo-lead-nome">Nome*</label>
                    <input type="text" id="duo-lead-nome" name="nome" class="sgp-input" placeholder="Seu nome completo" required>
                </div>
                
                <div class="sgp-form-group">
                    <label for="duo-lead-telefone">Telefone*</label>
                    <input type="text" id="duo-lead-telefone" name="telefone" class="sgp-input sgp-mask-phone" placeholder="(00) 00000-0000" required>
                </div>
                
                <div class="sgp-form-group">
                    <label for="duo-lead-email">Email*</label>
                    <input type="email" id="duo-lead-email" name="email" class="sgp-input" placeholder="seu@email.com" required>
                </div>
                
                <div class="sgp-form-actions">
                    <button type="submit" class="sgp-button sgp-button-primary">
                        <span class="sgp-button-text"><?php echo esc_html($texto_botao_lead); ?></span>
                        <span class="sgp-spinner" style="display:none;"></span>
                    </button>
                </div>
                
                <input type="hidden" name="action" value="create_lead">
                <?php wp_nonce_field('sgp-integration-nonce', 'nonce'); ?>
            </form>
            
            <div id="sgp-duo-lead-resultado" style="margin:20px 0;"></div>
        </div>
    </div>
</div>

<script>
jQuery(function($){
    // Cores dos efeitos especiais vindas do widget
    const nextBgColor = '<?php echo esc_js($button_next_bg_color); ?>';
    const nextBgColorSecondary = '<?php echo esc_js($button_next_bg_color_secondary); ?>';
    const nextPulseColor = '<?php echo esc_js($button_next_pulse_color); ?>';
    
    // Configurações do efeito neon
    const neonEnable = '<?php echo esc_js($neon_enable); ?>';
    const neonColor = '<?php echo esc_js($neon_color); ?>';
    const neonIntensity = <?php echo intval($neon_intensity); ?>;
    const neonAnimation = '<?php echo esc_js($neon_animation); ?>';
    
    // Aplica efeito neon se estiver habilitado
    if (neonEnable === 'yes' && neonColor) {
        applyNeonEffect();
    }
    
    // Função para aplicar efeito neon
    function applyNeonEffect() {
        // Adiciona classe ao container para indicar que neon está ativo
        $('.sgp-duo-form-container').addClass('neon-enabled');
        
        const neonCSS = `
            .sgp-duo-form-container .sgp-button {
                box-shadow: 
                    0 0 5px ${neonColor}40,
                    0 0 10px ${neonColor}40,
                    0 0 ${neonIntensity}px ${neonColor}60,
                    0 0 ${neonIntensity * 2}px ${neonColor}40 !important;
                border: 1px solid ${neonColor}80 !important;
                text-shadow: 0 0 5px ${neonColor}60 !important;
            }
            
            .sgp-duo-form-container .sgp-button:hover {
                box-shadow: 
                    0 0 8px ${neonColor}80,
                    0 0 18px ${neonColor}80,
                    0 0 ${neonIntensity + 8}px ${neonColor}90,
                    0 0 ${neonIntensity * 2 + 15}px ${neonColor}70,
                    0 4px 12px rgba(0,0,0,0.3) !important;
                transform: translateY(-3px) scale(1.02) !important;
                border: 1px solid ${neonColor} !important;
                text-shadow: 0 0 8px ${neonColor}80 !important;
            }
            
            .sgp-duo-form-container .sgp-button:focus {
                outline: none !important;
                box-shadow: 
                    0 0 8px ${neonColor}80,
                    0 0 18px ${neonColor}80,
                    0 0 ${neonIntensity + 8}px ${neonColor}90,
                    0 0 ${neonIntensity * 2 + 15}px ${neonColor}70 !important;
            }
            
            ${neonAnimation === 'yes' ? `
            .sgp-duo-form-container .sgp-button {
                animation: neon-glow 2.5s ease-in-out infinite alternate !important;
            }
            
            @keyframes neon-glow {
                0% {
                    box-shadow: 
                        0 0 5px ${neonColor}40,
                        0 0 10px ${neonColor}40,
                        0 0 ${neonIntensity}px ${neonColor}60,
                        0 0 ${neonIntensity * 2}px ${neonColor}40;
                    text-shadow: 0 0 5px ${neonColor}60;
                }
                100% {
                    box-shadow: 
                        0 0 8px ${neonColor}70,
                        0 0 16px ${neonColor}70,
                        0 0 ${neonIntensity + 5}px ${neonColor}80,
                        0 0 ${neonIntensity * 2 + 8}px ${neonColor}60;
                    text-shadow: 0 0 8px ${neonColor}80;
                }
            }
            ` : ''}
            
            /* Efeito especial para botão "Avançar" com neon */
            .sgp-duo-form-container.neon-enabled .sgp-button-next,
            .sgp-duo-form-container.neon-enabled .sgp-button-next-dynamic {
                animation: neon-glow 2.5s ease-in-out infinite alternate, pulse-next-neon 3s infinite !important;
            }
            
            @keyframes pulse-next-neon {
                0%, 100% { 
                    box-shadow: 
                        0 0 5px ${neonColor}40,
                        0 0 10px ${neonColor}40,
                        0 0 ${neonIntensity}px ${neonColor}60,
                        0 0 ${neonIntensity * 2}px ${neonColor}40,
                        0 0 0 0 ${neonColor}30;
                }
                50% { 
                    box-shadow: 
                        0 0 8px ${neonColor}70,
                        0 0 16px ${neonColor}70,
                        0 0 ${neonIntensity + 5}px ${neonColor}80,
                        0 0 ${neonIntensity * 2 + 8}px ${neonColor}60,
                        0 0 0 20px ${neonColor}00;
                }
            }
        `;
        
        if (!$('#sgp-neon-styles').length) {
            $('<style id="sgp-neon-styles">' + neonCSS + '</style>').appendTo('head');
        }
    }
    
    // Função utilitária para mostrar alertas
    function showAlert(message, type) {
        const alertClass = type === 'error' ? 'sgp-alert-error' : 'sgp-alert-success';
        $('<div class="sgp-alert ' + alertClass + '">' + message + '</div>')
            .appendTo('.sgp-duo-form-container')
            .delay(5000)
            .fadeOut(400, function() {
                $(this).remove();
            });
    }
    
    // Função para toggle do loading
    function toggleLoading($button, isLoading) {
        $button.prop('disabled', isLoading);
        $button.find('.sgp-spinner').toggle(isLoading);
        const originalText = $button.data('original-text') || $button.find('.sgp-button-text').text();
        $button.data('original-text', originalText);
        $button.find('.sgp-button-text').text(isLoading ? 'Processando...' : originalText);
    }
    
    // Função para resetar resultados
    function resetResults($container) {
        $container.hide()
            .find('#sgp-duo-coverage-status')
            .removeClass('sgp-status-success sgp-status-error sgp-status-warning')
            .empty();
    }
    
    // Função para transição suave entre etapas
    function transitionToStep(stepNumber) {
        const $currentStep = $('.sgp-step-wrapper.sgp-step-active');
        const $targetStep = $('#sgp-step-' + stepNumber);
        
        // Transição suave
        $currentStep.addClass('sgp-step-exiting');
        
        setTimeout(() => {
            $currentStep.removeClass('sgp-step-active sgp-step-exiting');
            $targetStep.addClass('sgp-step-active');
            
            // Scroll suave para o topo do formulário
            $('html, body').animate({
                scrollTop: $('.sgp-duo-form-container').offset().top - 50
            }, 400);
        }, 300);
    }
    
    // Função para aplicar efeitos do botão "Avançar"
    function applyNextButtonEffects($button) {
        if (nextBgColor && nextBgColorSecondary) {
            // Aplica gradiente se ambas as cores foram definidas
            $button.css('background', `linear-gradient(135deg, ${nextBgColor} 0%, ${nextBgColorSecondary} 100%)`);
        } else if (nextBgColor) {
            // Aplica cor sólida se apenas uma cor foi definida
            $button.css('background', nextBgColor);
        }
        
        if (nextPulseColor) {
            // Aplica efeito pulse se a cor foi definida
            $button.addClass('sgp-button-next-dynamic');
            // Cria keyframes dinâmicos
            const keyframes = `
                @keyframes pulse-next-dynamic {
                    0%, 100% { box-shadow: 0 0 0 0 ${nextPulseColor}66; }
                    50% { box-shadow: 0 0 0 10px ${nextPulseColor}00; }
                }
            `;
            if (!$('#sgp-dynamic-keyframes').length) {
                $('<style id="sgp-dynamic-keyframes">' + keyframes + '</style>').appendTo('head');
            }
            $button.css('animation', 'pulse-next-dynamic 2s infinite');
        } else {
            $button.addClass('sgp-button-next');
        }
    }
    
    // Função para lidar com resposta de disponibilidade
    function handleAvailabilityResponse(data) {
        const $results = $('#sgp-duo-coverage-results');
        const $status = $('#sgp-duo-coverage-status');
        
        // Define o status baseado na resposta
        if (data.available) {
            $status.removeClass('sgp-status-warning sgp-status-error').addClass('sgp-status-success')
                .html('<span class="sgp-status-icon" style="font-size:2rem;vertical-align:middle;">✅</span> <span class="sgp-status-text" style="font-size:1.2rem;font-weight:600;margin-left:0.5rem;">Excelente, atendemos sua residência!</span>');
        } else {
            $status.removeClass('sgp-status-success sgp-status-error').addClass('sgp-status-warning')
                .html('<span class="sgp-status-icon" style="font-size:2rem;vertical-align:middle;">⚠️</span> <span class="sgp-status-text" style="font-size:1.2rem;font-weight:600;margin-left:0.5rem;">Infelizmente ainda não chegamos nessa área.</span>');
        }
        
        // Mostra resultados com animação
        $results.slideDown(400);
        
        // Scroll suave para os resultados
        setTimeout(() => {
            $('html, body').animate({
                scrollTop: $results.offset().top - 50
            }, 500);
        }, 200);
    }

    // Busca automática de CEP (ViaCEP) na etapa 1
    $('#duo-cep').on('blur', function() {
        const cep = $(this).val().replace(/\D/g, '');
        if (cep.length === 8) {
            $(this).addClass('sgp-loading');
            $.getJSON(`https://viacep.com.br/ws/${cep}/json/`, function(data) {
                if (!data.erro) {
                    if (data.bairro) $('#duo-neighborhood').val(data.bairro);
                    if (data.localidade) $('#duo-city').val(data.localidade);
                    if (data.uf) $('#duo-state').val(data.uf);
                    if (data.bairro) {
                        $('#duo-number').focus();
                    }
                } else {
                    showAlert('CEP não encontrado. Verifique e tente novamente.', 'error');
                }
            }).fail(function() {
                showAlert('Erro ao consultar CEP. Tente novamente.', 'error');
            }).always(() => {
                $('#duo-cep').removeClass('sgp-loading');
            });
        }
    });

    // Etapa 1: Viabilidade
    $('#sgp-duo-viabilidade-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $results = $('#sgp-duo-coverage-results');
        
        // Se o botão já foi transformado em "Avançar", vai para próxima etapa
        if ($button.data('is-avancar')) {
            transitionToStep(2);
            return;
        }
        
        // Validação completa dos campos obrigatórios
        const requiredFields = ['cep', 'street', 'number', 'neighborhood', 'city', 'state'];
        const missingFields = [];
        
        requiredFields.forEach(field => {
            const $field = $form.find(`[name="${field}"]`);
            if (!$field.val().trim()) {
                missingFields.push($field.prev('label').text().replace('*', '').trim());
                $field.addClass('sgp-input-error');
            } else {
                $field.removeClass('sgp-input-error');
            }
        });
        
        // Validação do checkbox de termos
        if (!$form.find('[name="terms"]').is(':checked')) {
            showAlert('Você deve concordar com os termos para continuar.', 'error');
            return;
        }
        
        if (missingFields.length > 0) {
            showAlert(`Preencha os campos obrigatórios: ${missingFields.join(', ')}`, 'error');
            return;
        }
        
        // Validação do CEP
        const cep = $form.find('[name="cep"]').val().replace(/\D/g, '');
        if (cep.length !== 8) {
            showAlert('CEP inválido. Digite os 8 números.', 'error');
            return;
        }
        
        // Mostra loader
        toggleLoading($button, true);
        
        // Limpa resultados anteriores
        resetResults($results);
        
        // Envia requisição AJAX
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    
                    // Armazena os dados da etapa 1 para usar na etapa 2
                    const dadosEtapa1 = {
                        cep: $form.find('[name="cep"]').val().replace(/\D/g, ''),
                        endereco: $form.find('[name="street"]').val(),
                        numero: $form.find('[name="number"]').val(),
                        bairro: $form.find('[name="neighborhood"]').val(),
                        cidade: $form.find('[name="city"]').val(),
                        estado: $form.find('[name="state"]').val(),
                        viabilidade_aprovada: response.data.available ? 1 : 0
                    };
                    
                    // Armazena no localStorage ou data attribute
                    $('#sgp-duo-lead-form').data('endereco-etapa1', dadosEtapa1);
                    
                    handleAvailabilityResponse(response.data);
                    
                    // Transforma o botão em "Avançar" após um delay
                    setTimeout(() => {
                        $button.find('.sgp-button-text').text('<?php echo esc_js($texto_botao_avancar); ?>');
                        $button.data('is-avancar', true);
                        $button.data('original-text', '<?php echo esc_js($texto_botao_avancar); ?>');
                        
                        // Aplica efeitos especiais
                        applyNextButtonEffects($button);
                    }, 1000);
                } else {
                    showAlert(response.data.message || 'Erro na consulta. Tente novamente.', 'error');
                }
            },
            error: function(xhr) {
                const errorMsg = xhr.responseJSON?.data?.message || 'Erro na comunicação com o servidor.';
                showAlert(errorMsg, 'error');
            },
            complete: function() {
                toggleLoading($button, false);
            }
        });
    });
    
    // Remove classe de erro ao digitar
    $('.sgp-input').on('input', function() {
        $(this).removeClass('sgp-input-error');
    });
    
    // Etapa 2: Lead
    $('#sgp-duo-lead-form').on('submit', function(e){
        e.preventDefault();
        
        var form = $(this);
        var btn = form.find('button[type=submit]');
        var resultado = $('#sgp-duo-lead-resultado');
        
        // Inclui os dados da etapa 1 no envio
        var dadosEtapa1 = form.data('endereco-etapa1');
        var formData = form.serialize();
        
        // Adiciona os dados do endereço ao formulário
        if (dadosEtapa1) {
            formData += '&cep_endereco=' + encodeURIComponent(dadosEtapa1.cep);
            formData += '&endereco_completo=' + encodeURIComponent(dadosEtapa1.endereco);
            formData += '&numero_endereco=' + encodeURIComponent(dadosEtapa1.numero);
            formData += '&bairro_endereco=' + encodeURIComponent(dadosEtapa1.bairro);
            formData += '&cidade_endereco=' + encodeURIComponent(dadosEtapa1.cidade);
            formData += '&estado_endereco=' + encodeURIComponent(dadosEtapa1.estado);
            formData += '&viabilidade_aprovada=' + encodeURIComponent(dadosEtapa1.viabilidade_aprovada);
        }
        
        // Validação básica
        var nome = form.find('[name="nome"]').val();
        var email = form.find('[name="email"]').val();
        var telefone = form.find('[name="telefone"]').val();
        
        if (!nome || !email || !telefone) {
            showAlert('Preencha todos os campos obrigatórios.', 'error');
            return;
        }
        
        toggleLoading(btn, true);
        resultado.html('');
        
        $.ajax({
            url: sgpIntegrationVars.ajaxUrl,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    resultado.html('<div class="sgp-alert sgp-alert-success">'+response.data.message+'</div>');
                    form[0].reset();
                } else {
                    resultado.html('<div class="sgp-alert sgp-alert-error">'+(response.data && response.data.message ? response.data.message : 'Erro ao enviar lead')+'</div>');
                }
            },
            error: function(xhr, status, error) {
                const errorMsg = xhr.responseJSON?.data?.message || 'Erro ao enviar. Tente novamente.';
                resultado.html('<div class="sgp-alert sgp-alert-error">'+errorMsg+'</div>');
            },
            complete: function() {
                toggleLoading(btn, false);
            }
        });
    });
});
</script>

<style>
/* =============================================
   CONTAINER DAS ETAPAS
   ============================================= */

.sgp-steps-container {
    position: relative;
    overflow: hidden;
}

.sgp-step-wrapper {
    opacity: 0;
    transform: translateX(50px);
    transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
    position: absolute;
    width: 100%;
    top: 0;
    left: 0;
    visibility: hidden;
}

.sgp-step-wrapper.sgp-step-active {
    opacity: 1;
    transform: translateX(0);
    position: relative;
    visibility: visible;
}

.sgp-step-wrapper.sgp-step-exiting {
    opacity: 0;
    transform: translateX(-50px);
}

/* =============================================
   ESTILO DO FORMULÁRIO DUO
   ============================================= */

.sgp-duo-form-container {
    margin: 0 auto;
}

.sgp-duo-step h3 {
    margin-bottom: 1.5rem;
    color: #2d3748;
    font-size: 1.5rem;
    font-weight: 600;
}

.sgp-form-2col-row {
    display: flex;
    gap: 1rem;
    margin-bottom: 1rem;
}

.sgp-form-2col-row .sgp-form-group {
    flex: 1;
}

.sgp-form-group {
    margin-bottom: 1.25rem;
}

.sgp-form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #4a5568;
    font-size: 0.9rem;
}

.sgp-input {
    width: 100%;
    padding: 0.875rem 1rem;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.95rem;
    box-sizing: border-box;
    transition: all 0.3s ease;
    background-color: #f8fafc;
}

.sgp-input:focus {
    border-color: #3182ce;
    outline: none;
    box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
    background-color: #ffffff;
    transform: translateY(-1px);
}

.sgp-input-error {
    border-color: #e53e3e !important;
    box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.1) !important;
    animation: shake 0.5s ease-in-out;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

.sgp-help-text {
    font-size: 0.8rem;
    color: #718096;
    margin-top: 0.25rem;
    display: block;
}

.sgp-form-checkbox {
    display: block;
    margin-bottom: 1.5rem;
}

.sgp-checkbox-label {
    display: flex;
    align-items: flex-start;
    font-weight: 400;
    cursor: pointer;
    font-size: 0.9rem;
    line-height: 1.4;
}

.sgp-checkbox-label input[type=checkbox] {
    margin: 0.1rem 0.75rem 0 0;
    width: 18px;
    height: 18px;
    accent-color: #3182ce;
}

.sgp-checkbox-text {
    color: #4a5568;
}

.sgp-checkbox-text a {
    color: #3182ce;
    text-decoration: none;
}

.sgp-checkbox-text a:hover {
    text-decoration: underline;
}

/* =============================================
   BOTÕES E AÇÕES
   ============================================= */

.sgp-form-actions {
    margin-top: 1.5rem;
}

.sgp-button {
    border: none;
    padding: 0.875rem 1.5rem;
    border-radius: 8px;
    cursor: pointer;
    font-size: 0.95rem;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    width: 100%;
    /* Base para efeito neon */
    border: 1px solid transparent;
}

.sgp-button:hover {
    transform: translateY(-2px);
}

/* Efeito do botão "Avançar" - fallback se cores não forem definidas */
.sgp-button-next {
    background: linear-gradient(135deg, #38a169 0%, #48bb78 100%);
    animation: pulse-next 2s infinite;
}

@keyframes pulse-next {
    0%, 100% { box-shadow: 0 0 0 0 rgba(56, 161, 105, 0.4); }
    50% { box-shadow: 0 0 0 10px rgba(56, 161, 105, 0); }
}

/* Ajuste para botões com neon - não aplicar hover padrão */
.sgp-duo-form-container.neon-enabled .sgp-button:hover {
    transform: none;
}

.sgp-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
}

.sgp-spinner {
    display: inline-block;
    width: 18px;
    height: 18px;
    vertical-align: middle;
    margin-left: 8px;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top: 2px solid white;
    animation: sgp-spin 0.8s linear infinite;
}

@keyframes sgp-spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* =============================================
   RESULTADOS
   ============================================= */

.sgp-results-container {
    margin-top: 1.5rem;
}

.sgp-results-minimal {
    background: none;
    border: none;
    box-shadow: none;
    padding: 0;
}

.sgp-status-minimal {
    background: linear-gradient(135deg, #e6f9ed 0%, #f0fff4 100%);
    color: #2f855a;
    border: 2px solid #c6f6d5;
    border-radius: 12px;
    display: inline-block;
    padding: 1.25rem 2rem;
    margin: 0 auto;
    font-size: 1.1rem;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(33,122,60,0.08);
    animation: slideInUp 0.5s ease-out;
}

@keyframes slideInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.sgp-status-warning.sgp-status-minimal {
    background: linear-gradient(135deg, #fef5e7 0%, #fffbeb 100%);
    color: #d69e2e;
    border-color: #fbd38d;
}

/* =============================================
   ALERTAS
   ============================================= */

.sgp-alert {
    padding: 1rem 1.25rem;
    margin: 1rem 0;
    border-radius: 8px;
    font-size: 0.9rem;
    border-left: 4px solid;
    animation: slideInDown 0.3s ease-out;
}

@keyframes slideInDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.sgp-alert-success {
    background-color: #f0fff4;
    color: #2f855a;
    border-left-color: #38a169;
}

.sgp-alert-error {
    background-color: #fff5f5;
    color: #c53030;
    border-left-color: #e53e3e;
}

/* =============================================
   RESPONSIVIDADE
   ============================================= */

@media (max-width: 768px) {
    .sgp-form-2col-row {
        flex-direction: column;
        gap: 0;
    }
}

@media (max-width: 576px) {
    .sgp-duo-step h3 {
        font-size: 1.25rem;
    }
    
    .sgp-status-minimal {
        padding: 1rem 1.5rem;
        font-size: 1rem;
    }
}
</style> 
